//variables
var name = "Ali";
let age = 20;
const country = "Pakistan";

console.log(name);
console.log(age);
console.log(country);
//functions
function greet() {
    console.log("Hello, welcome to JavaScript!");
}

greet();

//functions with parameters
function add(a, b) {
    return a + b;
}

console.log(add(5, 3));
//evenss
function showMessage() {
    alert("Button was clicked!");
}
function changeText() {
    document.getElementById("demo").innerHTML = "Text Changed!";
}