<?php
require_once 'config/database.php';

$error = '';
$success = '';

// If already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}

// Process login form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Step 1: Get and sanitize input
    $login_input = trim($_POST['login_input']); // Can be username or email
    $password = $_POST['password'];
    
    // Step 2: Validate inputs are not empty
    if (empty($login_input) || empty($password)) {
        $error = 'Please enter username/email and password';
    } else {
        
        try {
            // Step 3: Get database connection
            $conn = getConnection();
            
            // Step 4: Prepare SQL query to find user by username OR email
            $sql = "SELECT id, username, email, password, full_name, status 
                    FROM users 
                    WHERE (username = :login_input OR email = :login_input) 
                    AND status = 'active'";
            
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':login_input', $login_input);
            $stmt->execute();
            
            // Step 5: Check if user exists
            if ($stmt->rowCount() > 0) {
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                // Step 6: Verify password
                if (password_verify($password, $user['password'])) {
                    
                    // Step 7: Password is correct - create session
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['login_time'] = time();
                    
                    // Step 8: Update last login time in database (optional)
                    $update_sql = "UPDATE users SET last_login = NOW() WHERE id = :user_id";
                    $update_stmt = $conn->prepare($update_sql);
                    $update_stmt->bindParam(':user_id', $user['id']);
                    $update_stmt->execute();
                    
                    // Step 9: Redirect to dashboard
                    header('Location: dashboard.php');
                    exit();
                    
                } else {
                    // Invalid password
                    $error = 'Invalid password. Please try again.';
                }
            } else {
                // User not found
                $error = 'No account found with that username/email or account is inactive.';
            }
            
        } catch (PDOException $e) {
            $error = 'Login failed: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="login-container">
            <div class="login-header">
                <h2>Welcome Back</h2>
                <p>Please login to your account</p>
            </div>
            
            <!-- Display error messages -->
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <!-- Display success messages -->
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>
            
            <!-- Login Form -->
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="login-form">
                <div class="form-group">
                    <label for="login_input">Username or Email</label>
                    <input type="text" 
                           id="login_input" 
                           name="login_input" 
                           required 
                           autofocus
                           placeholder="Enter your username or email"
                           value="<?php echo isset($_POST['login_input']) ? htmlspecialchars($_POST['login_input']) : ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" 
                           id="password" 
                           name="password" 
                           required
                           placeholder="Enter your password">
                    <span class="toggle-password" onclick="togglePassword()">👁️</span>
                </div>
                
                <div class="form-options">
                    <label class="checkbox-label">
                        <input type="checkbox" name="remember"> Remember Me
                    </label>
                    <a href="forgot_password.php" class="forgot-link">Forgot Password?</a>
                </div>
                
                <button type="submit" class="btn-login">Login</button>
                
                <div class="register-link">
                    Don't have an account? <a href="register.php">Register here</a>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function togglePassword() {
        var x = document.getElementById("password");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
    </script>
</body>
</html>