<?php
require_once 'config/database.php';

echo "<h2>Database Connection Test</h2>";

try {
    $conn = getConnection();
    echo "<p style='color:green'>✓ Database connected successfully!</p>";
    
    // Test query
    $stmt = $conn->query("SELECT COUNT(*) as total FROM users");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "<p>✓ Total users in database: " . $result['total'] . "</p>";
    
} catch (Exception $e) {
    echo "<p style='color:red'>✗ Connection failed: " . $e->getMessage() . "</p>";
}
?>