-- Create database (if not already created)
CREATE DATABASE IF NOT EXISTS login_system;
USE login_system;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    status ENUM('active', 'inactive') DEFAULT 'active'
);

-- Insert a test user (password is 'password123')
INSERT INTO users (username, email, password, full_name) 
VALUES ('john_doe', 'john@example.com', '$2y$10$YourHashedPasswordHere', 'John Doe');

-- Note: Generate proper password hash using password_hash('password123', PASSWORD_DEFAULT)