const routes = {
    '/login': {
      title: 'Sign in',
      render: () => renderLoginForm()
    },
    '/register': {
      title: 'Create account',
      render: () => renderRegisterForm()
    }
  };

  // Helper: get current path (normalized)
  function getCurrentPath() {
    let path = window.location.pathname;
    // remove trailing slash for consistency, but keep root style
    if (path !== '/' && path.endsWith('/')) {
      path = path.slice(0, -1);
    }
    // if path is empty or just slash -> default to /login
    if (path === '' || path === '/') {
      return '/login';
    }
    // supported routes: /login , /register
    if (path === '/login' || path === '/register') {
      return path;
    }
    // fallback for unknown routes -> 404-like redirect to login
    return '/login';
  }

  // Update active navigation style based on current route
  function updateActiveNav(path) {
    const btns = document.querySelectorAll('.nav-btn');
    btns.forEach(btn => {
      const routeValue = btn.getAttribute('data-route'); // 'login' or 'register'
      const fullPath = `/${routeValue}`;
      if (fullPath === path) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  }

  // Render the view inside container and sync title, active state
  function renderRoute(path) {
    const routeHandler = routes[path];
    const container = document.getElementById('viewContainer');
    if (!container) return;

    if (routeHandler) {
      container.innerHTML = routeHandler.render();
      // Update document title for better UX
      document.title = routeHandler.title === 'Sign in' ? '🔐 Login | Auth Demo' : '📝 Register | Auth Demo';
    } else {
      // fallback (should not happen due to getCurrentPath)
      container.innerHTML = `<div class="demo-message">⚠️ Route not found. <a href="#" id="fallbackLogin">Go to /login</a></div>`;
      const fallbackLink = document.getElementById('fallbackLogin');
      if (fallbackLink) {
        fallbackLink.addEventListener('click', (e) => {
          e.preventDefault();
          navigateTo('/login');
        });
      }
    }
    updateActiveNav(path);
    attachFormHandlers(path);
  }

  // Attach event listeners for forms dynamically after render
  function attachFormHandlers(currentPath) {
    if (currentPath === '/login') {
      const loginForm = document.getElementById('loginFormElement');
      if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
          e.preventDefault();
          const email = document.getElementById('loginEmail')?.value.trim() || '';
          const password = document.getElementById('loginPassword')?.value;
          // simple demo validation (non empty)
          if (!email || !password) {
            showMessage('loginMessage', '⚠️ Please fill in both email and password.', 'error');
            return;
          }
          if (!email.includes('@') || !email.includes('.')) {
            showMessage('loginMessage', '📧 Please enter a valid email address (e.g., name@example.com).', 'error');
            return;
          }
          // mock success
          showMessage('loginMessage', `✨ Welcome back! (Demo login successful for ${email})`, 'success');
          // optional: you could reset form or redirect, but for demo just success.
          setTimeout(() => {
            // just to illustrate keep message
          }, 100);
        });
      }
    } 
    else if (currentPath === '/register') {
      const registerForm = document.getElementById('registerFormElement');
      if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
          e.preventDefault();
          const fullname = document.getElementById('regName')?.value.trim() || '';
          const email = document.getElementById('regEmail')?.value.trim() || '';
          const password = document.getElementById('regPassword')?.value;
          const confirm = document.getElementById('regConfirm')?.value;

          if (!fullname || !email || !password || !confirm) {
            showMessage('registerMessage', '⚠️ All fields are required.', 'error');
            return;
          }
          if (password.length < 4) {
            showMessage('registerMessage', '🔒 Password must be at least 4 characters.', 'error');
            return;
          }
          if (password !== confirm) {
            showMessage('registerMessage', '❌ Passwords do not match.', 'error');
            return;
          }
          if (!email.includes('@')) {
            showMessage('registerMessage', '📧 Please enter a valid email address.', 'error');
            return;
          }
          showMessage('registerMessage', `🎉 Account created for ${fullname} (${email})! You can now go to /login.`, 'success');
          // optional: add small delay and maybe suggest login link? but not mandatory
        });
      }
    }
  }

  // helper to show styled feedback inside form container
  function showMessage(elementId, text, type = 'info') {
    const msgDiv = document.getElementById(elementId);
    if (!msgDiv) return;
    msgDiv.textContent = text;
    msgDiv.style.display = 'block';
    msgDiv.style.background = type === 'success' ? '#e0f2e9' : (type === 'error' ? '#fee9e6' : '#eef2ff');
    msgDiv.style.color = type === 'success' ? '#0a5c3e' : (type === 'error' ? '#b91c1c' : '#2c5282');
    msgDiv.style.borderLeftColor = type === 'success' ? '#2c9e6e' : (type === 'error' ? '#e53e3e' : '#4299e1');
    // auto clear after 4 secs (optional)
    setTimeout(() => {
      if (msgDiv) {
        msgDiv.style.opacity = '0';
        setTimeout(() => {
          if (msgDiv) {
            msgDiv.style.display = 'none';
            msgDiv.style.opacity = '1';
          }
        }, 200);
      }
    }, 3500);
  }

  // Navigation function: update url and render
  function navigateTo(path, addToHistory = true) {
    const normalizedPath = path === '/' ? '/login' : path;
    if (normalizedPath !== '/login' && normalizedPath !== '/register') return;
    if (addToHistory) {
      window.history.pushState({}, '', normalizedPath);
    }
    renderRoute(normalizedPath);
  }

  // ----- RENDER COMPONENTS (pure HTML strings) -----
  function renderLoginForm() {
    return `
      <h2>Welcome Back</h2>
      <div class="sub">Sign in to continue your journey</div>
      <form id="loginFormElement">
        <div class="input-group">
          <label for="loginEmail">Email address</label>
          <input type="email" id="loginEmail" placeholder="hello@example.com" autocomplete="email">
        </div>
        <div class="input-group">
          <label for="loginPassword">Password</label>
          <input type="password" id="loginPassword" placeholder="••••••••" autocomplete="current-password">
        </div>
        <button type="submit" class="action-btn">→ Sign in</button>
        <div id="loginMessage" class="demo-message" style="display: none;"></div>
      </form>
      <div class="route-info">
        ⚡ <span class="highlight">POST /login</span> simulation — credential validation demo
      </div>
    `;
  }

  function renderRegisterForm() {
    return `
      <h2>Create Account</h2>
      <div class="sub">Join our platform — it takes seconds</div>
      <form id="registerFormElement">
        <div class="input-group">
          <label for="regName">Full name</label>
          <input type="text" id="regName" placeholder="Alex Johnson" autocomplete="name">
        </div>
        <div class="input-group">
          <label for="regEmail">Email address</label>
          <input type="email" id="regEmail" placeholder="hello@example.com" autocomplete="email">
        </div>
        <div class="input-group">
          <label for="regPassword">Password</label>
          <input type="password" id="regPassword" placeholder="Create a strong password" autocomplete="new-password">
        </div>
        <div class="input-group">
          <label for="regConfirm">Confirm password</label>
          <input type="password" id="regConfirm" placeholder="Repeat password" autocomplete="off">
        </div>
        <button type="submit" class="action-btn">✓ Create account</button>
        <div id="registerMessage" class="demo-message" style="display: none;"></div>
      </form>
      <div class="route-info">
        📋 <span class="highlight">POST /register</span> — client-side validation & mock account creation
      </div>
    `;
  }

  // --- event listener for browser back/forward (popstate) ---
  window.addEventListener('popstate', () => {
    const currentPath = getCurrentPath();
    renderRoute(currentPath);
  });

  // -- manual nav buttons (data-route) event delegation --
  function initNavigationButtons() {
    const container = document.getElementById('appRoot');
    if (!container) return;
    container.addEventListener('click', (e) => {
      const btn = e.target.closest('.nav-btn');
      if (btn && btn.getAttribute('data-route')) {
        e.preventDefault();
        const routeName = btn.getAttribute('data-route'); // 'login' or 'register'
        const targetPath = `/${routeName}`;
        if (targetPath !== getCurrentPath()) {
          navigateTo(targetPath, true);
        }
      }
    });
  }

  // --- initial load: set correct route based on URL and render ---
  function bootstrap() {
    initNavigationButtons();
    let initialPath = getCurrentPath();
    // ensure if url is root or unrecognized -> rewrite to /login gracefully without breaking browser history
    const currentUrlPath = window.location.pathname;
    if (currentUrlPath !== '/login' && currentUrlPath !== '/register' && currentUrlPath !== '/') {
      // if user lands on /some-invalid-path, we replace state to /login (clean)
      window.history.replaceState({}, '', '/login');
      initialPath = '/login';
    } else if (currentUrlPath === '/') {
      window.history.replaceState({}, '', '/login');
      initialPath = '/login';
    }
    renderRoute(initialPath);
  }

  // additional live update for forms when navigation uses 'back' after rendering, attach handlers again? 
  // But since renderRoute already calls attachFormHandlers, it's fine.
  // Also in case url is manually typed in browser (like index.html#? Not needed), we serve correct route on load.
  bootstrap();