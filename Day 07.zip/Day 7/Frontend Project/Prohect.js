// Form submission handling
        document.getElementById('contactForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const service = document.getElementById('service').value;
            const message = document.getElementById('message').value.trim();
            const newsletter = document.getElementById('newsletter').checked;
            
            // Validation
            if (!name || !email || !message) {
                showMessage('Please fill in all required fields (*)', 'error');
                return;
            }
            
            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                showMessage('Please enter a valid email address', 'error');
                return;
            }
            
            // Simulate form submission (in real scenario, send to backend)
            console.log('Form submitted:', {
                name, email, service, message, newsletter
            });
            
            // Show success message
            showMessage(
                `Thank you ${name}! Your message has been sent successfully. ${newsletter ? 'You\'ve been subscribed to our newsletter.' : ''}`,
                'success'
            );
            
            // Reset form
            document.getElementById('contactForm').reset();
            
            // Optional: Remove success message after 5 seconds
            setTimeout(() => {
                const messageDiv = document.getElementById('formMessage');
                if (messageDiv.children.length > 0) {
                    messageDiv.innerHTML = '';
                }
            }, 5000);
        });
        
        // Function to show messages
        function showMessage(text, type) {
            const messageDiv = document.getElementById('formMessage');
            messageDiv.innerHTML = `
                <div class="message-alert ${type}">
                    ${text}
                </div>
            `;
            
            // Scroll to message
            messageDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
        
        // Add smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });
        
        // Add animation on scroll
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);
        
        // Observe feature cards
        document.querySelectorAll('.feature-card').forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(30px)';
            card.style.transition = 'all 0.6s ease';
            observer.observe(card);
        });