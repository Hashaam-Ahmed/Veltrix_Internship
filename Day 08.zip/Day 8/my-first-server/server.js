// server.js - Simple HTTP server
const http = require('http');

const server = http.createServer((req, res) => {
    // Set response headers
    res.writeHead(200, { 'Content-Type': 'text/html' });
    
    // Send response
    res.end(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>My First Node.js Server</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    text-align: center;
                    margin-top: 50px;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                }
                h1 { font-size: 3em; }
                .info { background: rgba(255,255,255,0.2); padding: 20px; border-radius: 10px; }
            </style>
        </head>
        <body>
            <div class="info">
                <h1>🚀 Server is Running!</h1>
                <p>Your Node.js server is working perfectly!</p>
                <p>Request URL: ${req.url}</p>
                <p>Request Method: ${req.method}</p>
            </div>
        </body>
        </html>
    `);
});

const PORT = 3000;
server.listen(PORT, () => {
    console.log(`✅ Server running at http://localhost:${PORT}/`);
    console.log(`📡 Press Ctrl+C to stop the server`);
});