// Get DOM elements
const dynamicText = document.getElementById('dynamicText');
const contentBox = document.getElementById('contentBox');
const counterElement = document.getElementById('counter');
const userInput = document.getElementById('userInput');
const htmlInput = document.getElementById('htmlInput');

// State management
let changeCount = 0;

// Function to update counter
function updateCounter() {
    changeCount++;
    counterElement.textContent = `Changes Made: ${changeCount}`;
    
    // Add animation effect to counter
    counterElement.style.transform = 'scale(1.1)';
    setTimeout(() => {
        counterElement.style.transform = 'scale(1)';
    }, 200);
}

// Method 1: Change text content using textContent
function changeTextPreset(text) {
    dynamicText.textContent = text;
    updateCounter();
    
    // Add visual feedback
    animateContentChange();
}

// Method 2: Clear content
function clearContent() {
    dynamicText.textContent = '';
    updateCounter();
}

// Method 3: Reset to original content
function resetContent() {
    dynamicText.textContent = 'Welcome to Dynamic Content!';
    updateCounter();
}

// Method 4: Change content from input field
function changeTextCustom() {
    const customText = userInput.value.trim();
    if (customText === '') {
        showTemporaryMessage('Please enter some text!', '#ff6b6b');
        return;
    }
    dynamicText.textContent = customText;
    userInput.value = ''; // Clear input after use
    updateCounter();
}

// Method 5: Change content with HTML using innerHTML
function changeHTMLContent() {
    const htmlContent = htmlInput.value.trim();
    if (htmlContent === '') {
        showTemporaryMessage('Please enter some HTML content!', '#ff6b6b');
        return;
    }
    dynamicText.innerHTML = htmlContent;
    htmlInput.value = ''; // Clear textarea after use
    updateCounter();
}

// Method 6: Change content with style modifications
function changeTextWithStyle(text, color, fontSize) {
    dynamicText.textContent = text;
    dynamicText.style.color = color;
    dynamicText.style.fontSize = fontSize;
    updateCounter();
}

// Method 7: Append content (doesn't replace)
function appendContent(text) {
    dynamicText.textContent += text;
    updateCounter();
}

// Method 8: Toggle visibility of content
function toggleContent() {
    if (dynamicText.style.display === 'none') {
        dynamicText.style.display = 'block';
        showTemporaryMessage('Content shown!', '#51cf66');
    } else {
        dynamicText.style.display = 'none';
        showTemporaryMessage('Content hidden!', '#ff6b6b');
    }
}

// Method 9: Change background color of content box
function changeBoxColor(color) {
    contentBox.style.backgroundColor = color;
    updateCounter();
}

// Method 10: Add animation effect when content changes
function animateContentChange() {
    dynamicText.style.transform = 'scale(1.05)';
    dynamicText.style.opacity = '0.8';
    
    setTimeout(() => {
        dynamicText.style.transform = 'scale(1)';
        dynamicText.style.opacity = '1';
    }, 300);
}

// Helper function to show temporary messages
function showTemporaryMessage(message, color) {
    const originalText = dynamicText.textContent;
    const originalColor = dynamicText.style.color;
    
    dynamicText.textContent = message;
    dynamicText.style.color = color;
    
    setTimeout(() => {
        dynamicText.textContent = originalText;
        dynamicText.style.color = originalColor;
    }, 2000);
}

// Event Listeners for keyboard shortcuts
document.addEventListener('keydown', (event) => {
    // Press 'R' to reset content
    if (event.key === 'r' || event.key === 'R') {
        resetContent();
        showTemporaryMessage('Content Reset!', '#51cf66');
    }
    
    // Press 'C' to clear content
    if (event.key === 'c' || event.key === 'C') {
        clearContent();
        showTemporaryMessage('Content Cleared!', '#ff6b6b');
    }
    
    // Press 'T' to toggle visibility
    if (event.key === 't' || event.key === 'T') {
        toggleContent();
    }
});

// Additional DOM manipulation examples

// Method 11: Create and add new elements dynamically
function addNewParagraph() {
    const newParagraph = document.createElement('p');
    newParagraph.textContent = `New paragraph added at ${new Date().toLocaleTimeString()}`;
    newParagraph.style.backgroundColor = '#e8f4f8';
    newParagraph.style.padding = '10px';
    newParagraph.style.margin = '10px 0';
    newParagraph.style.borderRadius = '5px';
    
    contentBox.appendChild(newParagraph);
    updateCounter();
    
    // Auto-remove after 5 seconds to prevent clutter
    setTimeout(() => {
        newParagraph.remove();
    }, 5000);
}

// Method 12: Replace content with loading state
function simulateLoading() {
    const originalContent = dynamicText.innerHTML;
    dynamicText.innerHTML = '<div class="loading">Loading... <span>⏳</span></div>';
    
    setTimeout(() => {
        dynamicText.innerHTML = originalContent;
        showTemporaryMessage('Loading complete!', '#51cf66');
    }, 2000);
    updateCounter();
}

// Method 13: Change multiple properties at once
function updateContentWithStyle() {
    const texts = ['🌟 Amazing!', '🎨 Beautiful!', '⚡ Powerful!', '💡 Creative!'];
    const randomText = texts[Math.floor(Math.random() * texts.length)];
    const randomColor = `hsl(${Math.random() * 360}, 70%, 60%)`;
    const randomSize = `${Math.floor(Math.random() * 20) + 16}px`;
    
    dynamicText.textContent = randomText;
    dynamicText.style.color = randomColor;
    dynamicText.style.fontSize = randomSize;
    dynamicText.style.fontWeight = 'bold';
    
    updateCounter();
}

// Method 14: Animated text change with fade effect
function fadeAndChange(newText) {
    let opacity = 1;
    const fadeInterval = setInterval(() => {
        if (opacity <= 0) {
            clearInterval(fadeInterval);
            dynamicText.textContent = newText;
            const fadeInInterval = setInterval(() => {
                if (opacity >= 1) {
                    clearInterval(fadeInInterval);
                } else {
                    opacity += 0.1;
                    dynamicText.style.opacity = opacity;
                }
            }, 50);
        } else {
            opacity -= 0.1;
            dynamicText.style.opacity = opacity;
        }
    }, 50);
    updateCounter();
}

// Log all available functions
console.log('DOM Manipulation Script Loaded!');
console.log('Available functions:');
console.log('- changeTextPreset(text)');
console.log('- clearContent()');
console.log('- resetContent()');
console.log('- changeTextCustom()');
console.log('- changeHTMLContent()');
console.log('- appendContent(text)');
console.log('- toggleContent()');
console.log('- changeBoxColor(color)');
console.log('- addNewParagraph()');
console.log('- simulateLoading()');
console.log('- updateContentWithStyle()');