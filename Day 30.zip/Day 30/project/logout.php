<?php
require_once 'config/database.php';

if (isLoggedIn()) {
    logUserActivity($_SESSION['user_id'], 'logout', 'User logged out');
}

// Destroy session
$_SESSION = array();
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time()-3600, '/');
}
session_destroy();

redirect('login.php');
?>