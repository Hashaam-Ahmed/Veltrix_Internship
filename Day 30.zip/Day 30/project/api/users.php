<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

$method = $_SERVER['REQUEST_METHOD'];
$response = [];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            // Get single user
            $stmt = $pdo->prepare("SELECT id, username, email, full_name, created_at FROM users WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            $user = $stmt->fetch();
            
            if ($user) {
                $response = ['success' => true, 'data' => $user];
            } else {
                $response = ['success' => false, 'message' => 'User not found'];
                http_response_code(404);
            }
        } else {
            // Get all users (limited for security)
            $stmt = $pdo->query("SELECT id, username, email, full_name, created_at FROM users LIMIT 50");
            $users = $stmt->fetchAll();
            $response = ['success' => true, 'data' => $users, 'total' => count($users)];
        }
        break;
        
    case 'POST':
        // Create new user via API
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (isset($data['username']) && isset($data['email']) && isset($data['password'])) {
            $hashed_password = password_hash($data['password'], PASSWORD_DEFAULT);
            
            try {
                $stmt = $pdo->prepare("INSERT INTO users (username, email, password, full_name) VALUES (?, ?, ?, ?)");
                $stmt->execute([
                    $data['username'],
                    $data['email'],
                    $hashed_password,
                    $data['full_name'] ?? null
                ]);
                
                $response = [
                    'success' => true,
                    'message' => 'User created successfully',
                    'user_id' => $pdo->lastInsertId()
                ];
                http_response_code(201);
            } catch (PDOException $e) {
                $response = ['success' => false, 'message' => 'User already exists or invalid data'];
                http_response_code(400);
            }
        } else {
            $response = ['success' => false, 'message' => 'Missing required fields'];
            http_response_code(400);
        }
        break;
        
    case 'PUT':
        // Update user
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (isset($_GET['id'])) {
            $fields = [];
            $params = [];
            
            if (isset($data['full_name'])) {
                $fields[] = "full_name = ?";
                $params[] = $data['full_name'];
            }
            if (isset($data['email'])) {
                $fields[] = "email = ?";
                $params[] = $data['email'];
            }
            
            if (!empty($fields)) {
                $params[] = $_GET['id'];
                $stmt = $pdo->prepare("UPDATE users SET " . implode(', ', $fields) . " WHERE id = ?");
                
                if ($stmt->execute($params)) {
                    $response = ['success' => true, 'message' => 'User updated successfully'];
                } else {
                    $response = ['success' => false, 'message' => 'Update failed'];
                    http_response_code(400);
                }
            } else {
                $response = ['success' => false, 'message' => 'No fields to update'];
                http_response_code(400);
            }
        } else {
            $response = ['success' => false, 'message' => 'User ID required'];
            http_response_code(400);
        }
        break;
        
    default:
        $response = ['success' => false, 'message' => 'Method not allowed'];
        http_response_code(405);
}

echo json_encode($response);
?>