<?php
require_once 'config/database.php';

if (isLoggedIn()) {
    redirect('dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Full Stack Auth System</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <a href="index.php" class="nav-brand">Auth System</a>
            <ul class="nav-menu">
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Register</a></li>
            </ul>
        </div>
    </nav>
    
    <div class="hero">
        <div class="hero-content">
            <h1>Welcome to Our Authentication System</h1>
            <p>A complete full-stack web application with user authentication, dashboard, database integration, and RESTful API</p>
            <div class="hero-buttons">
                <a href="login.php" class="btn btn-primary">Login</a>
                <a href="register.php" class="btn btn-secondary">Register</a>
            </div>
        </div>
    </div>
    
    <div class="features">
        <div class="feature">
            <h3>Secure Authentication</h3>
            <p>Password hashing, session management, and activity logging</p>
        </div>
        <div class="feature">
            <h3>Interactive Dashboard</h3>
            <p>User statistics, activity tracking, and personalized content</p>
        </div>
        <div class="feature">
            <h3>RESTful API</h3>
            <p>Complete CRUD operations with JSON responses</p>
        </div>
        <div class="feature">
            <h3>Responsive Design</h3>
            <p>Mobile-first approach that works on all devices</p>
        </div>
    </div>
</body>
</html>