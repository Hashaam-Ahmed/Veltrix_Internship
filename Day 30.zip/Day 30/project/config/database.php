<?php
session_start();

$host = 'localhost';
$dbname = 'user_auth_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Helper functions
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function redirect($url) {
    header("Location: $url");
    exit();
}

function logUserActivity($user_id, $activity_type, $description, $ip_address = null) {
    global $pdo;
    if (!$ip_address) {
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
    }
    
    $stmt = $pdo->prepare("INSERT INTO user_activities (user_id, activity_type, description, ip_address) VALUES (?, ?, ?, ?)");
    return $stmt->execute([$user_id, $activity_type, $description, $ip_address]);
}
?>