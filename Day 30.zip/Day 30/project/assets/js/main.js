// API interaction
document.addEventListener('DOMContentLoaded', function() {
    // Modal handling
    const modal = document.getElementById('apiModal');
    const apiBtn = document.getElementById('apiBtn');
    const closeBtn = document.querySelector('.close');
    
    if (apiBtn) {
        apiBtn.addEventListener('click', function(e) {
            e.preventDefault();
            fetchAPI();
        });
    }
    
    if (closeBtn) {
        closeBtn.onclick = function() {
            modal.style.display = 'none';
        }
    }
    
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    }
    
    function fetchAPI() {
        // Show loading
        const responseDiv = document.getElementById('apiResponse');
        responseDiv.textContent = 'Loading...';
        modal.style.display = 'block';
        
        // Fetch users from API
        fetch('api/users.php')
            .then(response => response.json())
            .then(data => {
                responseDiv.textContent = JSON.stringify(data, null, 2);
            })
            .catch(error => {
                responseDiv.textContent = 'Error: ' + error.message;
            });
    }
    
    // Form validation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const password = form.querySelector('#password');
            const confirmPassword = form.querySelector('#confirm_password');
            
            if (password && confirmPassword && password.value !== confirmPassword.value) {
                e.preventDefault();
                alert('Passwords do not match!');
            }
        });
    });
    
    // Real-time password strength indicator
    const passwordField = document.querySelector('#password');
    if (passwordField) {
        passwordField.addEventListener('input', function() {
            const strength = checkPasswordStrength(this.value);
            const strengthDiv = document.getElementById('passwordStrength') || createStrengthIndicator();
            strengthDiv.textContent = strength;
            strengthDiv.style.color = getStrengthColor(strength);
        });
    }
    
    function checkPasswordStrength(password) {
        if (password.length < 6) return 'Weak';
        if (password.length < 10) return 'Medium';
        if (/[A-Z]/.test(password) && /[0-9]/.test(password) && /[^A-Za-z0-9]/.test(password)) {
            return 'Strong';
        }
        return 'Medium';
    }
    
    function createStrengthIndicator() {
        const div = document.createElement('div');
        div.id = 'passwordStrength';
        div.style.marginTop = '5px';
        div.style.fontSize = '12px';
        passwordField.parentNode.appendChild(div);
        return div;
    }
    
    function getStrengthColor(strength) {
        switch(strength) {
            case 'Weak': return '#f44336';
            case 'Medium': return '#ff9800';
            case 'Strong': return '#4caf50';
            default: return '#999';
        }
    }
});

// Smooth scroll
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});