<?php
require_once 'config/database.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

// Get user data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// Get user statistics
$stats = [];
$stmt = $pdo->prepare("SELECT COUNT(*) as total_activities FROM user_activities WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$stats['activities'] = $stmt->fetch()['total_activities'];

// Get recent activities
$stmt = $pdo->prepare("SELECT * FROM user_activities WHERE user_id = ? ORDER BY created_at DESC LIMIT 10");
$stmt->execute([$_SESSION['user_id']]);
$activities = $stmt->fetchAll();

// Get system statistics (for admin)
$isAdmin = ($user['username'] == 'admin');
if ($isAdmin) {
    $stmt = $pdo->query("SELECT COUNT(*) as total_users FROM users");
    $stats['total_users'] = $stmt->fetch()['total_users'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total_activities_all FROM user_activities");
    $stats['total_activities'] = $stmt->fetch()['total_activities_all'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - User Authentication System</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <a href="dashboard.php" class="nav-brand">Auth System</a>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="#" id="apiBtn">API Demo</a></li>
                <li><span class="user-greeting">Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></span></li>
                <li><a href="logout.php" class="btn-logout">Logout</a></li>
            </ul>
        </div>
    </nav>
    
    <div class="container">
        <div class="dashboard-header">
            <h1>Dashboard</h1>
            <p>Welcome back, <?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?>!</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Member Since</h3>
                <p><?php echo date('F j, Y', strtotime($user['created_at'])); ?></p>
            </div>
            
            <div class="stat-card">
                <h3>Last Login</h3>
                <p><?php echo $user['last_login'] ? date('F j, Y g:i A', strtotime($user['last_login'])) : 'First login'; ?></p>
            </div>
            
            <div class="stat-card">
                <h3>Activities</h3>
                <p><?php echo $stats['activities']; ?> total</p>
            </div>
            
            <?php if ($isAdmin): ?>
            <div class="stat-card">
                <h3>System Users</h3>
                <p><?php echo $stats['total_users']; ?> registered</p>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="activities-section">
            <h2>Recent Activities</h2>
            <?php if (empty($activities)): ?>
                <p>No activities recorded yet.</p>
            <?php else: ?>
                <div class="activities-list">
                    <?php foreach ($activities as $activity): ?>
                        <div class="activity-item">
                            <strong><?php echo htmlspecialchars($activity['activity_type']); ?></strong>
                            <p><?php echo htmlspecialchars($activity['description']); ?></p>
                            <small><?php echo date('M j, Y g:i A', strtotime($activity['created_at'])); ?></small>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- API Response Modal -->
        <div id="apiModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <h2>API Response</h2>
                <pre id="apiResponse"></pre>
            </div>
        </div>
    </div>
    
    <script src="assets/js/main.js"></script>
</body>
</html>