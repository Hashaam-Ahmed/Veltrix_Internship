<?php
require_once 'config/database.php';

// Redirect to login if not logged in
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
} else {
    header('Location: login.php');
    exit();
}
?>