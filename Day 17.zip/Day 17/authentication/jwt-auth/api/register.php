<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/database.php';
require_once '../config/jwt-config.php';

$database = new Database();
$db = $database->getConnection();

$data = json_decode(file_get_contents("php://input"));

// Validation (same as session-based)
if(empty($data->username) || empty($data->email) || empty($data->password) || empty($data->full_name)) {
    http_response_code(400);
    echo json_encode(array("message" => "Missing required fields"));
    exit();
}

// Check existing user
$query = "SELECT id FROM users WHERE username = :username OR email = :email";
$stmt = $db->prepare($query);
$stmt->bindParam(':username', $data->username);
$stmt->bindParam(':email', $data->email);
$stmt->execute();

if($stmt->rowCount() > 0) {
    http_response_code(409);
    echo json_encode(array("message" => "User already exists"));
    exit();
}

// Create user
$password_hash = password_hash($data->password, PASSWORD_BCRYPT);
$query = "INSERT INTO users (username, email, password_hash, full_name) VALUES (:username, :email, :password_hash, :full_name)";
$stmt = $db->prepare($query);
$stmt->bindParam(':username', $data->username);
$stmt->bindParam(':email', $data->email);
$stmt->bindParam(':password_hash', $password_hash);
$stmt->bindParam(':full_name', $data->full_name);

if($stmt->execute()) {
    $user_id = $db->lastInsertId();
    $user_data = array(
        'id' => $user_id,
        'username' => $data->username,
        'email' => $data->email,
        'full_name' => $data->full_name
    );
    
    // Generate JWT token
    $token = JWTConfig::generateToken($user_data);
    
    http_response_code(201);
    echo json_encode(array(
        "message" => "Registration successful",
        "user" => $user_data,
        "token" => $token,
        "expires_in" => 3600
    ));
} else {
    http_response_code(500);
    echo json_encode(array("message" => "Registration failed"));
}
?>