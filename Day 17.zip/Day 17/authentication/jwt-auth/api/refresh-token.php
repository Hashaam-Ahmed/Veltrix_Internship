<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/jwt-config.php';

// Get current token
$old_token = JWTConfig::getTokenFromHeader();

if(!$old_token) {
    http_response_code(401);
    echo json_encode(array("message" => "No token provided"));
    exit();
}

// Validate old token
$decoded = JWTConfig::validateToken($old_token);

if(!$decoded) {
    http_response_code(401);
    echo json_encode(array("message" => "Invalid token"));
    exit();
}

// Generate new token
$user_data = (array) $decoded['data'];
$new_token = JWTConfig::generateToken($user_data);

echo json_encode(array(
    "message" => "Token refreshed successfully",
    "token" => $new_token,
    "expires_in" => 3600
));
?>