<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/database.php';
require_once '../config/jwt-config.php';

$database = new Database();
$db = $database->getConnection();

$token = JWTConfig::getTokenFromHeader();

if($token) {
    // Add token to blacklist
    $decoded = JWTConfig::validateToken($token);
    
    if($decoded) {
        $expires_at = date('Y-m-d H:i:s', $decoded['exp']);
        $query = "INSERT INTO token_blacklist (token, expires_at) VALUES (:token, :expires_at)";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':token', $token);
        $stmt->bindParam(':expires_at', $expires_at);
        $stmt->execute();
    }
}

http_response_code(200);
echo json_encode(array("message" => "Logout successful"));
?>