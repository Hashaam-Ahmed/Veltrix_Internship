<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/database.php';
require_once '../config/jwt-config.php';

$database = new Database();
$db = $database->getConnection();

$data = json_decode(file_get_contents("php://input"));

if(empty($data->username) || empty($data->password)) {
    http_response_code(400);
    echo json_encode(array("message" => "Username and password required"));
    exit();
}

// Get user
$query = "SELECT id, username, email, password_hash, full_name, is_active FROM users 
          WHERE username = :login OR email = :login";
$stmt = $db->prepare($query);
$login_param = $data->username;
$stmt->bindParam(':login', $login_param);
$stmt->execute();

if($stmt->rowCount() == 0) {
    http_response_code(401);
    echo json_encode(array("message" => "Invalid credentials"));
    exit();
}

$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Verify password
if(!password_verify($data->password, $user['password_hash'])) {
    http_response_code(401);
    echo json_encode(array("message" => "Invalid credentials"));
    exit();
}

if(!$user['is_active']) {
    http_response_code(403);
    echo json_encode(array("message" => "Account deactivated"));
    exit();
}

// Update last login
$update_query = "UPDATE users SET last_login = NOW() WHERE id = :id";
$update_stmt = $db->prepare($update_query);
$update_stmt->bindParam(':id', $user['id']);
$update_stmt->execute();

// Prepare user data
$user_data = array(
    'id' => $user['id'],
    'username' => $user['username'],
    'email' => $user['email'],
    'full_name' => $user['full_name']
);

// Generate JWT
$token = JWTConfig::generateToken($user_data);

http_response_code(200);
echo json_encode(array(
    "message" => "Login successful",
    "user" => $user_data,
    "token" => $token,
    "token_type" => "Bearer",
    "expires_in" => 3600
));
?>