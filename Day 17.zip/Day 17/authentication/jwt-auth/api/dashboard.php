<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

require_once 'auth_middleware.php';

// Protect route
$user_data = JWTAuthMiddleware::authenticate();

echo json_encode(array(
    "message" => "Welcome to your protected dashboard",
    "user" => $user_data,
    "access_granted" => true,
    "timestamp" => date('Y-m-d H:i:s')
));
?>