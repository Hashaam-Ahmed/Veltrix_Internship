<?php
require_once '../config/jwt-config.php';

class JWTAuthMiddleware {
    
    public static function authenticate() {
        $token = JWTConfig::getTokenFromHeader();
        
        if(!$token) {
            http_response_code(401);
            echo json_encode(array("message" => "No token provided"));
            exit();
        }
        
        $decoded = JWTConfig::validateToken($token);
        
        if(!$decoded) {
            http_response_code(401);
            echo json_encode(array("message" => "Invalid or expired token"));
            exit();
        }
        
        // Optional: Check if token is blacklisted
        if(self::isTokenBlacklisted($token)) {
            http_response_code(401);
            echo json_encode(array("message" => "Token has been revoked"));
            exit();
        }
        
        return $decoded['data'];
    }
    
    private static function isTokenBlacklisted($token) {
        // Implement token blacklist check using database
        // This requires the token_blacklist table
        return false; // Placeholder
    }
}
?>