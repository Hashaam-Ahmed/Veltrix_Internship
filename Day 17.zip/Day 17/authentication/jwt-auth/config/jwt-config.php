<?php
require_once '../vendor/autoload.php';

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class JWTConfig {
    private static $secret_key = "your-super-secret-key-change-this-in-production";
    private static $issuer = "http://localhost/jwt-auth";
    private static $audience = "http://localhost/jwt-auth";
    private static $expiry_time = 3600; // 1 hour in seconds
    
    public static function generateToken($user_data) {
        $issued_at = time();
        $expiration = $issued_at + self::$expiry_time;
        
        $payload = array(
            "iat" => $issued_at,
            "exp" => $expiration,
            "iss" => self::$issuer,
            "aud" => self::$audience,
            "data" => array(
                "user_id" => $user_data['id'],
                "username" => $user_data['username'],
                "email" => $user_data['email'],
                "full_name" => $user_data['full_name']
            )
        );
        
        return JWT::encode($payload, self::$secret_key, 'HS256');
    }
    
    public static function validateToken($token) {
        try {
            $decoded = JWT::decode($token, new Key(self::$secret_key, 'HS256'));
            return (array) $decoded;
        } catch(Exception $e) {
            return false;
        }
    }
    
    public static function getTokenFromHeader() {
        $headers = getallheaders();
        
        if(!isset($headers['Authorization'])) {
            return false;
        }
        
        $auth_header = $headers['Authorization'];
        $token = str_replace('Bearer ', '', $auth_header);
        
        return $token;
    }
}
?>