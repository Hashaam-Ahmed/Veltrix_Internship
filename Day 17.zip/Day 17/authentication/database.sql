-- Create database
CREATE DATABASE IF NOT EXISTS auth_system;
USE auth_system;

-- Users table (common for both authentication methods)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE
);

-- Optional: For JWT - blacklisted tokens table
CREATE TABLE IF NOT EXISTS token_blacklist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    token VARCHAR(500) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_token_expires (expires_at)
);

-- Insert test user (password: Test@123)
INSERT INTO users (username, email, password_hash, full_name) VALUES 
('john_doe', 'john@example.com', '$2y$10$YourHashHere', 'John Doe'),
('jane_smith', 'jane@example.com', '$2y$10$YourHashHere', 'Jane Smith');