<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Get posted data
$data = json_decode(file_get_contents("php://input"));

// Validate input
if(empty($data->username) || empty($data->email) || empty($data->password) || empty($data->full_name)) {
    http_response_code(400);
    echo json_encode(array("message" => "Missing required fields"));
    exit();
}

// Validate email format
if(!filter_var($data->email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(array("message" => "Invalid email format"));
    exit();
}

// Validate password strength
if(strlen($data->password) < 8) {
    http_response_code(400);
    echo json_encode(array("message" => "Password must be at least 8 characters"));
    exit();
}

// Check if user exists
$query = "SELECT id FROM users WHERE username = :username OR email = :email";
$stmt = $db->prepare($query);
$stmt->bindParam(':username', $data->username);
$stmt->bindParam(':email', $data->email);
$stmt->execute();

if($stmt->rowCount() > 0) {
    http_response_code(409);
    echo json_encode(array("message" => "Username or email already exists"));
    exit();
}

// Create user
$password_hash = password_hash($data->password, PASSWORD_BCRYPT);

$query = "INSERT INTO users (username, email, password_hash, full_name) VALUES (:username, :email, :password_hash, :full_name)";
$stmt = $db->prepare($query);
$stmt->bindParam(':username', $data->username);
$stmt->bindParam(':email', $data->email);
$stmt->bindParam(':password_hash', $password_hash);
$stmt->bindParam(':full_name', $data->full_name);

if($stmt->execute()) {
    $user_id = $db->lastInsertId();
    
    // Auto-login after registration
    session_regenerate_id(true);
    $_SESSION['user_id'] = $user_id;
    $_SESSION['username'] = $data->username;
    $_SESSION['full_name'] = $data->full_name;
    $_SESSION['login_time'] = time();
    
    http_response_code(201);
    echo json_encode(array(
        "message" => "Registration successful",
        "user" => array(
            "id" => $user_id,
            "username" => $data->username,
            "email" => $data->email,
            "full_name" => $data->full_name
        )
    ));
} else {
    http_response_code(500);
    echo json_encode(array("message" => "Registration failed"));
}
?>