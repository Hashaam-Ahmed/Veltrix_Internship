<?php
session_start();

class AuthMiddleware {
    
    public static function authenticate() {
        // Check if session exists
        if(!isset($_SESSION['user_id'])) {
            http_response_code(401);
            echo json_encode(array("message" => "Authentication required"));
            exit();
        }
        
        // Optional: Check session timeout (30 minutes)
        $timeout = 1800; // 30 minutes
        if(isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > $timeout)) {
            session_unset();
            session_destroy();
            http_response_code(401);
            echo json_encode(array("message" => "Session expired"));
            exit();
        }
        
        // Optional: Check IP address consistency
        if($_SESSION['ip_address'] != $_SERVER['REMOTE_ADDR']) {
            http_response_code(401);
            echo json_encode(array("message" => "Session hijacking detected"));
            exit();
        }
        
        // Refresh session time
        $_SESSION['login_time'] = time();
        
        return $_SESSION;
    }
}
?>