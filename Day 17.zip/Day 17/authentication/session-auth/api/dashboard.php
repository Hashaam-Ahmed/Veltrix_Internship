<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

require_once 'auth_middleware.php';

// Protect this route
$user_session = AuthMiddleware::authenticate();

// User data (only accessible after authentication)
echo json_encode(array(
    "message" => "Welcome to your dashboard",
    "user" => array(
        "id" => $user_session['user_id'],
        "username" => $user_session['username'],
        "full_name" => $user_session['full_name'],
        "email" => $user_session['email']
    ),
    "session_info" => array(
        "login_time" => date('Y-m-d H:i:s', $user_session['login_time']),
        "session_id" => session_id()
    )
));
?>