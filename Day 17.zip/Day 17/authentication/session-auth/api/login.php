<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Credentials: true");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$data = json_decode(file_get_contents("php://input"));

if(empty($data->username) || empty($data->password)) {
    http_response_code(400);
    echo json_encode(array("message" => "Username and password required"));
    exit();
}

// Get user by username or email
$query = "SELECT id, username, email, password_hash, full_name, is_active FROM users 
          WHERE username = :login OR email = :login";
$stmt = $db->prepare($query);
$login_param = $data->username;
$stmt->bindParam(':login', $login_param);
$stmt->execute();

if($stmt->rowCount() == 0) {
    http_response_code(401);
    echo json_encode(array("message" => "Invalid credentials"));
    exit();
}

$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Verify password
if(!password_verify($data->password, $user['password_hash'])) {
    http_response_code(401);
    echo json_encode(array("message" => "Invalid credentials"));
    exit();
}

// Check if account is active
if(!$user['is_active']) {
    http_response_code(403);
    echo json_encode(array("message" => "Account is deactivated"));
    exit();
}

// Update last login
$update_query = "UPDATE users SET last_login = NOW() WHERE id = :id";
$update_stmt = $db->prepare($update_query);
$update_stmt->bindParam(':id', $user['id']);
$update_stmt->execute();

// Create session
session_regenerate_id(true);
$_SESSION['user_id'] = $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['email'] = $user['email'];
$_SESSION['full_name'] = $user['full_name'];
$_SESSION['login_time'] = time();
$_SESSION['ip_address'] = $_SERVER['REMOTE_ADDR'];

http_response_code(200);
echo json_encode(array(
    "message" => "Login successful",
    "user" => array(
        "id" => $user['id'],
        "username" => $user['username'],
        "email" => $user['email'],
        "full_name" => $user['full_name']
    ),
    "session_id" => session_id()
));
?>