<?php
/**
 * User Controller - Handles HTTP requests and responses
 */
require_once __DIR__ . '/../models/User.php';

class UserController {
    private $user;
    
    public function __construct() {
        $this->user = new User();
    }
    
    // Set response headers for JSON
    private function setHeaders() {
        header("Content-Type: application/json");
        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
        header("Access-Control-Allow-Headers: Content-Type");
    }
    
    // Send JSON response
    private function sendResponse($success, $data = null, $message = null, $code = 200) {
        http_response_code($code);
        echo json_encode([
            'success' => $success,
            'data' => $data,
            'message' => $message,
            'timestamp' => date('Y-m-d H:i:s')
        ]);
        exit;
    }
    
    // Create user
    public function create() {
        $this->setHeaders();
        
        try {
            // Get raw input
            $input = json_decode(file_get_contents("php://input"), true);
            
            // Validate required fields
            if (!isset($input['name']) || empty($input['name'])) {
                $this->sendResponse(false, null, 'Name is required', 400);
            }
            
            if (!isset($input['email']) || !filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
                $this->sendResponse(false, null, 'Valid email is required', 400);
            }
            
            // Assign values
            $this->user->name = $input['name'];
            $this->user->email = $input['email'];
            $this->user->age = $input['age'] ?? null;
            $this->user->phone = $input['phone'] ?? null;
            $this->user->address = $input['address'] ?? null;
            
            // Create user
            if ($this->user->create()) {
                $this->sendResponse(true, [
                    'id' => $this->user->id,
                    'name' => $this->user->name,
                    'email' => $this->user->email
                ], 'User created successfully', 201);
            } else {
                $this->sendResponse(false, null, 'Failed to create user', 500);
            }
        } catch(Exception $e) {
            $this->sendResponse(false, null, $e->getMessage(), 400);
        }
    }
    
    // Get all users
    public function getAll() {
        $this->setHeaders();
        
        try {
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
            
            $result = $this->user->getAll($page, $limit);
            $this->sendResponse(true, $result, 'Users retrieved successfully');
        } catch(Exception $e) {
            $this->sendResponse(false, null, 'Failed to retrieve users: ' . $e->getMessage(), 500);
        }
    }
    
    // Get single user
    public function getOne($id) {
        $this->setHeaders();
        
        try {
            $user = $this->user->getById($id);
            
            if ($user) {
                $this->sendResponse(true, $user, 'User retrieved successfully');
            } else {
                $this->sendResponse(false, null, 'User not found', 404);
            }
        } catch(Exception $e) {
            $this->sendResponse(false, null, 'Failed to retrieve user: ' . $e->getMessage(), 500);
        }
    }
    
    // Update user
    public function update($id) {
        $this->setHeaders();
        
        try {
            // Check if user exists
            if (!$this->user->getById($id)) {
                $this->sendResponse(false, null, 'User not found', 404);
            }
            
            // Get raw input
            $input = json_decode(file_get_contents("php://input"), true);
            
            // Assign values
            $this->user->id = $id;
            $this->user->name = $input['name'] ?? $this->user->name;
            $this->user->email = $input['email'] ?? $this->user->email;
            $this->user->age = $input['age'] ?? $this->user->age;
            $this->user->phone = $input['phone'] ?? $this->user->phone;
            $this->user->address = $input['address'] ?? $this->user->address;
            
            // Update user
            if ($this->user->update()) {
                $updatedUser = $this->user->getById($id);
                $this->sendResponse(true, $updatedUser, 'User updated successfully');
            } else {
                $this->sendResponse(false, null, 'Failed to update user', 500);
            }
        } catch(Exception $e) {
            $this->sendResponse(false, null, $e->getMessage(), 400);
        }
    }
    
    // Delete user
    public function delete($id) {
        $this->setHeaders();
        
        try {
            // Check if user exists
            if (!$this->user->getById($id)) {
                $this->sendResponse(false, null, 'User not found', 404);
            }
            
            $this->user->id = $id;
            
            if ($this->user->delete()) {
                $this->sendResponse(true, null, 'User deleted successfully');
            } else {
                $this->sendResponse(false, null, 'Failed to delete user', 500);
            }
        } catch(Exception $e) {
            $this->sendResponse(false, null, 'Failed to delete user: ' . $e->getMessage(), 500);
        }
    }
    
    // Search users
    public function search() {
        $this->setHeaders();
        
        try {
            $keyword = $_GET['q'] ?? '';
            
            if (empty($keyword)) {
                $this->sendResponse(false, null, 'Search keyword is required', 400);
            }
            
            $results = $this->user->search($keyword);
            $this->sendResponse(true, $results, 'Search completed');
        } catch(Exception $e) {
            $this->sendResponse(false, null, 'Search failed: ' . $e->getMessage(), 500);
        }
    }
}
?>