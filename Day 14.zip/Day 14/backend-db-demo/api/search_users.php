<?php
/**
 * API: Search users
 * Method: GET
 * Parameters: q=search_keyword
 */
require_once __DIR__ . '/../controllers/UserController.php';

$controller = new UserController();
$controller->search();
?>