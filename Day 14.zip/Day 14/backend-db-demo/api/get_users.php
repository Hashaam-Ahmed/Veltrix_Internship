<?php
/**
 * API: Get all users (paginated)
 * Method: GET
 * Parameters: page=1, limit=10
 */
require_once __DIR__ . '/../controllers/UserController.php';

$controller = new UserController();
$controller->getAll();
?>