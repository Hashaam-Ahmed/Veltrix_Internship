<?php
/**
 * API: Create new user
 * Method: POST
 * Body: { "name": "John", "email": "john@example.com", "age": 25 }
 */
require_once __DIR__ . '/../controllers/UserController.php';

$controller = new UserController();
$controller->create();
?>