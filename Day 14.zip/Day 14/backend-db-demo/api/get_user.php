<?php
/**
 * API: Get single user by ID
 * Method: GET
 * Parameter: id (in URL)
 */
require_once __DIR__ . '/../controllers/UserController.php';

$controller = new UserController();

// Get ID from URL parameter
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Valid ID is required']);
    exit;
}

$controller->getOne($id);
?>