<?php
/**
 * User Model - Handles all database operations for users
 */
require_once __DIR__ . '/../config/database.php';

class User {
    private $conn;
    private $table_name = "users";

    public $id;
    public $name;
    public $email;
    public $age;
    public $phone;
    public $address;
    public $created_at;
    public $updated_at;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Create new user
    public function create() {
        try {
            $query = "INSERT INTO " . $this->table_name . "
                      (name, email, age, phone, address)
                      VALUES (:name, :email, :age, :phone, :address)";

            $stmt = $this->conn->prepare($query);

            // Sanitize inputs
            $this->sanitizeInputs();

            // Bind values
            $stmt->bindParam(":name", $this->name);
            $stmt->bindParam(":email", $this->email);
            $stmt->bindParam(":age", $this->age);
            $stmt->bindParam(":phone", $this->phone);
            $stmt->bindParam(":address", $this->address);

            if ($stmt->execute()) {
                $this->id = $this->conn->lastInsertId();
                return true;
            }
            return false;
        } catch(PDOException $e) {
            if ($e->errorInfo[1] == 1062) { // Duplicate entry
                throw new Exception("Email already exists");
            }
            throw $e;
        }
    }

    // Get all users
    public function getAll($page = 1, $limit = 10) {
        try {
            $offset = ($page - 1) * $limit;
            $query = "SELECT * FROM " . $this->table_name . " 
                      ORDER BY created_at DESC 
                      LIMIT :limit OFFSET :offset";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":limit", $limit, PDO::PARAM_INT);
            $stmt->bindParam(":offset", $offset, PDO::PARAM_INT);
            $stmt->execute();

            $users = $stmt->fetchAll();

            // Get total count
            $countQuery = "SELECT COUNT(*) as total FROM " . $this->table_name;
            $totalStmt = $this->conn->prepare($countQuery);
            $totalStmt->execute();
            $total = $totalStmt->fetch()['total'];

            return [
                'data' => $users,
                'total' => $total,
                'page' => $page,
                'limit' => $limit,
                'total_pages' => ceil($total / $limit)
            ];
        } catch(PDOException $e) {
            throw $e;
        }
    }

    // Get single user by ID
    public function getById($id) {
        try {
            $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id LIMIT 1";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":id", $id);
            $stmt->execute();

            $user = $stmt->fetch();
            
            if ($user) {
                $this->id = $user['id'];
                $this->name = $user['name'];
                $this->email = $user['email'];
                $this->age = $user['age'];
                $this->phone = $user['phone'];
                $this->address = $user['address'];
                $this->created_at = $user['created_at'];
                $this->updated_at = $user['updated_at'];
                return $user;
            }
            return null;
        } catch(PDOException $e) {
            throw $e;
        }
    }

    // Update user
    public function update() {
        try {
            $query = "UPDATE " . $this->table_name . "
                      SET name = :name,
                          email = :email,
                          age = :age,
                          phone = :phone,
                          address = :address
                      WHERE id = :id";

            $stmt = $this->conn->prepare($query);

            $this->sanitizeInputs();

            $stmt->bindParam(":name", $this->name);
            $stmt->bindParam(":email", $this->email);
            $stmt->bindParam(":age", $this->age);
            $stmt->bindParam(":phone", $this->phone);
            $stmt->bindParam(":address", $this->address);
            $stmt->bindParam(":id", $this->id);

            return $stmt->execute();
        } catch(PDOException $e) {
            if ($e->errorInfo[1] == 1062) {
                throw new Exception("Email already exists");
            }
            throw $e;
        }
    }

    // Delete user
    public function delete() {
        try {
            $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":id", $this->id);
            return $stmt->execute();
        } catch(PDOException $e) {
            throw $e;
        }
    }

    // Search users
    public function search($keyword) {
        try {
            $query = "SELECT * FROM " . $this->table_name . "
                      WHERE name LIKE :keyword 
                      OR email LIKE :keyword 
                      OR phone LIKE :keyword
                      ORDER BY created_at DESC";

            $stmt = $this->conn->prepare($query);
            $searchTerm = "%{$keyword}%";
            $stmt->bindParam(":keyword", $searchTerm);
            $stmt->execute();

            return $stmt->fetchAll();
        } catch(PDOException $e) {
            throw $e;
        }
    }

    // Sanitize input data
    private function sanitizeInputs() {
        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->age = htmlspecialchars(strip_tags($this->age));
        $this->phone = htmlspecialchars(strip_tags($this->phone));
        $this->address = htmlspecialchars(strip_tags($this->address));
    }
}
?>