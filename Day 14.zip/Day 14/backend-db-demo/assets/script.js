// API Base URL
const API_URL = 'http://localhost/php-mysql-backend/api/';

let currentPage = 1;
let currentSearch = '';

// Load users on page load
document.addEventListener('DOMContentLoaded', () => {
    loadUsers();
    
    // Add user form submit
    document.getElementById('addUserForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        await createUser();
    });
    
    // Edit user form submit
    document.getElementById('editUserForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        await updateUser();
    });
    
    // Modal close
    document.querySelector('.close').onclick = () => {
        document.getElementById('editModal').style.display = 'none';
    };
    
    // Search on enter key
    document.getElementById('searchInput').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') searchUsers();
    });
});

// Load all users
async function loadUsers(page = 1) {
    currentPage = page;
    currentSearch = '';
    document.getElementById('searchInput').value = '';
    
    try {
        const response = await fetch(`${API_URL}get_users.php?page=${page}&limit=10`);
        const result = await response.json();
        
        if (result.success) {
            displayUsers(result.data.data);
            updatePagination(result.data.page, result.data.total_pages);
        } else {
            showError('Failed to load users');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Network error');
    }
}

// Search users
async function searchUsers() {
    const keyword = document.getElementById('searchInput').value.trim();
    if (!keyword) {
        loadUsers();
        return;
    }
    
    currentSearch = keyword;
    
    try {
        const response = await fetch(`${API_URL}search_users.php?q=${encodeURIComponent(keyword)}`);
        const result = await response.json();
        
        if (result.success) {
            displayUsers(result.data);
            document.getElementById('pageInfo').innerHTML = 'Search Results';
        } else {
            showError('Search failed');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Network error');
    }
}

// Create user
async function createUser() {
    const userData = {
        name: document.getElementById('name').value,
        email: document.getElementById('email').value,
        age: document.getElementById('age').value,
        phone: document.getElementById('phone').value,
        address: document.getElementById('address').value
    };
    
    try {
        const response = await fetch(`${API_URL}create_user.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('✅ User created successfully!');
            document.getElementById('addUserForm').reset();
            loadUsers();
        } else {
            alert('❌ Error: ' + result.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Network error');
    }
}

// Edit user (show modal)
async function editUser(id) {
    try {
        const response = await fetch(`${API_URL}get_user.php?id=${id}`);
        const result = await response.json();
        
        if (result.success) {
            const user = result.data;
            document.getElementById('editId').value = user.id;
            document.getElementById('editName').value = user.name;
            document.getElementById('editEmail').value = user.email;
            document.getElementById('editAge').value = user.age;
            document.getElementById('editPhone').value = user.phone;
            document.getElementById('editAddress').value = user.address;
            document.getElementById('editModal').style.display = 'block';
        } else {
            alert('User not found');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Failed to load user data');
    }
}

// Update user
async function updateUser() {
    const id = document.getElementById('editId').value;
    const userData = {
        name: document.getElementById('editName').value,
        email: document.getElementById('editEmail').value,
        age: document.getElementById('editAge').value,
        phone: document.getElementById('editPhone').value,
        address: document.getElementById('editAddress').value
    };
    
    try {
        const response = await fetch(`${API_URL}update_user.php?id=${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('✅ User updated successfully!');
            document.getElementById('editModal').style.display = 'none';
            loadUsers(currentPage);
        } else {
            alert('❌ Error: ' + result.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Network error');
    }
}

// Delete user
async function deleteUser(id) {
    if (confirm('Are you sure you want to delete this user?')) {
        try {
            const response = await fetch(`${API_URL}delete_user.php?id=${id}`, {
                method: 'DELETE'
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert('✅ User deleted successfully!');
                loadUsers(currentPage);
            } else {
                alert('❌ Error: ' + result.message);
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Network error');
        }
    }
}

// Display users in the UI
function displayUsers(users) {
    const usersList = document.getElementById('usersList');
    
    if (!users || users.length === 0) {
        usersList.innerHTML = '<div class="loading">No users found</div>';
        return;
    }
    
    usersList.innerHTML = users.map(user => `
        <div class="user-item">
            <div class="user-info">
                <h3>${escapeHtml(user.name)}</h3>
                <p>📧 ${escapeHtml(user.email)}</p>
                ${user.age ? `<p>🎂 Age: ${user.age}</p>` : ''}
                ${user.phone ? `<p>📱 ${escapeHtml(user.phone)}</p>` : ''}
                ${user.address ? `<p>📍 ${escapeHtml(user.address)}</p>` : ''}
                <small>📅 Joined: ${new Date(user.created_at).toLocaleDateString()}</small>
            </div>
            <div class="user-actions">
                <button onclick="editUser(${user.id})" class="btn btn-warning btn-small">✏️ Edit</button>
                <button onclick="deleteUser(${user.id})" class="btn btn-danger btn-small">🗑️ Delete</button>
            </div>
        </div>
    `).join('');
}

// Update pagination controls
function updatePagination(currentPage, totalPages) {
    const pageInfo = document.getElementById('pageInfo');
    
    if (currentSearch) {
        pageInfo.innerHTML = `Search Results`;
    } else {
        pageInfo.innerHTML = `Page ${currentPage} of ${totalPages}`;
    }
    
    // Update button states
    const prevBtn = document.querySelector('.pagination-controls button:first-child');
    const nextBtn = document.querySelector('.pagination-controls button:last-child');
    
    if (prevBtn) prevBtn.disabled = currentPage <= 1;
    if (nextBtn) nextBtn.disabled = currentPage >= totalPages;
}

// Pagination functions
function previousPage() {
    if (currentPage > 1 && !currentSearch) {
        loadUsers(currentPage - 1);
    }
}

function nextPage() {
    if (!currentSearch) {
        loadUsers(currentPage + 1);
    }
}

// Show error message
function showError(message) {
    const usersList = document.getElementById('usersList');
    usersList.innerHTML = `<div class="loading" style="color: #f56565;">❌ ${message}</div>`;
}

// Helper function to escape HTML
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Optional: Add loading spinner
function showLoading() {
    const usersList = document.getElementById('usersList');
    usersList.innerHTML = '<div class="loading"><div class="spinner"></div> Loading users...</div>';
}

// Optional: Add toast notifications
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    toast.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: ${type === 'success' ? '#48bb78' : '#f56565'};
        color: white;
        padding: 12px 24px;
        border-radius: 8px;
        z-index: 1000;
        animation: slideIn 0.3s ease;
    `;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// Add keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl + N to focus on name field
    if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        document.getElementById('name').focus();
    }
    // Ctrl + S to search
    if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        document.getElementById('searchInput').focus();
    }
    // Escape to close modal
    if (e.key === 'Escape') {
        document.getElementById('editModal').style.display = 'none';
    }
});

// Add refresh button functionality
function addRefreshButton() {
    const refreshBtn = document.createElement('button');
    refreshBtn.innerHTML = '🔄 Refresh';
    refreshBtn.className = 'btn btn-secondary';
    refreshBtn.onclick = () => loadUsers(currentPage);
    document.querySelector('.pagination-controls').appendChild(refreshBtn);
}

// Auto-refresh every 30 seconds (optional)
let autoRefreshInterval;
function startAutoRefresh() {
    autoRefreshInterval = setInterval(() => {
        if (!currentSearch) {
            loadUsers(currentPage);
        }
    }, 30000);
}

function stopAutoRefresh() {
    if (autoRefreshInterval) {
        clearInterval(autoRefreshInterval);
    }
}

// Form validation before submit
function validateUserData(userData) {
    if (!userData.name || userData.name.trim().length < 2) {
        showToast('Name must be at least 2 characters', 'error');
        return false;
    }
    
    if (!userData.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(userData.email)) {
        showToast('Please enter a valid email address', 'error');
        return false;
    }
    
    if (userData.age && (userData.age < 0 || userData.age > 150)) {
        showToast('Age must be between 0 and 150', 'error');
        return false;
    }
    
    if (userData.phone && !/^[\d\+\-\(\)\s]+$/.test(userData.phone)) {
        showToast('Please enter a valid phone number', 'error');
        return false;
    }
    
    return true;
}

// Enhanced createUser with validation
async function createUser() {
    const userData = {
        name: document.getElementById('name').value.trim(),
        email: document.getElementById('email').value.trim(),
        age: document.getElementById('age').value,
        phone: document.getElementById('phone').value.trim(),
        address: document.getElementById('address').value.trim()
    };
    
    if (!validateUserData(userData)) {
        return;
    }
    
    showLoading();
    
    try {
        const response = await fetch(`${API_URL}create_user.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            showToast('✅ User created successfully!', 'success');
            document.getElementById('addUserForm').reset();
            loadUsers();
        } else {
            showToast('❌ Error: ' + result.message, 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showToast('Network error - Could not create user', 'error');
    }
}

// Enhanced deleteUser with undo functionality
let lastDeletedUser = null;

async function deleteUser(id, userName = '') {
    if (confirm(`Are you sure you want to delete ${userName ? userName : 'this user'}?`)) {
        try {
            // Store for potential undo
            const response = await fetch(`${API_URL}get_user.php?id=${id}`);
            const result = await response.json();
            if (result.success) {
                lastDeletedUser = result.data;
            }
            
            const deleteResponse = await fetch(`${API_URL}delete_user.php?id=${id}`, {
                method: 'DELETE'
            });
            
            const deleteResult = await deleteResponse.json();
            
            if (deleteResult.success) {
                showToast('✅ User deleted successfully!', 'success');
                
                // Show undo button
                const undoButton = document.createElement('button');
                undoButton.textContent = '↩️ Undo';
                undoButton.style.cssText = `
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    background: #667eea;
                    color: white;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 8px;
                    cursor: pointer;
                    z-index: 1000;
                `;
                undoButton.onclick = async () => {
                    if (lastDeletedUser) {
                        await restoreUser(lastDeletedUser);
                        undoButton.remove();
                    }
                };
                document.body.appendChild(undoButton);
                setTimeout(() => undoButton.remove(), 5000);
                
                loadUsers(currentPage);
            } else {
                showToast('❌ Error: ' + deleteResult.message, 'error');
            }
        } catch (error) {
            console.error('Error:', error);
            showToast('Network error - Could not delete user', 'error');
        }
    }
}

// Restore deleted user
async function restoreUser(user) {
    try {
        const response = await fetch(`${API_URL}create_user.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                name: user.name,
                email: user.email,
                age: user.age,
                phone: user.phone,
                address: user.address
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showToast('✅ User restored successfully!', 'success');
            loadUsers(currentPage);
        } else {
            showToast('❌ Failed to restore user', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showToast('Network error - Could not restore user', 'error');
    }
}

// Export users to CSV
async function exportUsersToCSV() {
    try {
        const response = await fetch(`${API_URL}get_users.php?page=1&limit=1000`);
        const result = await response.json();
        
        if (result.success && result.data.data) {
            const users = result.data.data;
            
            // Create CSV content
            const headers = ['ID', 'Name', 'Email', 'Age', 'Phone', 'Address', 'Created At'];
            const csvRows = [headers];
            
            for (const user of users) {
                csvRows.push([
                    user.id,
                    user.name,
                    user.email,
                    user.age || '',
                    user.phone || '',
                    user.address || '',
                    user.created_at
                ]);
            }
            
            const csvContent = csvRows.map(row => row.join(',')).join('\n');
            const blob = new Blob([csvContent], { type: 'text/csv' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `users_export_${new Date().toISOString().split('T')[0]}.csv`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            showToast('✅ Users exported successfully!', 'success');
        }
    } catch (error) {
        console.error('Error:', error);
        showToast('Failed to export users', 'error');
    }
}

// Add export button to UI
function addExportButton() {
    const exportBtn = document.createElement('button');
    exportBtn.innerHTML = '📥 Export CSV';
    exportBtn.className = 'btn btn-primary';
    exportBtn.onclick = exportUsersToCSV;
    exportBtn.style.marginLeft = '10px';
    document.querySelector('.pagination-controls').appendChild(exportBtn);
}

// Display statistics
async function loadStatistics() {
    try {
        const response = await fetch(`${API_URL}get_stats.php`);
        const result = await response.json();
        
        if (result.success) {
            const stats = result.data;
            const statsHtml = `
                <div class="stats-container">
                    <div class="stat-box">
                        <div class="stat-value">${stats.total_users}</div>
                        <div class="stat-label">Total Users</div>
                    </div>
                    <div class="stat-box">
                        <div class="stat-value">${stats.average_age || 0}</div>
                        <div class="stat-label">Average Age</div>
                    </div>
                    <div class="stat-box">
                        <div class="stat-value">${stats.users_today}</div>
                        <div class="stat-label">Joined Today</div>
                    </div>
                </div>
            `;
            
            // Add stats to the top of the page
            const container = document.querySelector('.container');
            if (container && !document.querySelector('.stats-container')) {
                container.insertAdjacentHTML('afterbegin', statsHtml);
            }
        }
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// Add CSS for new elements
function addStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-box {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .stat-value {
            font-size: 36px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .stat-label {
            font-size: 14px;
            opacity: 0.9;
        }
        
        .spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(0,0,0,.1);
            border-radius: 50%;
            border-top-color: #667eea;
            animation: spin 1s ease-in-out infinite;
            margin-right: 10px;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        .toast {
            animation: slideIn 0.3s ease;
        }
        
        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .btn:disabled:hover {
            transform: none;
        }
    `;
    document.head.appendChild(style);
}

// Initialize all features
document.addEventListener('DOMContentLoaded', () => {
    addStyles();
    loadUsers();
    loadStatistics();
    addExportButton();
    addRefreshButton();
    startAutoRefresh();
    
    // Add user form submit
    document.getElementById('addUserForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        await createUser();
    });
    
    // Edit user form submit
    document.getElementById('editUserForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        await updateUser();
    });
    
    // Modal close
    document.querySelector('.close').onclick = () => {
        document.getElementById('editModal').style.display = 'none';
    };
    
    // Search on enter key
    document.getElementById('searchInput').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') searchUsers();
    });
    
    // Clear search button
    const clearSearchBtn = document.createElement('button');
    clearSearchBtn.innerHTML = '✖️ Clear';
    clearSearchBtn.className = 'btn btn-secondary';
    clearSearchBtn.onclick = () => {
        document.getElementById('searchInput').value = '';
        loadUsers();
    };
    document.querySelector('.search-bar').appendChild(clearSearchBtn);
});

// Handle offline mode
window.addEventListener('online', () => {
    showToast('Back online! Refreshing data...', 'success');
    loadUsers(currentPage);
});

window.addEventListener('offline', () => {
    showToast('You are offline. Some features may not work.', 'error');
});

// Add dark mode toggle (optional)
function addDarkModeToggle() {
    const toggle = document.createElement('button');
    toggle.innerHTML = '🌙 Dark Mode';
    toggle.className = 'btn btn-secondary';
    toggle.style.position = 'fixed';
    toggle.style.top = '20px';
    toggle.style.right = '20px';
    toggle.onclick = () => {
        document.body.classList.toggle('dark-mode');
        const isDark = document.body.classList.contains('dark-mode');
        toggle.innerHTML = isDark ? '☀️ Light Mode' : '🌙 Dark Mode';
        localStorage.setItem('darkMode', isDark);
    };
    
    // Load saved preference
    if (localStorage.getItem('darkMode') === 'true') {
        document.body.classList.add('dark-mode');
        toggle.innerHTML = '☀️ Light Mode';
    }
    
    document.body.appendChild(toggle);
}

// Dark mode styles
const darkModeStyles = `
    body.dark-mode {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    }
    
    body.dark-mode .card {
        background: #2d2d3d;
        color: #fff;
    }
    
    body.dark-mode .card h2 {
        color: #fff;
    }
    
    body.dark-mode .user-item {
        background: #3d3d4d;
        color: #fff;
    }
    
    body.dark-mode .user-info p {
        color: #ccc;
    }
    
    body.dark-mode input,
    body.dark-mode textarea {
        background: #3d3d4d;
        color: #fff;
        border-color: #5d5d6d;
    }
    
    body.dark-mode .stat-box {
        background: linear-gradient(135deg, #16213e 0%, #1a1a2e 100%);
    }
`;

// Add dark mode styles
const darkStyle = document.createElement('style');
darkStyle.textContent = darkModeStyles;
document.head.appendChild(darkStyle);

// Call after DOM load
document.addEventListener('DOMContentLoaded', addDarkModeToggle);

console.log('✅ Application fully loaded and ready!');