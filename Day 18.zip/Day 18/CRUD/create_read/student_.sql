From: <Saved by Blink>
Snapshot-Content-Location: http://localhost/phpmyadmin/index.php?route=/server/sql
Subject: localhost / 127.0.0.1 | phpMyAdmin 5.2.1
Date: Sun, 5 Oct 2025 11:46:41 +0500
MIME-Version: 1.0
Content-Type: multipart/related;
	type="text/html";
	boundary="----MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----"


------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: text/html
Content-ID: <frame-81BC6B6BB6D3FBAE09BEB707972BAA2D@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: http://localhost/phpmyadmin/index.php?route=/server/sql

<!DOCTYPE html><html lang=3D"en" dir=3D"ltr"><head><meta http-equiv=3D"Cont=
ent-Type" content=3D"text/html; charset=3DUTF-8"><link rel=3D"stylesheet" t=
ype=3D"text/css" href=3D"cid:css-9a16203a-d41e-4183-bb61-b6a306639b29@mhtml=
.blink" />
 =20
  <meta name=3D"viewport" content=3D"width=3Ddevice-width, initial-scale=3D=
1">
  <meta name=3D"referrer" content=3D"no-referrer">
  <meta name=3D"robots" content=3D"noindex,nofollow,notranslate">
  <meta name=3D"google" content=3D"notranslate">
 =20
  <link rel=3D"icon" href=3D"http://localhost/phpmyadmin/favicon.ico" type=
=3D"image/x-icon">
  <link rel=3D"shortcut icon" href=3D"http://localhost/phpmyadmin/favicon.i=
co" type=3D"image/x-icon">
  <link rel=3D"stylesheet" type=3D"text/css" href=3D"http://localhost/phpmy=
admin/themes/pmahomme/jquery/jquery-ui.css">
  <link rel=3D"stylesheet" type=3D"text/css" href=3D"http://localhost/phpmy=
admin/js/vendor/codemirror/lib/codemirror.css?v=3D5.2.1">
  <link rel=3D"stylesheet" type=3D"text/css" href=3D"http://localhost/phpmy=
admin/js/vendor/codemirror/addon/hint/show-hint.css?v=3D5.2.1">
  <link rel=3D"stylesheet" type=3D"text/css" href=3D"http://localhost/phpmy=
admin/js/vendor/codemirror/addon/lint/lint.css?v=3D5.2.1">
  <link rel=3D"stylesheet" type=3D"text/css" href=3D"http://localhost/phpmy=
admin/themes/pmahomme/css/theme.css?v=3D5.2.1">
  <title>localhost / 127.0.0.1 | phpMyAdmin 5.2.1</title>
   =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20
 =20



 =20
</head>
<body data-new-gr-c-s-check-loaded=3D"14.1256.0" data-gr-ext-installed=3D""=
 style=3D"margin-bottom: 21.3861px; margin-left: 240px; padding-top: 59.863=
9px;">
    <div id=3D"pma_navigation" class=3D"d-print-none" data-config-navigatio=
n-width=3D"240" style=3D"width: 240px;">
    <div id=3D"pma_navigation_resizer" style=3D"left: 240px; width: 3px;"><=
/div>
    <div id=3D"pma_navigation_collapser" title=3D"Hide panel" style=3D"left=
: 240px;">=E2=86=90</div>
    <div id=3D"pma_navigation_content">
      <div id=3D"pma_navigation_header">

                  <div id=3D"pmalogo">
                          <a href=3D"http://localhost/phpmyadmin/index.php"=
>
                                      <img id=3D"imgpmalogo" src=3D"http://=
localhost/phpmyadmin/themes/pmahomme/img/logo_left.png" alt=3D"phpMyAdmin">
                                      </a>
                      </div>
       =20
        <div id=3D"navipanellinks">
          <a href=3D"http://localhost/phpmyadmin/index.php?route=3D/" title=
=3D"Home"><img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"=
Home" alt=3D"Home" class=3D"icon ic_b_home"></a>

                      <a class=3D"logout disableAjax" href=3D"http://localh=
ost/phpmyadmin/index.php?route=3D/logout" title=3D"Empty session data"><img=
 src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Empty session =
data" alt=3D"Empty session data" class=3D"icon ic_s_loggoff"></a>
         =20
          <a href=3D"http://localhost/phpmyadmin/doc/html/index.html" title=
=3D"phpMyAdmin documentation" target=3D"_blank" rel=3D"noopener noreferrer"=
><img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"phpMyAdmi=
n documentation" alt=3D"phpMyAdmin documentation" class=3D"icon ic_b_docs">=
</a>

          <a href=3D"http://localhost/phpmyadmin/url.php?url=3Dhttps%3A%2F%=
2Fmariadb.com%2Fkb%2Fen%2Fdocumentation%2F" title=3D"MariaDB Documentation"=
 target=3D"_blank" rel=3D"noopener noreferrer"><img src=3D"http://localhost=
/phpmyadmin/themes/dot.gif" title=3D"MariaDB Documentation" alt=3D"MariaDB =
Documentation" class=3D"icon ic_b_sqlhelp"></a>

          <a id=3D"pma_navigation_settings_icon" href=3D"http://localhost/p=
hpmyadmin/index.php?route=3D/server/sql#" title=3D"Navigation panel setting=
s"><img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Navigat=
ion panel settings" alt=3D"Navigation panel settings" class=3D"icon ic_s_co=
g"></a>

          <a id=3D"pma_navigation_reload" href=3D"http://localhost/phpmyadm=
in/index.php?route=3D/server/sql#" title=3D"Reload navigation panel"><img s=
rc=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Reload navigatio=
n panel" alt=3D"Reload navigation panel" class=3D"icon ic_s_reload"></a>
        </div>

       =20
        <img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Lo=
ading=E2=80=A6" alt=3D"Loading=E2=80=A6" style=3D"visibility: hidden; displ=
ay:none" class=3D"icon ic_ajax_clock_small throbber">
      </div>
      <div id=3D"pma_navigation_tree" class=3D"list_container synced highli=
ght autoexpand" style=3D"height: 954.587px;">
  <div class=3D"pma_quick_warp">
    <div class=3D"drop_list"><button title=3D"Recent tables" class=3D"drop_=
button btn">Recent</button><ul id=3D"pma_recent_list"><li class=3D"warp_lin=
k">
            There are no recent tables.    </li>
</ul></div>    <div class=3D"drop_list"><button title=3D"Favorite tables" c=
lass=3D"drop_button btn">Favorites</button><ul id=3D"pma_favorite_list"><li=
 class=3D"warp_link">
            There are no favorite tables.    </li>
</ul></div>    <div class=3D"clearfloat"></div>
</div>


<div class=3D"clearfloat"></div>

<ul>
 =20
  <!-- CONTROLS START -->
<li id=3D"navigation_controls_outer">
    <div id=3D"navigation_controls">
        <a href=3D"http://localhost/phpmyadmin/index.php?route=3D/server/sq=
l#" id=3D"pma_navigation_collapse" title=3D"Collapse all"><img src=3D"http:=
//localhost/phpmyadmin/themes/dot.gif" title=3D"Collapse all" alt=3D"Collap=
se all" class=3D"icon ic_s_collapseall"></a>
        <a href=3D"http://localhost/phpmyadmin/index.php?route=3D/server/sq=
l#" id=3D"pma_navigation_sync" title=3D"Unlink from main panel"><img src=3D=
"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Unlink from main pane=
l" alt=3D"Unlink from main panel" class=3D"icon ic_s_link"></a>
    </div>
</li>
<!-- CONTROLS ENDS -->

</ul>



<div id=3D"pma_navigation_tree_content" style=3D"height: 898.953px;">
  <ul>
      <li class=3D"first new_database italics">
    <div class=3D"block">
      <i class=3D"first"></i>
          </div>
   =20
          <div class=3D"block second">
                  <a href=3D"http://localhost/phpmyadmin/index.php?route=3D=
/server/databases"><img src=3D"http://localhost/phpmyadmin/themes/dot.gif" =
title=3D"New" alt=3D"New" class=3D"icon ic_b_newdb"></a>
              </div>

              <a class=3D"hover_show_full" href=3D"http://localhost/phpmyad=
min/index.php?route=3D/server/databases" title=3D"New">New</a>
         =20
   =20

   =20
    <div class=3D"clearfloat"></div>



  </li>
  <li class=3D"database">
    <div class=3D"block">
      <i></i>
              <b></b>
        <a class=3D"expander" href=3D"http://localhost/phpmyadmin/index.php=
?route=3D/server/sql#">
          <span class=3D"hide paths_nav" data-apath=3D"cm9vdA=3D=3D.aW5mb3J=
tYXRpb25fc2NoZW1h" data-vpath=3D"cm9vdA=3D=3D.aW5mb3JtYXRpb25fc2NoZW1h" dat=
a-pos=3D"0"></span>
                    <img src=3D"http://localhost/phpmyadmin/themes/dot.gif"=
 title=3D"Expand/Collapse" alt=3D"Expand/Collapse" class=3D"icon ic_b_plus"=
>
        </a>
          </div>
   =20
          <div class=3D"block second">
                  <a href=3D"http://localhost/phpmyadmin/index.php?route=3D=
/database/operations&amp;db=3Dinformation_schema"><img src=3D"http://localh=
ost/phpmyadmin/themes/dot.gif" title=3D"Database operations" alt=3D"Databas=
e operations" class=3D"icon ic_s_db"></a>
              </div>

              <a class=3D"hover_show_full" href=3D"http://localhost/phpmyad=
min/index.php?route=3D/database/structure&amp;db=3Dinformation_schema" titl=
e=3D"Structure">information_schema</a>
         =20
   =20

   =20
    <div class=3D"clearfloat"></div>



  </li>
  <li class=3D"database">
    <div class=3D"block">
      <i></i>
              <b></b>
        <a class=3D"expander" href=3D"http://localhost/phpmyadmin/index.php=
?route=3D/server/sql#">
          <span class=3D"hide paths_nav" data-apath=3D"cm9vdA=3D=3D.bXlzcWw=
=3D" data-vpath=3D"cm9vdA=3D=3D.bXlzcWw=3D" data-pos=3D"0"></span>
                    <img src=3D"http://localhost/phpmyadmin/themes/dot.gif"=
 title=3D"Expand/Collapse" alt=3D"Expand/Collapse" class=3D"icon ic_b_plus"=
>
        </a>
          </div>
   =20
          <div class=3D"block second">
                  <a href=3D"http://localhost/phpmyadmin/index.php?route=3D=
/database/operations&amp;db=3Dmysql"><img src=3D"http://localhost/phpmyadmi=
n/themes/dot.gif" title=3D"Database operations" alt=3D"Database operations"=
 class=3D"icon ic_s_db"></a>
              </div>

              <a class=3D"hover_show_full" href=3D"http://localhost/phpmyad=
min/index.php?route=3D/database/structure&amp;db=3Dmysql" title=3D"Structur=
e">mysql</a>
         =20
   =20

   =20
    <div class=3D"clearfloat"></div>



  </li>
  <li class=3D"database">
    <div class=3D"block">
      <i></i>
              <b></b>
        <a class=3D"expander" href=3D"http://localhost/phpmyadmin/index.php=
?route=3D/server/sql#">
          <span class=3D"hide paths_nav" data-apath=3D"cm9vdA=3D=3D.cGVyZm9=
ybWFuY2Vfc2NoZW1h" data-vpath=3D"cm9vdA=3D=3D.cGVyZm9ybWFuY2Vfc2NoZW1h" dat=
a-pos=3D"0"></span>
                    <img src=3D"http://localhost/phpmyadmin/themes/dot.gif"=
 title=3D"Expand/Collapse" alt=3D"Expand/Collapse" class=3D"icon ic_b_plus"=
>
        </a>
          </div>
   =20
          <div class=3D"block second">
                  <a href=3D"http://localhost/phpmyadmin/index.php?route=3D=
/database/operations&amp;db=3Dperformance_schema"><img src=3D"http://localh=
ost/phpmyadmin/themes/dot.gif" title=3D"Database operations" alt=3D"Databas=
e operations" class=3D"icon ic_s_db"></a>
              </div>

              <a class=3D"hover_show_full" href=3D"http://localhost/phpmyad=
min/index.php?route=3D/database/structure&amp;db=3Dperformance_schema" titl=
e=3D"Structure">performance_schema</a>
         =20
   =20

   =20
    <div class=3D"clearfloat"></div>



  </li>
  <li class=3D"database">
    <div class=3D"block">
      <i></i>
              <b></b>
        <a class=3D"expander" href=3D"http://localhost/phpmyadmin/index.php=
?route=3D/server/sql#">
          <span class=3D"hide paths_nav" data-apath=3D"cm9vdA=3D=3D.cGhwbXl=
hZG1pbg=3D=3D" data-vpath=3D"cm9vdA=3D=3D.cGhwbXlhZG1pbg=3D=3D" data-pos=3D=
"0"></span>
                    <img src=3D"http://localhost/phpmyadmin/themes/dot.gif"=
 title=3D"Expand/Collapse" alt=3D"Expand/Collapse" class=3D"icon ic_b_plus"=
>
        </a>
          </div>
   =20
          <div class=3D"block second">
                  <a href=3D"http://localhost/phpmyadmin/index.php?route=3D=
/database/operations&amp;db=3Dphpmyadmin"><img src=3D"http://localhost/phpm=
yadmin/themes/dot.gif" title=3D"Database operations" alt=3D"Database operat=
ions" class=3D"icon ic_s_db"></a>
              </div>

              <a class=3D"hover_show_full" href=3D"http://localhost/phpmyad=
min/index.php?route=3D/database/structure&amp;db=3Dphpmyadmin" title=3D"Str=
ucture">phpmyadmin</a>
         =20
   =20

   =20
    <div class=3D"clearfloat"></div>



  </li>
  <li class=3D"navGroup">
    <div class=3D"block">
      <i></i>
              <b></b>
        <a class=3D"expander loaded container" href=3D"http://localhost/php=
myadmin/index.php?route=3D/server/sql#">
          <span class=3D"hide paths_nav" data-apath=3D"cm9vdA=3D=3D" data-v=
path=3D"cm9vdA=3D=3D.c3R1ZGVudA=3D=3D" data-pos=3D"0"></span>
                    <img src=3D"http://localhost/phpmyadmin/themes/dot.gif"=
 title=3D"Expand/Collapse" alt=3D"Expand/Collapse" class=3D"icon ic_b_plus"=
>
        </a>
          </div>
          <div class=3D"fst-italic">
   =20
          <div class=3D"block second">
        <u><img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D=
"Groups" alt=3D"Groups" class=3D"icon ic_b_group"></u>
      </div>
      &nbsp;student
   =20
   =20

          </div>
   =20
    <div class=3D"clearfloat"></div>

  <div class=3D"list_container" style=3D"display: none;">
    <ul>
  <li class=3D"database database">
    <div class=3D"block">
      <i></i>
              <b></b>
        <a class=3D"expander" href=3D"http://localhost/phpmyadmin/index.php=
?route=3D/server/sql#">
          <span class=3D"hide paths_nav" data-apath=3D"cm9vdA=3D=3D.c3R1ZGV=
udA=3D=3D" data-vpath=3D"cm9vdA=3D=3D.c3R1ZGVudA=3D=3D." data-pos=3D"0"></s=
pan>
                    <img src=3D"http://localhost/phpmyadmin/themes/dot.gif"=
 title=3D"Expand/Collapse" alt=3D"Expand/Collapse" class=3D"icon ic_b_plus"=
>
        </a>
          </div>
   =20
          <div class=3D"block second">
                  <a href=3D"http://localhost/phpmyadmin/index.php?route=3D=
/database/operations&amp;db=3Dstudent"><img src=3D"http://localhost/phpmyad=
min/themes/dot.gif" title=3D"Database operations" alt=3D"Database operation=
s" class=3D"icon ic_s_db"></a>
              </div>

              <a class=3D"hover_show_full" href=3D"http://localhost/phpmyad=
min/index.php?route=3D/database/structure&amp;db=3Dstudent" title=3D"Struct=
ure">student</a>
         =20
   =20

   =20
    <div class=3D"clearfloat"></div>



  </li>
  <li class=3D"database database">
    <div class=3D"block">
      <i></i>
              <b></b>
        <a class=3D"expander" href=3D"http://localhost/phpmyadmin/index.php=
?route=3D/server/sql#">
          <span class=3D"hide paths_nav" data-apath=3D"cm9vdA=3D=3D.c3R1ZGV=
udF8=3D" data-vpath=3D"cm9vdA=3D=3D.c3R1ZGVudA=3D=3D." data-pos=3D"0"></spa=
n>
                    <img src=3D"http://localhost/phpmyadmin/themes/dot.gif"=
 title=3D"Expand/Collapse" alt=3D"Expand/Collapse" class=3D"icon ic_b_plus"=
>
        </a>
          </div>
   =20
          <div class=3D"block second">
                  <a href=3D"http://localhost/phpmyadmin/index.php?route=3D=
/database/operations&amp;db=3Dstudent_"><img src=3D"http://localhost/phpmya=
dmin/themes/dot.gif" title=3D"Database operations" alt=3D"Database operatio=
ns" class=3D"icon ic_s_db"></a>
              </div>

              <a class=3D"hover_show_full" href=3D"http://localhost/phpmyad=
min/index.php?route=3D/database/structure&amp;db=3Dstudent_" title=3D"Struc=
ture">student_</a>
         =20
   =20

   =20
    <div class=3D"clearfloat"></div>



  </li>
  <li class=3D"database last database">
    <div class=3D"block">
      <i></i>
             =20
        <a class=3D"expander" href=3D"http://localhost/phpmyadmin/index.php=
?route=3D/server/sql#">
          <span class=3D"hide paths_nav" data-apath=3D"cm9vdA=3D=3D.c3R1ZGV=
udF9t" data-vpath=3D"cm9vdA=3D=3D.c3R1ZGVudA=3D=3D.bQ=3D=3D" data-pos=3D"0"=
></span>
                    <img src=3D"http://localhost/phpmyadmin/themes/dot.gif"=
 title=3D"Expand/Collapse" alt=3D"Expand/Collapse" class=3D"icon ic_b_plus"=
>
        </a>
          </div>
   =20
          <div class=3D"block second">
                  <a href=3D"http://localhost/phpmyadmin/index.php?route=3D=
/database/operations&amp;db=3Dstudent_m"><img src=3D"http://localhost/phpmy=
admin/themes/dot.gif" title=3D"Database operations" alt=3D"Database operati=
ons" class=3D"icon ic_s_db"></a>
              </div>

              <a class=3D"hover_show_full" href=3D"http://localhost/phpmyad=
min/index.php?route=3D/database/structure&amp;db=3Dstudent_m" title=3D"Stru=
cture">student_m</a>
         =20
   =20

   =20
    <div class=3D"clearfloat"></div>



  </li>

    </ul>
  </div>

  </li>
  <li class=3D"database">
    <div class=3D"block">
      <i></i>
              <b></b>
        <a class=3D"expander" href=3D"http://localhost/phpmyadmin/index.php=
?route=3D/server/sql#">
          <span class=3D"hide paths_nav" data-apath=3D"cm9vdA=3D=3D.dGVzdA=
=3D=3D" data-vpath=3D"cm9vdA=3D=3D.dGVzdA=3D=3D" data-pos=3D"0"></span>
                    <img src=3D"http://localhost/phpmyadmin/themes/dot.gif"=
 title=3D"Expand/Collapse" alt=3D"Expand/Collapse" class=3D"icon ic_b_plus"=
>
        </a>
          </div>
   =20
          <div class=3D"block second">
                  <a href=3D"http://localhost/phpmyadmin/index.php?route=3D=
/database/operations&amp;db=3Dtest"><img src=3D"http://localhost/phpmyadmin=
/themes/dot.gif" title=3D"Database operations" alt=3D"Database operations" =
class=3D"icon ic_s_db"></a>
              </div>

              <a class=3D"hover_show_full" href=3D"http://localhost/phpmyad=
min/index.php?route=3D/database/structure&amp;db=3Dtest" title=3D"Structure=
">test</a>
         =20
   =20

   =20
    <div class=3D"clearfloat"></div>



  </li>
  <li class=3D"last database">
    <div class=3D"block">
      <i></i>
             =20
        <a class=3D"expander" href=3D"http://localhost/phpmyadmin/index.php=
?route=3D/server/sql#">
          <span class=3D"hide paths_nav" data-apath=3D"cm9vdA=3D=3D.dW5pdmV=
yc2l0eV9jb3Vyc2U=3D" data-vpath=3D"cm9vdA=3D=3D.dW5pdmVyc2l0eV9jb3Vyc2U=3D"=
 data-pos=3D"0"></span>
                    <img src=3D"http://localhost/phpmyadmin/themes/dot.gif"=
 title=3D"Expand/Collapse" alt=3D"Expand/Collapse" class=3D"icon ic_b_plus"=
>
        </a>
          </div>
   =20
          <div class=3D"block second">
                  <a href=3D"http://localhost/phpmyadmin/index.php?route=3D=
/database/operations&amp;db=3Duniversity_course"><img src=3D"http://localho=
st/phpmyadmin/themes/dot.gif" title=3D"Database operations" alt=3D"Database=
 operations" class=3D"icon ic_s_db"></a>
              </div>

              <a class=3D"hover_show_full" href=3D"http://localhost/phpmyad=
min/index.php?route=3D/database/structure&amp;db=3Duniversity_course" title=
=3D"Structure">university_course</a>
         =20
   =20

   =20
    <div class=3D"clearfloat"></div>



  </li>

  </ul>
</div>


</div>

      <div id=3D"pma_navi_settings_container">
                  <div id=3D"pma_navigation_settings"><div class=3D"page_se=
ttings"><form method=3D"post" action=3D"http://localhost/phpmyadmin/index.p=
hp?route=3D%2Fserver%2Fsql&amp;server=3D1" class=3D"config-form disableAjax=
">
 =20
     =20
   =20
 =20

  <ul class=3D"nav nav-tabs" id=3D"configFormDisplayTab" role=3D"tablist">
          <li class=3D"nav-item" role=3D"presentation">
        <a class=3D"nav-link active" id=3D"Navi_panel-tab" href=3D"http://l=
ocalhost/phpmyadmin/index.php?route=3D/server/sql#Navi_panel" data-bs-toggl=
e=3D"tab" role=3D"tab" aria-controls=3D"Navi_panel" aria-selected=3D"true">=
Navigation panel</a>
      </li>
          <li class=3D"nav-item" role=3D"presentation">
        <a class=3D"nav-link" id=3D"Navi_tree-tab" href=3D"http://localhost=
/phpmyadmin/index.php?route=3D/server/sql#Navi_tree" data-bs-toggle=3D"tab"=
 role=3D"tab" aria-controls=3D"Navi_tree" aria-selected=3D"false" tabindex=
=3D"-1">Navigation tree</a>
      </li>
          <li class=3D"nav-item" role=3D"presentation">
        <a class=3D"nav-link" id=3D"Navi_servers-tab" href=3D"http://localh=
ost/phpmyadmin/index.php?route=3D/server/sql#Navi_servers" data-bs-toggle=
=3D"tab" role=3D"tab" aria-controls=3D"Navi_servers" aria-selected=3D"false=
" tabindex=3D"-1">Servers</a>
      </li>
          <li class=3D"nav-item" role=3D"presentation">
        <a class=3D"nav-link" id=3D"Navi_databases-tab" href=3D"http://loca=
lhost/phpmyadmin/index.php?route=3D/server/sql#Navi_databases" data-bs-togg=
le=3D"tab" role=3D"tab" aria-controls=3D"Navi_databases" aria-selected=3D"f=
alse" tabindex=3D"-1">Databases</a>
      </li>
          <li class=3D"nav-item" role=3D"presentation">
        <a class=3D"nav-link" id=3D"Navi_tables-tab" href=3D"http://localho=
st/phpmyadmin/index.php?route=3D/server/sql#Navi_tables" data-bs-toggle=3D"=
tab" role=3D"tab" aria-controls=3D"Navi_tables" aria-selected=3D"false" tab=
index=3D"-1">Tables</a>
      </li>
      </ul>
  <div class=3D"tab-content">
          <div class=3D"tab-pane fade show active" id=3D"Navi_panel" role=
=3D"tabpanel" aria-labelledby=3D"Navi_panel-tab">
        <div class=3D"card border-top-0">
          <div class=3D"card-body">
            <h5 class=3D"card-title visually-hidden">Navigation panel</h5>
                          <h6 class=3D"card-subtitle mb-2 text-muted">Custo=
mize appearance of the navigation panel.</h6>
           =20
            <fieldset class=3D"optbox">
              <legend>Navigation panel</legend>

                           =20
              <table class=3D"table table-borderless">
                <tbody><tr>
  <th>
    <label for=3D"ShowDatabasesNavigationAsTree">Show databases navigation =
as tree</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Sho=
wDatabasesNavigationAsTree" target=3D"documentation"><img src=3D"http://loc=
alhost/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentat=
ion" class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>In the navigation panel, replaces the database tree with a=
 selector</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"ShowDatabasesNavigationAsTree" id=
=3D"ShowDatabasesNavigationAsTree" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#ShowDatabasesNavigationAsTree" title=3D"=
Restore default value" style=3D"display: inline-block; opacity: 0.25;"><img=
 src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore defaul=
t value" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"=
display: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationLinkWithMainPanel">Link with main panel</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationLinkWithMainPanel" target=3D"documentation"><img src=3D"http://local=
host/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentatio=
n" class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Link with main panel by highlighting the current database =
or table.</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"NavigationLinkWithMainPanel" id=3D=
"NavigationLinkWithMainPanel" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationLinkWithMainPanel" title=3D"Re=
store default value" style=3D"display: inline-block; opacity: 0.25;"><img s=
rc=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default =
value" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"di=
splay: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationDisplayLogo">Display logo</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationDisplayLogo" target=3D"documentation"><img src=3D"http://localhost/p=
hpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" cla=
ss=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Show logo in navigation panel.</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"NavigationDisplayLogo" id=3D"Navig=
ationDisplayLogo" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationDisplayLogo" title=3D"Restore =
default value" style=3D"display: inline-block; opacity: 0.25;"><img src=3D"=
http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default value"=
 alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"display:=
 none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationLogoLink">Logo link URL</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationLogoLink" target=3D"documentation"><img src=3D"http://localhost/phpm=
yadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" class=
=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>URL where logo in the navigation panel will point to.</sma=
ll>
      </th>

  <td>
          <input type=3D"text" name=3D"NavigationLogoLink" id=3D"Navigation=
LogoLink" value=3D"index.php" class=3D"w-75">
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationLogoLink" title=3D"Restore def=
ault value" style=3D"display: inline-block; opacity: 0.25;"><img src=3D"htt=
p://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default value" al=
t=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"display: no=
ne;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationLogoLinkWindow">Logo link target</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationLogoLinkWindow" target=3D"documentation"><img src=3D"http://localhos=
t/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" =
class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Open the linked page in the main window (<code>main</code>=
) or in a new one (<code>new</code>).</small>
      </th>

  <td>
          <select name=3D"NavigationLogoLinkWindow" id=3D"NavigationLogoLin=
kWindow" class=3D"w-75">
                            <option value=3D"main" selected=3D"">main</opti=
on>
                            <option value=3D"new">new</option>
              </select>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationLogoLinkWindow" title=3D"Resto=
re default value" style=3D"display: inline-block; opacity: 0.25;"><img src=
=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default va=
lue" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"disp=
lay: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationTreePointerEnable">Enable highlighting</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationTreePointerEnable" target=3D"documentation"><img src=3D"http://local=
host/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentatio=
n" class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Highlight server under the mouse cursor.</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"NavigationTreePointerEnable" id=3D=
"NavigationTreePointerEnable" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationTreePointerEnable" title=3D"Re=
store default value" style=3D"display: inline-block; opacity: 0.25;"><img s=
rc=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default =
value" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"di=
splay: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"FirstLevelNavigationItems">Maximum items on first level</=
label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Fir=
stLevelNavigationItems" target=3D"documentation"><img src=3D"http://localho=
st/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation"=
 class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>The number of items that can be displayed on each page on =
the first level of the navigation tree.</small>
      </th>

  <td>
          <input type=3D"number" name=3D"FirstLevelNavigationItems" id=3D"F=
irstLevelNavigationItems" value=3D"100" class=3D"">
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#FirstLevelNavigationItems" title=3D"Rest=
ore default value" style=3D"display: inline-block; opacity: 0.25;"><img src=
=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default va=
lue" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"disp=
lay: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationTreeDisplayItemFilterMinimum">Minimum number of=
 items to display the filter box</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationTreeDisplayItemFilterMinimum" target=3D"documentation"><img src=3D"h=
ttp://localhost/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"D=
ocumentation" class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Defines the minimum number of items (tables, views, routin=
es and events) to display a filter box.</small>
      </th>

  <td>
          <input type=3D"number" name=3D"NavigationTreeDisplayItemFilterMin=
imum" id=3D"NavigationTreeDisplayItemFilterMinimum" value=3D"30" class=3D""=
>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationTreeDisplayItemFilterMinimum" =
title=3D"Restore default value" style=3D"display: inline-block; opacity: 0.=
25;"><img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Resto=
re default value" alt=3D"Restore default value" class=3D"icon ic_s_reload" =
style=3D"display: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NumRecentTables">Recently used tables</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Num=
RecentTables" target=3D"documentation"><img src=3D"http://localhost/phpmyad=
min/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" class=3D"=
icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Maximum number of recently used tables; set 0 to disable.<=
/small>
      </th>

  <td>
          <input type=3D"number" name=3D"NumRecentTables" id=3D"NumRecentTa=
bles" value=3D"10" class=3D"">
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NumRecentTables" title=3D"Restore defaul=
t value" style=3D"display: inline-block; opacity: 0.25;"><img src=3D"http:/=
/localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default value" alt=
=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"display: non=
e;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NumFavoriteTables">Favorite tables</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Num=
FavoriteTables" target=3D"documentation"><img src=3D"http://localhost/phpmy=
admin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" class=
=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Maximum number of favorite tables; set 0 to disable.</smal=
l>
      </th>

  <td>
          <input type=3D"number" name=3D"NumFavoriteTables" id=3D"NumFavori=
teTables" value=3D"10" class=3D"">
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NumFavoriteTables" title=3D"Restore defa=
ult value" style=3D"display: inline-block; opacity: 0.25;"><img src=3D"http=
://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default value" alt=
=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"display: non=
e;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationWidth">Navigation panel width</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationWidth" target=3D"documentation"><img src=3D"http://localhost/phpmyad=
min/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" class=3D"=
icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Set to 0 to collapse navigation panel.</small>
      </th>

  <td>
          <input type=3D"number" name=3D"NavigationWidth" id=3D"NavigationW=
idth" value=3D"240" class=3D"">
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationWidth" title=3D"Restore defaul=
t value" style=3D"display: inline-block; opacity: 0.25;"><img src=3D"http:/=
/localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default value" alt=
=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"display: non=
e;"></a>
   =20
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
          <div class=3D"tab-pane fade" id=3D"Navi_tree" role=3D"tabpanel" a=
ria-labelledby=3D"Navi_tree-tab">
        <div class=3D"card border-top-0">
          <div class=3D"card-body">
            <h5 class=3D"card-title visually-hidden">Navigation tree</h5>
                          <h6 class=3D"card-subtitle mb-2 text-muted">Custo=
mize the navigation tree.</h6>
           =20
            <fieldset class=3D"optbox">
              <legend>Navigation tree</legend>

                           =20
              <table class=3D"table table-borderless">
                <tbody><tr>
  <th>
    <label for=3D"MaxNavigationItems">Maximum items in branch</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Max=
NavigationItems" target=3D"documentation"><img src=3D"http://localhost/phpm=
yadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" class=
=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>The number of items that can be displayed on each page of =
the navigation tree.</small>
      </th>

  <td>
          <input type=3D"number" name=3D"MaxNavigationItems" id=3D"MaxNavig=
ationItems" value=3D"50" class=3D"">
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#MaxNavigationItems" title=3D"Restore def=
ault value" style=3D"display: inline-block; opacity: 0.25;"><img src=3D"htt=
p://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default value" al=
t=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"display: no=
ne;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationTreeEnableGrouping">Group items in the tree</la=
bel>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationTreeEnableGrouping" target=3D"documentation"><img src=3D"http://loca=
lhost/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentati=
on" class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Group items in the navigation tree (determined by the sepa=
rator defined in the Databases and Tables tabs above).</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"NavigationTreeEnableGrouping" id=
=3D"NavigationTreeEnableGrouping" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationTreeEnableGrouping" title=3D"R=
estore default value" style=3D"display: inline-block; opacity: 0.25;"><img =
src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default=
 value" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"d=
isplay: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationTreeEnableExpansion">Enable navigation tree exp=
ansion</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationTreeEnableExpansion" target=3D"documentation"><img src=3D"http://loc=
alhost/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentat=
ion" class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Whether to offer the possibility of tree expansion in the =
navigation panel.</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"NavigationTreeEnableExpansion" id=
=3D"NavigationTreeEnableExpansion" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationTreeEnableExpansion" title=3D"=
Restore default value" style=3D"display: inline-block; opacity: 0.25;"><img=
 src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore defaul=
t value" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"=
display: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationTreeShowTables">Show tables in tree</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationTreeShowTables" target=3D"documentation"><img src=3D"http://localhos=
t/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" =
class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Whether to show tables under database in the navigation tr=
ee</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"NavigationTreeShowTables" id=3D"Na=
vigationTreeShowTables" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationTreeShowTables" title=3D"Resto=
re default value" style=3D"display: inline-block; opacity: 0.25;"><img src=
=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default va=
lue" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"disp=
lay: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationTreeShowViews">Show views in tree</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationTreeShowViews" target=3D"documentation"><img src=3D"http://localhost=
/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" c=
lass=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Whether to show views under database in the navigation tre=
e</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"NavigationTreeShowViews" id=3D"Nav=
igationTreeShowViews" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationTreeShowViews" title=3D"Restor=
e default value" style=3D"display: inline-block; opacity: 0.25;"><img src=
=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default va=
lue" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"disp=
lay: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationTreeShowFunctions">Show functions in tree</labe=
l>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationTreeShowFunctions" target=3D"documentation"><img src=3D"http://local=
host/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentatio=
n" class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Whether to show functions under database in the navigation=
 tree</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"NavigationTreeShowFunctions" id=3D=
"NavigationTreeShowFunctions" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationTreeShowFunctions" title=3D"Re=
store default value" style=3D"display: inline-block; opacity: 0.25;"><img s=
rc=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default =
value" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"di=
splay: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationTreeShowProcedures">Show procedures in tree</la=
bel>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationTreeShowProcedures" target=3D"documentation"><img src=3D"http://loca=
lhost/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentati=
on" class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Whether to show procedures under database in the navigatio=
n tree</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"NavigationTreeShowProcedures" id=
=3D"NavigationTreeShowProcedures" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationTreeShowProcedures" title=3D"R=
estore default value" style=3D"display: inline-block; opacity: 0.25;"><img =
src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default=
 value" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"d=
isplay: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationTreeShowEvents">Show events in tree</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationTreeShowEvents" target=3D"documentation"><img src=3D"http://localhos=
t/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" =
class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Whether to show events under database in the navigation tr=
ee</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"NavigationTreeShowEvents" id=3D"Na=
vigationTreeShowEvents" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationTreeShowEvents" title=3D"Resto=
re default value" style=3D"display: inline-block; opacity: 0.25;"><img src=
=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default va=
lue" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"disp=
lay: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationTreeAutoexpandSingleDb">Expand single database<=
/label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationTreeAutoexpandSingleDb" target=3D"documentation"><img src=3D"http://=
localhost/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documen=
tation" class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Whether to expand single database in the navigation tree a=
utomatically.</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"NavigationTreeAutoexpandSingleDb" =
id=3D"NavigationTreeAutoexpandSingleDb" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationTreeAutoexpandSingleDb" title=
=3D"Restore default value" style=3D"display: inline-block; opacity: 0.25;">=
<img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore de=
fault value" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=
=3D"display: none;"></a>
   =20
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
          <div class=3D"tab-pane fade" id=3D"Navi_servers" role=3D"tabpanel=
" aria-labelledby=3D"Navi_servers-tab">
        <div class=3D"card border-top-0">
          <div class=3D"card-body">
            <h5 class=3D"card-title visually-hidden">Servers</h5>
                          <h6 class=3D"card-subtitle mb-2 text-muted">Serve=
rs display options.</h6>
           =20
            <fieldset class=3D"optbox">
              <legend>Servers</legend>

                           =20
              <table class=3D"table table-borderless">
                <tbody><tr>
  <th>
    <label for=3D"NavigationDisplayServers">Display servers selection</labe=
l>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationDisplayServers" target=3D"documentation"><img src=3D"http://localhos=
t/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" =
class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Display server choice at the top of the navigation panel.<=
/small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"NavigationDisplayServers" id=3D"Na=
vigationDisplayServers" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationDisplayServers" title=3D"Resto=
re default value" style=3D"display: inline-block; opacity: 0.25;"><img src=
=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default va=
lue" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"disp=
lay: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"DisplayServersList">Display servers as a list</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Dis=
playServersList" target=3D"documentation"><img src=3D"http://localhost/phpm=
yadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" class=
=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Show server listing as a list instead of a drop down.</sma=
ll>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"DisplayServersList" id=3D"DisplayS=
erversList">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#DisplayServersList" title=3D"Restore def=
ault value" style=3D"display: inline-block; opacity: 0.25;"><img src=3D"htt=
p://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default value" al=
t=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"display: no=
ne;"></a>
   =20
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
          <div class=3D"tab-pane fade" id=3D"Navi_databases" role=3D"tabpan=
el" aria-labelledby=3D"Navi_databases-tab">
        <div class=3D"card border-top-0">
          <div class=3D"card-body">
            <h5 class=3D"card-title visually-hidden">Databases</h5>
                          <h6 class=3D"card-subtitle mb-2 text-muted">Datab=
ases display options.</h6>
           =20
            <fieldset class=3D"optbox">
              <legend>Databases</legend>

                           =20
              <table class=3D"table table-borderless">
                <tbody><tr>
  <th>
    <label for=3D"NavigationTreeDisplayDbFilterMinimum">Minimum number of d=
atabases to display the database filter box</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationTreeDisplayDbFilterMinimum" target=3D"documentation"><img src=3D"htt=
p://localhost/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Doc=
umentation" class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
      </th>

  <td>
          <input type=3D"number" name=3D"NavigationTreeDisplayDbFilterMinim=
um" id=3D"NavigationTreeDisplayDbFilterMinimum" value=3D"30" class=3D"">
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationTreeDisplayDbFilterMinimum" ti=
tle=3D"Restore default value" style=3D"display: inline-block; opacity: 0.25=
;"><img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore=
 default value" alt=3D"Restore default value" class=3D"icon ic_s_reload" st=
yle=3D"display: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationTreeDbSeparator">Database tree separator</label=
>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationTreeDbSeparator" target=3D"documentation"><img src=3D"http://localho=
st/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation"=
 class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>String that separates databases into different tree levels=
.</small>
      </th>

  <td>
                <input type=3D"text" size=3D"25" name=3D"NavigationTreeDbSe=
parator" id=3D"NavigationTreeDbSeparator" value=3D"_" class=3D"">
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationTreeDbSeparator" title=3D"Rest=
ore default value" style=3D"display: inline-block; opacity: 0.25;"><img src=
=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default va=
lue" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"disp=
lay: none;"></a>
   =20
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
          <div class=3D"tab-pane fade" id=3D"Navi_tables" role=3D"tabpanel"=
 aria-labelledby=3D"Navi_tables-tab">
        <div class=3D"card border-top-0">
          <div class=3D"card-body">
            <h5 class=3D"card-title visually-hidden">Tables</h5>
                          <h6 class=3D"card-subtitle mb-2 text-muted">Table=
s display options.</h6>
           =20
            <fieldset class=3D"optbox">
              <legend>Tables</legend>

                           =20
              <table class=3D"table table-borderless">
                <tbody><tr>
  <th>
    <label for=3D"NavigationTreeDefaultTabTable">Target for quick access ic=
on</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationTreeDefaultTabTable" target=3D"documentation"><img src=3D"http://loc=
alhost/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentat=
ion" class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
      </th>

  <td>
          <select name=3D"NavigationTreeDefaultTabTable" id=3D"NavigationTr=
eeDefaultTabTable" class=3D"w-75">
                            <option value=3D"structure" selected=3D"">Struc=
ture</option>
                            <option value=3D"sql">SQL</option>
                            <option value=3D"search">Search</option>
                            <option value=3D"insert">Insert</option>
                            <option value=3D"browse">Browse</option>
              </select>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationTreeDefaultTabTable" title=3D"=
Restore default value" style=3D"display: inline-block; opacity: 0.25;"><img=
 src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore defaul=
t value" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"=
display: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationTreeDefaultTabTable2">Target for second quick a=
ccess icon</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationTreeDefaultTabTable2" target=3D"documentation"><img src=3D"http://lo=
calhost/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documenta=
tion" class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
      </th>

  <td>
          <select name=3D"NavigationTreeDefaultTabTable2" id=3D"NavigationT=
reeDefaultTabTable2" class=3D"w-75">
                            <option value=3D"" selected=3D""></option>
                            <option value=3D"structure">Structure</option>
                            <option value=3D"sql">SQL</option>
                            <option value=3D"search">Search</option>
                            <option value=3D"insert">Insert</option>
                            <option value=3D"browse">Browse</option>
              </select>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationTreeDefaultTabTable2" title=3D=
"Restore default value" style=3D"display: inline-block; opacity: 0.25;"><im=
g src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore defau=
lt value" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D=
"display: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationTreeTableSeparator">Table tree separator</label=
>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationTreeTableSeparator" target=3D"documentation"><img src=3D"http://loca=
lhost/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentati=
on" class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>String that separates tables into different tree levels.</=
small>
      </th>

  <td>
                <input type=3D"text" size=3D"25" name=3D"NavigationTreeTabl=
eSeparator" id=3D"NavigationTreeTableSeparator" value=3D"__" class=3D"">
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationTreeTableSeparator" title=3D"R=
estore default value" style=3D"display: inline-block; opacity: 0.25;"><img =
src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default=
 value" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"d=
isplay: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"NavigationTreeTableLevel">Maximum table tree depth</label=
>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Nav=
igationTreeTableLevel" target=3D"documentation"><img src=3D"http://localhos=
t/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" =
class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
      </th>

  <td>
          <input type=3D"number" name=3D"NavigationTreeTableLevel" id=3D"Na=
vigationTreeTableLevel" value=3D"1" class=3D"">
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#NavigationTreeTableLevel" title=3D"Resto=
re default value" style=3D"display: inline-block; opacity: 0.25;"><img src=
=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default va=
lue" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"disp=
lay: none;"></a>
   =20
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
      </div>
</form>


</div></div>
              </div>
    </div>

          <div class=3D"pma_drop_handler">
        Drop files here      </div>
      <div class=3D"pma_sql_import_status">
        <h2>
          SQL upload          ( <span class=3D"pma_import_count">0</span> )
          <span class=3D"close">x</span>
          <span class=3D"minimize">-</span>
        </h2>
        <div></div>
      </div>
      </div>
  <div class=3D"modal fade" id=3D"unhideNavItemModal" tabindex=3D"-1" aria-=
labelledby=3D"unhideNavItemModalLabel" aria-hidden=3D"true">
  <div class=3D"modal-dialog">
    <div class=3D"modal-content">
      <div class=3D"modal-header">
        <h5 class=3D"modal-title" id=3D"unhideNavItemModalLabel">Show hidde=
n navigation tree items.</h5>
        <button type=3D"button" class=3D"btn-close" data-bs-dismiss=3D"moda=
l" aria-label=3D"Close"></button>
      </div>
      <div class=3D"modal-body"></div>
      <div class=3D"modal-footer">
        <button type=3D"button" class=3D"btn btn-secondary" data-bs-dismiss=
=3D"modal">Close</button>
      </div>
    </div>
  </div>
</div>

  <div class=3D"modal fade" id=3D"createViewModal" tabindex=3D"-1" aria-lab=
elledby=3D"createViewModalLabel" aria-hidden=3D"true">
  <div class=3D"modal-dialog modal-lg" id=3D"createViewModalDialog">
    <div class=3D"modal-content">
      <div class=3D"modal-header">
        <h5 class=3D"modal-title" id=3D"createViewModalLabel">Create view</=
h5>
        <button type=3D"button" class=3D"btn-close" data-bs-dismiss=3D"moda=
l" aria-label=3D"Close"></button>
      </div>
      <div class=3D"modal-body"></div>
      <div class=3D"modal-footer">
        <button type=3D"button" class=3D"btn btn-secondary" id=3D"createVie=
wModalGoButton">Go</button>
        <button type=3D"button" class=3D"btn btn-secondary" data-bs-dismiss=
=3D"modal">Close</button>
      </div>
    </div>
  </div>
</div>


 =20
 =20

 =20
     =20
 =20
      <div id=3D"floating_menubar" class=3D"d-print-none" style=3D"margin-l=
eft: 242.984px; left: 0px; position: fixed; top: 0px; width: 100%; z-index:=
 99;">
<nav id=3D"server-breadcrumb" aria-label=3D"breadcrumb">
  <ol class=3D"breadcrumb breadcrumb-navbar">
    <li class=3D"breadcrumb-item">
      <img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"" al=
t=3D"" class=3D"icon ic_s_host">
      <a href=3D"http://localhost/phpmyadmin/index.php?route=3D/" data-raw-=
text=3D"127.0.0.1" draggable=3D"false">
        Server:        127.0.0.1
      </a>
    </li>

      </ol>
</nav>
<div id=3D"topmenucontainer" class=3D"menucontainer">
  <nav class=3D"navbar navbar-expand-lg navbar-light bg-light">
    <button class=3D"navbar-toggler" type=3D"button" data-bs-toggle=3D"coll=
apse" data-bs-target=3D"#navbarNav" aria-label=3D"Toggle navigation" aria-c=
ontrols=3D"navbarNav" aria-expanded=3D"false">
      <span class=3D"navbar-toggler-icon"></span>
    </button>
    <div class=3D"collapse navbar-collapse" id=3D"navbarNav" style=3D"width=
: auto; overflow: visible;">
      <ul id=3D"topmenu" class=3D"navbar-nav">
                  <li class=3D"nav-item">
            <a class=3D"nav-link text-nowrap" href=3D"http://localhost/phpm=
yadmin/index.php?route=3D/server/databases">
              <img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=
=3D"Databases" alt=3D"Databases" class=3D"icon ic_s_db">&nbsp;Databases
                          </a>
          </li>
                  <li class=3D"nav-item active">
            <a class=3D"nav-link text-nowrap" href=3D"http://localhost/phpm=
yadmin/index.php?route=3D/server/sql">
              <img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=
=3D"SQL" alt=3D"SQL" class=3D"icon ic_b_sql">&nbsp;SQL
                              <span class=3D"visually-hidden">(current)</sp=
an>
                          </a>
          </li>
                  <li class=3D"nav-item">
            <a class=3D"nav-link text-nowrap" href=3D"http://localhost/phpm=
yadmin/index.php?route=3D/server/status">
              <img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=
=3D"Status" alt=3D"Status" class=3D"icon ic_s_status">&nbsp;Status
                          </a>
          </li>
                  <li class=3D"nav-item">
            <a class=3D"nav-link text-nowrap" href=3D"http://localhost/phpm=
yadmin/index.php?route=3D/server/privileges&amp;viewing_mode=3Dserver">
              <img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=
=3D"User accounts" alt=3D"User accounts" class=3D"icon ic_s_rights">&nbsp;U=
ser accounts
                          </a>
          </li>
                  <li class=3D"nav-item">
            <a class=3D"nav-link text-nowrap" href=3D"http://localhost/phpm=
yadmin/index.php?route=3D/server/export">
              <img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=
=3D"Export" alt=3D"Export" class=3D"icon ic_b_export">&nbsp;Export
                          </a>
          </li>
                  <li class=3D"nav-item">
            <a class=3D"nav-link text-nowrap" href=3D"http://localhost/phpm=
yadmin/index.php?route=3D/server/import">
              <img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=
=3D"Import" alt=3D"Import" class=3D"icon ic_b_import">&nbsp;Import
                          </a>
          </li>
                  <li class=3D"nav-item">
            <a class=3D"nav-link text-nowrap" href=3D"http://localhost/phpm=
yadmin/index.php?route=3D/preferences/manage">
              <img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=
=3D"Settings" alt=3D"Settings" class=3D"icon ic_b_tblops">&nbsp;Settings
                          </a>
          </li>
                  <li class=3D"nav-item">
            <a class=3D"nav-link text-nowrap" href=3D"http://localhost/phpm=
yadmin/index.php?route=3D/server/replication">
              <img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=
=3D"Replication" alt=3D"Replication" class=3D"icon ic_s_replication">&nbsp;=
Replication
                          </a>
          </li>
                  <li class=3D"nav-item">
            <a class=3D"nav-link text-nowrap" href=3D"http://localhost/phpm=
yadmin/index.php?route=3D/server/variables">
              <img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=
=3D"Variables" alt=3D"Variables" class=3D"icon ic_s_vars">&nbsp;Variables
                          </a>
          </li>
                  <li class=3D"nav-item">
            <a class=3D"nav-link text-nowrap" href=3D"http://localhost/phpm=
yadmin/index.php?route=3D/server/collations">
              <img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=
=3D"Charsets" alt=3D"Charsets" class=3D"icon ic_s_asci">&nbsp;Charsets
                          </a>
          </li>
                  <li class=3D"nav-item">
            <a class=3D"nav-link text-nowrap" href=3D"http://localhost/phpm=
yadmin/index.php?route=3D/server/engines">
              <img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=
=3D"Engines" alt=3D"Engines" class=3D"icon ic_b_engine">&nbsp;Engines
                          </a>
          </li>
                  <li class=3D"nav-item">
            <a class=3D"nav-link text-nowrap" href=3D"http://localhost/phpm=
yadmin/index.php?route=3D/server/plugins">
              <img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=
=3D"Plugins" alt=3D"Plugins" class=3D"icon ic_b_plugin">&nbsp;Plugins
                          </a>
          </li>
              <li class=3D"nav-item dropdown d-none" style=3D""><a href=3D"=
http://localhost/phpmyadmin/index.php?route=3D/server/sql#" class=3D"nav-li=
nk dropdown-toggle" id=3D"navbarDropdown" role=3D"button" data-bs-toggle=3D=
"dropdown" aria-haspopup=3D"true" aria-expanded=3D"false"><img alt=3D"" tit=
le=3D"" src=3D"http://localhost/phpmyadmin/themes/dot.gif" class=3D"icon ic=
_b_more">More</a><ul class=3D"dropdown-menu dropdown-menu-end" aria-labelle=
dby=3D"navbarDropdown"></ul></li></ul>
    </div>
  </nav>
</div>
</div>



    <span id=3D"page_nav_icons" class=3D"d-print-none">
      <span id=3D"lock_page_icon"><img alt=3D"Indicates that you have made =
changes to this page; you will be prompted for confirmation before abandoni=
ng changes" title=3D"Indicates that you have made changes to this page; you=
 will be prompted for confirmation before abandoning changes" src=3D"http:/=
/localhost/phpmyadmin/themes/dot.gif" class=3D"icon ic_s_lock"></span>
      <span id=3D"page_settings_icon" style=3D"display: inline;">
        <img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Pa=
ge-related settings" alt=3D"Page-related settings" class=3D"icon ic_s_cog">
      </span>
      <a id=3D"goto_pagetop" href=3D"http://localhost/phpmyadmin/index.php?=
route=3D/server/sql#"><img src=3D"http://localhost/phpmyadmin/themes/dot.gi=
f" title=3D"Click on the bar to scroll to top of page" alt=3D"Click on the =
bar to scroll to top of page" class=3D"icon ic_s_top"></a>
    </span>
 =20
  <div id=3D"pma_console_container" class=3D"d-print-none">
    <div id=3D"pma_console" style=3D"margin-left: 242.997px;">
                <div class=3D"toolbar collapsed">
                    <div class=3D"switch_button console_switch">
            <img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=
=3D"SQL Query Console" alt=3D"SQL Query Console" class=3D"icon ic_console">
            <span>Console</span>
        </div>
                            <div class=3D"button clear">
           =20
            <span>Clear</span>
        </div>
                            <div class=3D"button history">
           =20
            <span>History</span>
        </div>
                            <div class=3D"button options">
           =20
            <span>Options</span>
        </div>
                            <div class=3D"button bookmarks">
           =20
            <span>Bookmarks</span>
        </div>
                            <div class=3D"button debug hide">
           =20
            <span>Debug SQL</span>
        </div>
            </div>
                <div class=3D"content" style=3D"height: 98.6085px; margin-b=
ottom: -98.5969px; display: none;">
            <div class=3D"console_message_container">
                <div class=3D"message welcome binded">
                    <span id=3D"instructions-0">
                        Press Ctrl+Enter to execute query                  =
  </span>
                    <span class=3D"hide" id=3D"instructions-1">
                        Press Enter to execute query                    </s=
pan>
                </div>
                            </div><!-- console_message_container -->
            <div class=3D"query_input">
                <span class=3D"console_query_input"><div class=3D"CodeMirro=
r cm-s-pma CodeMirror-wrap" translate=3D"no" style=3D"clip-path: inset(0px)=
;"><div style=3D"overflow: hidden; position: relative; width: 3px; height: =
0px; top: 0px; left: 15.9864px;"><textarea autocorrect=3D"off" autocapitali=
ze=3D"off" spellcheck=3D"false" tabindex=3D"0" style=3D"position: absolute;=
 bottom: -1em; padding: 0px; width: 1000px; height: 1em; min-height: 1em; o=
utline: none;"></textarea></div><div class=3D"CodeMirror-vscrollbar" tabind=
ex=3D"-1" cm-not-content=3D"true"><div style=3D"min-width: 1px; height: 0px=
;"></div></div><div class=3D"CodeMirror-hscrollbar" tabindex=3D"-1" cm-not-=
content=3D"true"><div style=3D"height: 100%; min-height: 1px; width: 0px;">=
</div></div><div class=3D"CodeMirror-scrollbar-filler" cm-not-content=3D"tr=
ue"></div><div class=3D"CodeMirror-gutter-filler" cm-not-content=3D"true"><=
/div><div class=3D"CodeMirror-scroll" tabindex=3D"-1"><div class=3D"CodeMir=
ror-sizer" style=3D"margin-left: 16px; margin-bottom: -45px; border-right-w=
idth: 5px; min-height: 20px; padding-right: 0px; padding-bottom: 0px;"><div=
 style=3D"position: relative; top: 0px;"><div class=3D"CodeMirror-lines" ro=
le=3D"presentation"><div role=3D"presentation" style=3D"position: relative;=
 outline: none;"><div class=3D"CodeMirror-measure"><span><span>=E2=80=8B</s=
pan>x</span></div><div class=3D"CodeMirror-measure"></div><div style=3D"pos=
ition: relative; z-index: 1;"></div><div class=3D"CodeMirror-cursors"><div =
class=3D"CodeMirror-cursor" style=3D"left: 0px; top: 0px; height: 19.6641px=
;">&nbsp;</div></div><div class=3D"CodeMirror-code" role=3D"presentation"><=
pre class=3D" CodeMirror-line " role=3D"presentation"><span role=3D"present=
ation" style=3D"padding-right: 0.1px;"><span cm-text=3D"">=E2=80=8B</span><=
/span></pre></div></div></div></div></div><div style=3D"position: absolute;=
 height: 5px; width: 1px; border-bottom: 0px solid transparent; top: 20px;"=
></div><div class=3D"CodeMirror-gutters" style=3D"height: 25px;"><div class=
=3D"CodeMirror-gutter CodeMirror-lint-markers"></div></div></div></div></sp=
an>
            </div>
        </div><!-- message end -->
                <div class=3D"mid_layer"></div>
                <div class=3D"card ungrouped" id=3D"debug_console">
            <div class=3D"toolbar ">
                    <div class=3D"button order order_asc active">
           =20
            <span>ascending</span>
        </div>
                            <div class=3D"button order order_desc">
           =20
            <span>descending</span>
        </div>
                            <div class=3D"text">
           =20
            <span>Order:</span>
        </div>
                            <div class=3D"switch_button">
           =20
            <span>Debug SQL</span>
        </div>
                            <div class=3D"button order_by sort_count">
           =20
            <span>Count</span>
        </div>
                            <div class=3D"button order_by sort_exec active"=
>
           =20
            <span>Execution order</span>
        </div>
                            <div class=3D"button order_by sort_time">
           =20
            <span>Time taken</span>
        </div>
                            <div class=3D"text">
           =20
            <span>Order by:</span>
        </div>
                            <div class=3D"button group_queries">
           =20
            <span>Group queries</span>
        </div>
                            <div class=3D"button ungroup_queries">
           =20
            <span>Ungroup queries</span>
        </div>
            </div>
            <div class=3D"content debug" style=3D"height: 98.6085px;">
                <div class=3D"message welcome binded">Some error occurred w=
hile getting SQL debug info.</div>
                <div class=3D"debugLog"></div>
            </div> <!-- Content -->
            <div class=3D"templates">
                <div class=3D"debug_query action_content">
                    <span class=3D"action collapse">
            Collapse
                    </span>
                            <span class=3D"action expand">
            Expand
                    </span>
                            <span class=3D"action dbg_show_trace">
            Show trace
                    </span>
                            <span class=3D"action dbg_hide_trace">
            Hide trace
                    </span>
                            <span class=3D"text count hide">
            Count
                            : <span></span>
                    </span>
                            <span class=3D"text time">
            Time taken
                            : <span></span>
                    </span>
            </div>
            </div> <!-- Template -->
        </div> <!-- Debug SQL card -->
                    <div class=3D"card" id=3D"pma_bookmarks">
                <div class=3D"toolbar ">
                    <div class=3D"switch_button">
           =20
            <span>Bookmarks</span>
        </div>
                            <div class=3D"button refresh">
           =20
            <span>Refresh</span>
        </div>
                            <div class=3D"button add">
           =20
            <span>Add</span>
        </div>
            </div>
                <div class=3D"content bookmark" style=3D"height: 98.6085px;=
">
                    <div class=3D"message welcome binded">
    <span>No bookmarks</span>
</div>

                </div>
                <div class=3D"mid_layer"></div>
                <div class=3D"card add">
                    <div class=3D"toolbar ">
                    <div class=3D"switch_button">
           =20
            <span>Add bookmark</span>
        </div>
            </div>
                    <div class=3D"content add_bookmark" style=3D"height: 10=
1.361px;">
                        <div class=3D"options">
                            <label>
                                Label: <input type=3D"text" name=3D"label">
                            </label>
                            <label>
                                Target database: <input type=3D"text" name=
=3D"targetdb">
                            </label>
                            <label>
                                <input type=3D"checkbox" name=3D"shared">Sh=
are this bookmark                            </label>
                            <button class=3D"btn btn-primary" type=3D"submi=
t" name=3D"submit">OK</button>
                        </div> <!-- options -->
                        <div class=3D"query_input">
                            <span class=3D"bookmark_add_input"><div class=
=3D"CodeMirror cm-s-pma CodeMirror-wrap" translate=3D"no" style=3D"clip-pat=
h: inset(0px);"><div style=3D"overflow: hidden; position: relative; width: =
3px; height: 0px; top: 0px; left: 15.9863px;"><textarea autocorrect=3D"off"=
 autocapitalize=3D"off" spellcheck=3D"false" tabindex=3D"0" style=3D"positi=
on: absolute; bottom: -1em; padding: 0px; width: 1000px; height: 1em; min-h=
eight: 1em; outline: none;"></textarea></div><div class=3D"CodeMirror-vscro=
llbar" tabindex=3D"-1" cm-not-content=3D"true"><div style=3D"min-width: 1px=
; height: 0px;"></div></div><div class=3D"CodeMirror-hscrollbar" tabindex=
=3D"-1" cm-not-content=3D"true"><div style=3D"height: 100%; min-height: 1px=
; width: 0px;"></div></div><div class=3D"CodeMirror-scrollbar-filler" cm-no=
t-content=3D"true"></div><div class=3D"CodeMirror-gutter-filler" cm-not-con=
tent=3D"true"></div><div class=3D"CodeMirror-scroll" tabindex=3D"-1"><div c=
lass=3D"CodeMirror-sizer" style=3D"margin-left: 16px; margin-bottom: -45px;=
 border-right-width: 5px; min-height: 20px; padding-right: 0px; padding-bot=
tom: 0px;"><div style=3D"position: relative; top: 0px;"><div class=3D"CodeM=
irror-lines" role=3D"presentation"><div role=3D"presentation" style=3D"posi=
tion: relative; outline: none;"><div class=3D"CodeMirror-measure"><pre clas=
s=3D"CodeMirror-line-like"><span>xxxxxxxxxx</span></pre></div><div class=3D=
"CodeMirror-measure"></div><div style=3D"position: relative; z-index: 1;"><=
/div><div class=3D"CodeMirror-cursors"><div class=3D"CodeMirror-cursor" sty=
le=3D"left: 0px; top: 0px; height: 19.6641px;">&nbsp;</div></div><div class=
=3D"CodeMirror-code" role=3D"presentation"><pre class=3D" CodeMirror-line "=
 role=3D"presentation"><span role=3D"presentation" style=3D"padding-right: =
0.1px;"><span cm-text=3D"">=E2=80=8B</span></span></pre></div></div></div><=
/div></div><div style=3D"position: absolute; height: 5px; width: 1px; borde=
r-bottom: 0px solid transparent; top: 20px;"></div><div class=3D"CodeMirror=
-gutters" style=3D"height: 25px;"><div class=3D"CodeMirror-gutter CodeMirro=
r-lint-markers"></div></div></div></div></span>
                        </div>
                    </div>
                </div> <!-- Add bookmark card -->
            </div> <!-- Bookmarks card -->
                        <div class=3D"card" id=3D"pma_console_options">
            <div class=3D"toolbar ">
                    <div class=3D"switch_button">
           =20
            <span>Options</span>
        </div>
                            <div class=3D"button default">
           =20
            <span>Set default</span>
        </div>
            </div>
            <div class=3D"content" style=3D"height: 101.361px;">
                <label>
                    <input type=3D"checkbox" name=3D"always_expand">Always =
expand query messages                </label>
                <br>
                <label>
                    <input type=3D"checkbox" name=3D"start_history">Show qu=
ery history at start                </label>
                <br>
                <label>
                    <input type=3D"checkbox" name=3D"current_query">Show cu=
rrent browsing query                </label>
                <br>
                <label>
                    <input type=3D"checkbox" name=3D"enter_executes">
                        Execute queries on Enter and insert new line with S=
hift+Enter. To make this permanent, view settings.                </label>
                <br>
                <label>
                    <input type=3D"checkbox" name=3D"dark_theme">Switch to =
dark theme                </label>
                <br>
            </div>
        </div> <!-- Options card -->
        <div class=3D"templates">
                        <div class=3D"query_actions">
                    <span class=3D"action collapse">
            Collapse
                    </span>
                            <span class=3D"action expand">
            Expand
                    </span>
                            <span class=3D"action requery">
            Requery
                    </span>
                            <span class=3D"action edit">
            Edit
                    </span>
                            <span class=3D"action explain">
            Explain
                    </span>
                            <span class=3D"action profiling">
            Profiling
                    </span>
                            <span class=3D"action bookmark">
            Bookmark
                    </span>
                            <span class=3D"text failed">
            Query failed
                    </span>
                            <span class=3D"text targetdb">
            Database
                            : <span></span>
                    </span>
                            <span class=3D"text query_time">
            Queried time
                            : <span></span>
                    </span>
            </div>
        </div>
    </div> <!-- #console end -->
</div> <!-- #console_container end -->


  <div id=3D"page_content"><div id=3D"loading_parent"></div><div id=3D"page=
_settings_modal"><div class=3D"page_settings"><form method=3D"post" action=
=3D"http://localhost/phpmyadmin/index.php?route=3D%2Fserver%2Fsql&amp;serve=
r=3D1" class=3D"config-form disableAjax">
 =20
     =20
   =20
 =20

  <ul class=3D"nav nav-tabs" id=3D"configFormDisplayTab" role=3D"tablist">
          <li class=3D"nav-item" role=3D"presentation">
        <a class=3D"nav-link active" id=3D"Sql_queries-tab" href=3D"http://=
localhost/phpmyadmin/index.php?route=3D/server/sql#Sql_queries" data-bs-tog=
gle=3D"tab" role=3D"tab" aria-controls=3D"Sql_queries" aria-selected=3D"tru=
e">SQL queries</a>
      </li>
          <li class=3D"nav-item" role=3D"presentation">
        <a class=3D"nav-link" id=3D"Sql_box-tab" href=3D"http://localhost/p=
hpmyadmin/index.php?route=3D/server/sql#Sql_box" data-bs-toggle=3D"tab" rol=
e=3D"tab" aria-controls=3D"Sql_box" aria-selected=3D"false">SQL Query box</=
a>
      </li>
      </ul>
  <div class=3D"tab-content">
          <div class=3D"tab-pane fade show active" id=3D"Sql_queries" role=
=3D"tabpanel" aria-labelledby=3D"Sql_queries-tab">
        <div class=3D"card border-top-0">
          <div class=3D"card-body">
            <h5 class=3D"card-title visually-hidden">SQL queries</h5>
                          <h6 class=3D"card-subtitle mb-2 text-muted">SQL q=
ueries settings.</h6>
           =20
            <fieldset class=3D"optbox">
              <legend>SQL queries</legend>

                           =20
              <table class=3D"table table-borderless">
                <tbody><tr>
  <th>
    <label for=3D"ShowSQL">Show SQL queries</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Sho=
wSQL" target=3D"documentation"><img src=3D"http://localhost/phpmyadmin/them=
es/dot.gif" title=3D"Documentation" alt=3D"Documentation" class=3D"icon ic_=
b_help"></a>
      </span>
   =20
   =20
          <small>Defines whether SQL queries generated by phpMyAdmin should=
 be displayed.</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"ShowSQL" id=3D"ShowSQL" checked=3D=
"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#ShowSQL" title=3D"Restore default value"=
 style=3D"display: inline-block; opacity: 0.25;"><img src=3D"http://localho=
st/phpmyadmin/themes/dot.gif" title=3D"Restore default value" alt=3D"Restor=
e default value" class=3D"icon ic_s_reload" style=3D"display: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"Confirm">Confirm DROP queries</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Con=
firm" target=3D"documentation"><img src=3D"http://localhost/phpmyadmin/them=
es/dot.gif" title=3D"Documentation" alt=3D"Documentation" class=3D"icon ic_=
b_help"></a>
      </span>
   =20
   =20
          <small>Whether a warning ("Are your really sure=E2=80=A6") should=
 be displayed when you're about to lose data.</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"Confirm" id=3D"Confirm" checked=3D=
"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#Confirm" title=3D"Restore default value"=
 style=3D"display: inline-block; opacity: 0.25;"><img src=3D"http://localho=
st/phpmyadmin/themes/dot.gif" title=3D"Restore default value" alt=3D"Restor=
e default value" class=3D"icon ic_s_reload" style=3D"display: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"QueryHistoryMax">Query history length</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Que=
ryHistoryMax" target=3D"documentation"><img src=3D"http://localhost/phpmyad=
min/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" class=3D"=
icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>How many queries are kept in history.</small>
      </th>

  <td>
          <input type=3D"number" name=3D"QueryHistoryMax" id=3D"QueryHistor=
yMax" value=3D"25" class=3D"">
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#QueryHistoryMax" title=3D"Restore defaul=
t value" style=3D"display: inline-block; opacity: 0.25;"><img src=3D"http:/=
/localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default value" alt=
=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"display: non=
e;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"IgnoreMultiSubmitErrors">Ignore multiple statement errors=
</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Ign=
oreMultiSubmitErrors" target=3D"documentation"><img src=3D"http://localhost=
/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" c=
lass=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>If enabled, phpMyAdmin continues computing multiple-statem=
ent queries even if one of the queries failed.</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"IgnoreMultiSubmitErrors" id=3D"Ign=
oreMultiSubmitErrors">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#IgnoreMultiSubmitErrors" title=3D"Restor=
e default value" style=3D"display: inline-block; opacity: 0.25;"><img src=
=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default va=
lue" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"disp=
lay: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"MaxCharactersInDisplayedSQL">Maximum displayed SQL length=
</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Max=
CharactersInDisplayedSQL" target=3D"documentation"><img src=3D"http://local=
host/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentatio=
n" class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Maximum number of characters used when a SQL query is disp=
layed.</small>
      </th>

  <td>
          <input type=3D"number" name=3D"MaxCharactersInDisplayedSQL" id=3D=
"MaxCharactersInDisplayedSQL" value=3D"1000" class=3D"">
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#MaxCharactersInDisplayedSQL" title=3D"Re=
store default value" style=3D"display: inline-block; opacity: 0.25;"><img s=
rc=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default =
value" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"di=
splay: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"RetainQueryBox">Retain query box</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Ret=
ainQueryBox" target=3D"documentation"><img src=3D"http://localhost/phpmyadm=
in/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" class=3D"i=
con ic_b_help"></a>
      </span>
   =20
   =20
          <small>Defines whether the query box should stay on-screen after =
its submission.</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"RetainQueryBox" id=3D"RetainQueryB=
ox">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#RetainQueryBox" title=3D"Restore default=
 value" style=3D"display: inline-block; opacity: 0.25;"><img src=3D"http://=
localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default value" alt=3D=
"Restore default value" class=3D"icon ic_s_reload" style=3D"display: none;"=
></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"CodemirrorEnable">Enable CodeMirror</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Cod=
emirrorEnable" target=3D"documentation"><img src=3D"http://localhost/phpmya=
dmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" class=3D=
"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Use user-friendly editor for editing SQL queries (CodeMirr=
or) with syntax highlighting and line numbers.</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"CodemirrorEnable" id=3D"Codemirror=
Enable" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#CodemirrorEnable" title=3D"Restore defau=
lt value" style=3D"display: inline-block; opacity: 0.25;"><img src=3D"http:=
//localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default value" alt=
=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"display: non=
e;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"LintEnable">Enable linter</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Lin=
tEnable" target=3D"documentation"><img src=3D"http://localhost/phpmyadmin/t=
hemes/dot.gif" title=3D"Documentation" alt=3D"Documentation" class=3D"icon =
ic_b_help"></a>
      </span>
   =20
   =20
          <small>Find any errors in the query before executing it. Requires=
 CodeMirror to be enabled.</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"LintEnable" id=3D"LintEnable" chec=
ked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#LintEnable" title=3D"Restore default val=
ue" style=3D"display: inline-block; opacity: 0.25;"><img src=3D"http://loca=
lhost/phpmyadmin/themes/dot.gif" title=3D"Restore default value" alt=3D"Res=
tore default value" class=3D"icon ic_s_reload" style=3D"display: none;"></a=
>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"EnableAutocompleteForTablesAndColumns">Enable autocomplet=
e for table and column names</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Ena=
bleAutocompleteForTablesAndColumns" target=3D"documentation"><img src=3D"ht=
tp://localhost/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Do=
cumentation" class=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Autocomplete of the table and column names in the SQL quer=
ies.</small>
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"EnableAutocompleteForTablesAndColu=
mns" id=3D"EnableAutocompleteForTablesAndColumns" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#EnableAutocompleteForTablesAndColumns" t=
itle=3D"Restore default value" style=3D"display: inline-block; opacity: 0.2=
5;"><img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restor=
e default value" alt=3D"Restore default value" class=3D"icon ic_s_reload" s=
tyle=3D"display: none;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"DefaultForeignKeyChecks">Foreign key checks</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_Def=
aultForeignKeyChecks" target=3D"documentation"><img src=3D"http://localhost=
/phpmyadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" c=
lass=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
          <small>Default value for foreign key checks checkbox for some que=
ries.</small>
      </th>

  <td>
          <select name=3D"DefaultForeignKeyChecks" id=3D"DefaultForeignKeyC=
hecks" class=3D"w-75">
                            <option value=3D"default" selected=3D"">Server =
default</option>
                            <option value=3D"enable">Enable</option>
                            <option value=3D"disable">Disable</option>
              </select>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#DefaultForeignKeyChecks" title=3D"Restor=
e default value" style=3D"display: inline-block; opacity: 0.25;"><img src=
=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default va=
lue" alt=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"disp=
lay: none;"></a>
   =20
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
          <div class=3D"tab-pane fade" id=3D"Sql_box" role=3D"tabpanel" ari=
a-labelledby=3D"Sql_box-tab">
        <div class=3D"card border-top-0">
          <div class=3D"card-body">
            <h5 class=3D"card-title visually-hidden">SQL Query box</h5>
                          <h6 class=3D"card-subtitle mb-2 text-muted">Custo=
mize links shown in SQL Query boxes.</h6>
           =20
            <fieldset class=3D"optbox">
              <legend>SQL Query box</legend>

                           =20
              <table class=3D"table table-borderless">
                <tbody><tr>
  <th>
    <label for=3D"SQLQuery-Edit">Edit</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_SQL=
Query_Edit" target=3D"documentation"><img src=3D"http://localhost/phpmyadmi=
n/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" class=3D"ic=
on ic_b_help"></a>
      </span>
   =20
   =20
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"SQLQuery-Edit" id=3D"SQLQuery-Edit=
" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#SQLQuery-Edit" title=3D"Restore default =
value" style=3D"display: inline-block; opacity: 0.25;"><img src=3D"http://l=
ocalhost/phpmyadmin/themes/dot.gif" title=3D"Restore default value" alt=3D"=
Restore default value" class=3D"icon ic_s_reload" style=3D"display: none;">=
</a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"SQLQuery-Explain">Explain SQL</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_SQL=
Query_Explain" target=3D"documentation"><img src=3D"http://localhost/phpmya=
dmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" class=3D=
"icon ic_b_help"></a>
      </span>
   =20
   =20
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"SQLQuery-Explain" id=3D"SQLQuery-E=
xplain" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#SQLQuery-Explain" title=3D"Restore defau=
lt value" style=3D"display: inline-block; opacity: 0.25;"><img src=3D"http:=
//localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default value" alt=
=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"display: non=
e;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"SQLQuery-ShowAsPHP">Create PHP code</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_SQL=
Query_ShowAsPHP" target=3D"documentation"><img src=3D"http://localhost/phpm=
yadmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" class=
=3D"icon ic_b_help"></a>
      </span>
   =20
   =20
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"SQLQuery-ShowAsPHP" id=3D"SQLQuery=
-ShowAsPHP" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#SQLQuery-ShowAsPHP" title=3D"Restore def=
ault value" style=3D"display: inline-block; opacity: 0.25;"><img src=3D"htt=
p://localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default value" al=
t=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"display: no=
ne;"></a>
   =20
          </td>

  </tr>
<tr>
  <th>
    <label for=3D"SQLQuery-Refresh">Refresh</label>

          <span class=3D"doc">
        <a href=3D"http://localhost/phpmyadmin/doc/html/config.html#cfg_SQL=
Query_Refresh" target=3D"documentation"><img src=3D"http://localhost/phpmya=
dmin/themes/dot.gif" title=3D"Documentation" alt=3D"Documentation" class=3D=
"icon ic_b_help"></a>
      </span>
   =20
   =20
      </th>

  <td>
          <span class=3D"checkbox">
        <input type=3D"checkbox" name=3D"SQLQuery-Refresh" id=3D"SQLQuery-R=
efresh" checked=3D"">
      </span>
   =20
   =20
   =20
          <a class=3D"restore-default hide" href=3D"http://localhost/phpmya=
dmin/index.php?route=3D/server/sql#SQLQuery-Refresh" title=3D"Restore defau=
lt value" style=3D"display: inline-block; opacity: 0.25;"><img src=3D"http:=
//localhost/phpmyadmin/themes/dot.gif" title=3D"Restore default value" alt=
=3D"Restore default value" class=3D"icon ic_s_reload" style=3D"display: non=
e;"></a>
   =20
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
      </div>
</form>


</div></div><form method=3D"post" action=3D"http://localhost/phpmyadmin/ind=
ex.php?route=3D/import" class=3D"ajax lock-page" id=3D"sqlqueryform" name=
=3D"sqlform" enctype=3D"multipart/form-data">
 =20
 =20
 =20
 =20
 =20
 =20

      <a id=3D"querybox"></a>

    <div class=3D"card mb-3">
      <div class=3D"card-header">Run SQL query/queries on server =E2=80=9C1=
27.0.0.1=E2=80=9D: <a href=3D"http://localhost/phpmyadmin/url.php?url=3Dhtt=
ps%3A%2F%2Fdev.mysql.com%2Fdoc%2Frefman%2F8.0%2Fen%2Fselect.html" target=3D=
"mysql_doc"><img src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=
=3D"Documentation" alt=3D"Documentation" class=3D"icon ic_b_help"></a></div=
>
      <div class=3D"card-body">
        <div id=3D"queryfieldscontainer">
          <div class=3D"row">
            <div class=3D"col">
              <div class=3D"mb-3">
                <textarea class=3D"form-control" tabindex=3D"100" name=3D"s=
ql_query" id=3D"sqlquery" cols=3D"40" rows=3D"15" data-textarea-auto-select=
=3D"false" aria-label=3D"SQL query" style=3D"display: none;"></textarea><di=
v class=3D"CodeMirror cm-s-default CodeMirror-wrap ui-resizable CodeMirror-=
focused" translate=3D"no" style=3D"clip-path: inset(0px); resize: vertical;=
"><div style=3D"overflow: hidden; position: relative; width: 3px; height: 0=
px; top: 141.617px; left: 64.4345px;"><textarea autocorrect=3D"off" autocap=
italize=3D"off" spellcheck=3D"false" tabindex=3D"100" style=3D"position: ab=
solute; bottom: -1em; padding: 0px; width: 1000px; height: 1em; min-height:=
 1em; outline: none;"></textarea></div><div class=3D"CodeMirror-vscrollbar"=
 tabindex=3D"-1" cm-not-content=3D"true"><div style=3D"min-width: 1px; heig=
ht: 0px;"></div></div><div class=3D"CodeMirror-hscrollbar" tabindex=3D"-1" =
cm-not-content=3D"true"><div style=3D"height: 100%; min-height: 1px; width:=
 0px;"></div></div><div class=3D"CodeMirror-scrollbar-filler" cm-not-conten=
t=3D"true"></div><div class=3D"CodeMirror-gutter-filler" cm-not-content=3D"=
true"></div><div class=3D"CodeMirror-scroll" tabindex=3D"-1"><div class=3D"=
CodeMirror-sizer" style=3D"margin-left: 46px; margin-bottom: -45px; border-=
right-width: 5px; min-height: 165px; padding-right: 0px; padding-bottom: 0p=
x;"><div style=3D"position: relative; top: 0px;"><div class=3D"CodeMirror-l=
ines" role=3D"presentation"><div role=3D"presentation" style=3D"position: r=
elative; outline: none;"><div class=3D"CodeMirror-measure"><pre class=3D"Co=
deMirror-line-like"><span>xxxxxxxxxx</span></pre><div class=3D"CodeMirror-l=
inenumber CodeMirror-gutter-elt"><div>1</div></div></div><div class=3D"Code=
Mirror-measure"></div><div style=3D"position: relative; z-index: 1;"></div>=
<div class=3D"CodeMirror-cursors" style=3D""><div class=3D"CodeMirror-curso=
r" style=3D"left: 18.4524px; top: 137.62px; height: 19.6641px;">&nbsp;</div=
></div><div class=3D"CodeMirror-code" role=3D"presentation" style=3D""><div=
 style=3D"position: relative;"><div class=3D"CodeMirror-gutter-wrapper" ari=
a-hidden=3D"true" style=3D"left: -45.9821px;"><div class=3D"CodeMirror-line=
number CodeMirror-gutter-elt" style=3D"left: 16px; width: 21px;">1</div></d=
iv><pre class=3D" CodeMirror-line " role=3D"presentation"><span role=3D"pre=
sentation" style=3D"padding-right: 0.1px;"><span class=3D"cm-keyword">CREAT=
E</span> <span class=3D"cm-keyword">DATABASE</span> student_<span class=3D"=
cm-punctuation">;</span></span></pre></div><div style=3D"position: relative=
;"><div class=3D"CodeMirror-gutter-wrapper" aria-hidden=3D"true" style=3D"l=
eft: -45.9821px;"><div class=3D"CodeMirror-linenumber CodeMirror-gutter-elt=
" style=3D"left: 16px; width: 21px;">2</div></div><pre class=3D" CodeMirror=
-line " role=3D"presentation"><span role=3D"presentation" style=3D"padding-=
right: 0.1px;"><span class=3D"cm-keyword">USE</span> student_<span class=3D=
"cm-punctuation">;</span></span></pre></div><div style=3D"position: relativ=
e;"><div class=3D"CodeMirror-gutter-wrapper" aria-hidden=3D"true" style=3D"=
left: -45.9821px;"><div class=3D"CodeMirror-linenumber CodeMirror-gutter-el=
t" style=3D"left: 16px; width: 21px;">3</div></div><pre class=3D" CodeMirro=
r-line " role=3D"presentation"><span role=3D"presentation" style=3D"padding=
-right: 0.1px;"><span class=3D"cm-keyword">CREATE</span> <span class=3D"cm-=
keyword">TABLE</span> students <span class=3D"cm-bracket">(</span></span></=
pre></div><div style=3D"position: relative;"><div class=3D"CodeMirror-gutte=
r-wrapper" aria-hidden=3D"true" style=3D"left: -45.9821px;"><div class=3D"C=
odeMirror-linenumber CodeMirror-gutter-elt" style=3D"left: 16px; width: 21p=
x;">4</div></div><pre class=3D" CodeMirror-line " role=3D"presentation"><sp=
an role=3D"presentation" style=3D"padding-right: 0.1px;"> &nbsp;  id <span =
class=3D"cm-type">INT</span> <span class=3D"cm-keyword">AUTO_INCREMENT</spa=
n> <span class=3D"cm-keyword">PRIMARY</span> <span class=3D"cm-keyword">KEY=
</span><span class=3D"cm-punctuation">,</span></span></pre></div><div style=
=3D"position: relative;"><div class=3D"CodeMirror-gutter-wrapper" aria-hidd=
en=3D"true" style=3D"left: -45.9821px;"><div class=3D"CodeMirror-linenumber=
 CodeMirror-gutter-elt" style=3D"left: 16px; width: 21px;">5</div></div><pr=
e class=3D" CodeMirror-line " role=3D"presentation"><span role=3D"presentat=
ion" style=3D"padding-right: 0.1px;"> &nbsp;  name <span class=3D"cm-type">=
VARCHAR</span><span class=3D"cm-bracket">(</span><span class=3D"cm-number">=
100</span><span class=3D"cm-bracket">)</span> <span class=3D"cm-keyword">NO=
T</span> <span class=3D"cm-atom">NULL</span><span class=3D"cm-punctuation">=
,</span></span></pre></div><div style=3D"position: relative;"><div class=3D=
"CodeMirror-gutter-wrapper" aria-hidden=3D"true" style=3D"left: -45.9821px;=
"><div class=3D"CodeMirror-linenumber CodeMirror-gutter-elt" style=3D"left:=
 16px; width: 21px;">6</div></div><pre class=3D" CodeMirror-line " role=3D"=
presentation"><span role=3D"presentation" style=3D"padding-right: 0.1px;"> =
&nbsp;  email <span class=3D"cm-type">VARCHAR</span><span class=3D"cm-brack=
et">(</span><span class=3D"cm-number">100</span><span class=3D"cm-bracket">=
)</span> <span class=3D"cm-keyword">NOT</span> <span class=3D"cm-atom">NULL=
</span><span class=3D"cm-punctuation">,</span></span></pre></div><div style=
=3D"position: relative;"><div class=3D"CodeMirror-gutter-wrapper" aria-hidd=
en=3D"true" style=3D"left: -45.9821px;"><div class=3D"CodeMirror-linenumber=
 CodeMirror-gutter-elt" style=3D"left: 16px; width: 21px;">7</div></div><pr=
e class=3D" CodeMirror-line " role=3D"presentation"><span role=3D"presentat=
ion" style=3D"padding-right: 0.1px;"> &nbsp;  age <span class=3D"cm-type">I=
NT</span> <span class=3D"cm-keyword">NOT</span> <span class=3D"cm-atom">NUL=
L</span></span></pre></div><div style=3D"position: relative;"><div class=3D=
"CodeMirror-gutter-wrapper" aria-hidden=3D"true" style=3D"left: -45.9821px;=
"><div class=3D"CodeMirror-linenumber CodeMirror-gutter-elt" style=3D"left:=
 16px; width: 21px;">8</div></div><pre class=3D" CodeMirror-line " role=3D"=
presentation"><span role=3D"presentation" style=3D"padding-right: 0.1px;"><=
span class=3D"cm-bracket">)</span><span class=3D"cm-punctuation">;</span></=
span></pre></div></div></div></div></div></div><div style=3D"position: abso=
lute; height: 5px; width: 1px; border-bottom: 0px solid transparent; top: 1=
65px;"></div><div class=3D"CodeMirror-gutters" style=3D"height: 170px;"><di=
v class=3D"CodeMirror-gutter CodeMirror-lint-markers"></div><div class=3D"C=
odeMirror-gutter CodeMirror-linenumbers" style=3D"width: 29px;"></div></div=
></div><div class=3D"ui-resizable-handle ui-resizable-s" style=3D"z-index: =
90;"></div></div>
              </div>
              <div id=3D"querymessage"></div>

              <div class=3D"btn-toolbar" role=3D"toolbar">
               =20
                <div class=3D"btn-group me-2" role=3D"group">
                  <input type=3D"button" value=3D"Clear" id=3D"clear" class=
=3D"btn btn-secondary button sqlbutton">
                                      <input type=3D"button" value=3D"Forma=
t" id=3D"format" class=3D"btn btn-secondary button sqlbutton">
                                  </div>

                <input type=3D"button" value=3D"Get auto-saved query" id=3D=
"saved" class=3D"btn btn-secondary button sqlbutton">
              </div>

              <div class=3D"my-3">
                <div class=3D"form-check">
                  <input class=3D"form-check-input" type=3D"checkbox" name=
=3D"parameterized" id=3D"parameterized">
                  <label class=3D"form-check-label" for=3D"parameterized">
                    Bind parameters                    <a href=3D"http://lo=
calhost/phpmyadmin/doc/html/faq.html#faq6-40" target=3D"documentation"><img=
 src=3D"http://localhost/phpmyadmin/themes/dot.gif" title=3D"Documentation"=
 alt=3D"Documentation" class=3D"icon ic_b_help"></a>
                  </label>
                </div>
              </div>
              <div class=3D"mb-3" id=3D"parametersDiv"></div>
            </div>

                      </div>
        </div>

                  <div class=3D"row row-cols-lg-auto g-3 align-items-center=
">
            <div class=3D"col-6">
              <label class=3D"form-label" for=3D"bkm_label">Bookmark this S=
QL query:</label>
            </div>
            <div class=3D"col-6">
              <input class=3D"form-control" type=3D"text" name=3D"bkm_label=
" id=3D"bkm_label" tabindex=3D"110" value=3D"">
            </div>

            <div class=3D"col-12">
              <div class=3D"form-check form-check-inline" style=3D"display:=
 none;">
                <input class=3D"form-check-input" type=3D"checkbox" name=3D=
"bkm_all_users" tabindex=3D"111" id=3D"id_bkm_all_users" value=3D"true">
                <label class=3D"form-check-label" for=3D"id_bkm_all_users">=
Let every user access this bookmark</label>
              </div>
            </div>

            <div class=3D"col-12">
              <div class=3D"form-check form-check-inline" style=3D"display:=
 none;">
                <input class=3D"form-check-input" type=3D"checkbox" name=3D=
"bkm_replace" tabindex=3D"112" id=3D"id_bkm_replace" value=3D"true">
                <label class=3D"form-check-label" for=3D"id_bkm_replace">Re=
place existing bookmark of same name</label>
              </div>
            </div>
          </div>
              </div>
      <div class=3D"card-footer">
        <div class=3D"row row-cols-lg-auto g-3 align-items-center">
          <div class=3D"col-12">
            <div class=3D"input-group me-2">
              <span class=3D"input-group-text">Delimiter</span>
              <label class=3D"visually-hidden" for=3D"id_sql_delimiter">Del=
imiter</label>
              <input class=3D"form-control" type=3D"text" name=3D"sql_delim=
iter" tabindex=3D"131" size=3D"3" value=3D";" id=3D"id_sql_delimiter">
            </div>
          </div>

          <div class=3D"col-12">
            <div class=3D"form-check form-check-inline">
              <input class=3D"form-check-input" type=3D"checkbox" name=3D"s=
how_query" value=3D"1" id=3D"checkbox_show_query" tabindex=3D"132">
              <label class=3D"form-check-label" for=3D"checkbox_show_query"=
>Show this query here again</label>
            </div>
          </div>

          <div class=3D"col-12">
            <div class=3D"form-check form-check-inline">
              <input class=3D"form-check-input" type=3D"checkbox" name=3D"r=
etain_query_box" value=3D"1" id=3D"retain_query_box" tabindex=3D"133">
              <label class=3D"form-check-label" for=3D"retain_query_box">Re=
tain query box</label>
            </div>
          </div>

          <div class=3D"col-12">
            <div class=3D"form-check form-check-inline">
              <input class=3D"form-check-input" type=3D"checkbox" name=3D"r=
ollback_query" value=3D"1" id=3D"rollback_query" tabindex=3D"134">
              <label class=3D"form-check-label" for=3D"rollback_query">Roll=
back when finished</label>
            </div>
          </div>

          <div class=3D"col-12">
            <div class=3D"form-check">
             =20
              <input class=3D"form-check-input" type=3D"checkbox" name=3D"f=
k_checks" id=3D"fk_checks" value=3D"1" checked=3D"">
              <label class=3D"form-check-label" for=3D"fk_checks">Enable fo=
reign key checks</label>
            </div>
          </div>

          <div class=3D"col-12">
            <input class=3D"btn btn-primary ms-1" type=3D"submit" id=3D"but=
ton_submit_query" name=3D"SQL" tabindex=3D"200" value=3D"Go">
          </div>
        </div>
      </div>
    </div>
 =20
 =20
  <button class=3D"btn btn-secondary" id=3D"togglequerybox" style=3D"displa=
y: none;">Hide query box</button></form>

<div id=3D"sqlqueryresultsouter"></div>

<div class=3D"modal fade" id=3D"simulateDmlModal" tabindex=3D"-1" aria-labe=
lledby=3D"simulateDmlModalLabel" aria-hidden=3D"true">
  <div class=3D"modal-dialog">
    <div class=3D"modal-content">
      <div class=3D"modal-header">
        <h5 class=3D"modal-title" id=3D"simulateDmlModalLabel">Simulate que=
ry</h5>
        <button type=3D"button" class=3D"btn-close" data-bs-dismiss=3D"moda=
l" aria-label=3D"Close"></button>
      </div>
      <div class=3D"modal-body">
      </div>
      <div class=3D"modal-footer">
        <button type=3D"button" class=3D"btn btn-secondary" data-bs-dismiss=
=3D"modal">Close</button>
      </div>
    </div>
  </div>
</div>
</div>
      <div id=3D"selflink" class=3D"d-print-none">
      <a href=3D"http://localhost/phpmyadmin/index.php?route=3D%2Fserver%2F=
sql&amp;server=3D1" title=3D"Open new phpMyAdmin window" target=3D"_blank" =
rel=3D"noopener noreferrer">
                  <img src=3D"http://localhost/phpmyadmin/themes/dot.gif" t=
itle=3D"Open new phpMyAdmin window" alt=3D"Open new phpMyAdmin window" clas=
s=3D"icon ic_window-new">
              </a>
    </div>
 =20
 =20

 =20



 =20
 =20
 =20

</body><grammarly-desktop-integration data-grammarly-shadow-root=3D"true"><=
template shadowmode=3D"open"><div aria-label=3D"grammarly-integration" role=
=3D"group" tabindex=3D"-1" class=3D"grammarly-desktop-integration" data-con=
tent=3D"{&quot;mode&quot;:&quot;limited&quot;,&quot;isActive&quot;:false,&q=
uot;isUserDisabled&quot;:false}"></div></template></grammarly-desktop-integ=
ration></html>
------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/dot.gif

R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/logo_left.png

iVBORw0KGgoAAAANSUhEUgAAAKUAAAAcCAYAAAAA7n9nAAAKYElEQVR4Ae1bZXjjyBLMMUo6vvv2
MTMzMzMzY+D4Lus8ZmaOIXkMC7FzzMzMzMx8poDe1Pd5NuVKywrZ34J/9IJGPSPN1FRX98g97+zd
u2tdW6usLZ32fm1V1JtZ/XhvT33q9Rt16oUeGA52qo5Ej2er5KLHzcW3nN/hker78MjWu7XzeeOR
XbZpx3iVke0e4/t84G/Bju2e9/gfOwT8HvHwsq3XKlAOLC8ND2SKccOu7+Quq+bDo5zFavFoz5at
/Goj2z7d3TcxyzcX/q6tz5uLxmTMS5YEIPlwkvocaPe8V/Lh95veIxs+Ye0CZaZ4CYHy750CZPyd
nk3dhDxogbIyvP2jW4KjEB5u+dUK0Yfb9by1fPhRY8zJRbCMf5e3cZ/1QvS8tpNBLjyOxrxtrQrf
Xx0c39EBcZpA+ZVOgbKeDV/Ei8GGtmR2Dd6V5PdwYetlbZMZhfB2GotB9MJFsVYu+CH1d3+8omeT
tpLBv3o2c+OU14xZCFauVaDsz5TeS4B0Nva0joXuQrAPLcYULzSAlzihhfDSBFBe1bZwVwj/7cdR
cFYKwRcWKWFOoP4ObXuE+l3PFvVc9AJv5b9t9YilBiXC72t3z5TeaNry0gt6Mwdtn6wni7+cAWSp
0j849ibv2z809rK+zPgTkxKf/m+UHps0bn9m7BXO/8niK4sRFWkxzuXd60DwxYSwswf5uNAf3Oj/
78LrqAj5N3qL/xRtb+lS317OB6+YIzNXnb3D1rHpDFXLbvvUciF4mR/XadQ3uT4qa94hF32dNu1T
cM98rVYIX4zEKfF9RsMn8f0AqW/DPCT1i+glALZBuUdm1W4AVIpNOjucWZAAfXq6f+k2CuvMsv+c
w9i3OOAPqG8c92zUzDjBX9zf1+risAFYru1uYqgfc4LAjOX6/riGdUMjnpLGUPHw9lET8AvhtxFe
3b9rM77R8a3ACI2IBIk3XZJV8tu+WnXzIuzaWj76gMHMB1tyAZUF9//6HPq9HDo4EZQOaB9KBQaB
y7HYo7xv37dK27jrEyl+bK8VQF8/D99vsi8YQ0MgQCLso5P5GwLxjQq8ajZ4Mt37p1Zh3S3EVgCW
bgI1lziNUD9X+qqASIh7sckSQnMfVQnSrIrngh+AAsDg+iKtzpk1npM3Nm9GV4p7/Tz6LT+Y23bn
BFAWf+8Xvj9TfNABbwXMsdMYWNAA3e857EvbId7fgf149/+HBdQ/8L4At7SdNONbPBIMKX0/vPfe
K3YgjfbFpqw5t/2zudxSyYX/4/fExDKIkAkDuNTHHQQMgOEiCetSEolem8RQskjTdN87qP8S+3O4
pPLRl3UxG2AGU62ACUBOYnYViXCc94ExewMguIaEpaFPq83vFnx2zSYb3eZZ3MabEVGANwiNtRrP
ppvLs6WlCc8hUB6g7X1DpWe7thqB40IC5TcZNF/+8vBm7Nu/vPhWAdb3aNxPchv0I/t+5zvHboqN
wfegP99ey4V/40ltlIf+xIsgjDNOIDsNAGTgYeIkzE9ZYZ3G/yaNX+OyDoWyaxI3ST76adPi5oN3
SxL3FNKKsMsBNCmJbQyWpXf4Cb3vnuQ77VnJ2HSwo5o3U/jJ5igUflqY25YLufBIajshRc/H0MO4
PuskBnqRMud9uX2G1YpnWsVxMBpdP8Yoqr+YQQUgcsGdZYGV0LjrH2F//J8m5xrRZLpTL09gtWm3
81+JRcK/adfupYkJh/WUOudJRtj9IydUKvABdB4DIJfi9H8Y9ACpjlHPb/cctFtMDNaz5gKGEx96
d2yY77SqpyLx0efSzag1Y5Sp9HkV0DhRI1DaTIZsOSE7v5ruO98zmYTn7xl+X+T+kYlT24XUtor8
6PlKveyPzB7XscDNYSD6uRHu7iU2Octfx6RaE4/ShsliEtZJr93HCRO3A/TMtNC6LmFYzuaeNY82
qfVRcsQJQ1RM0JsDXBKL8+EO1HYrMVKe/cDKPDZkBrfjfTgKcXYtYf8krRlraGZDMsqa3kx0HAh/
yOF3cHB8c+1o768fFLCuRMZssSDKOAYo/85s6K9DG3LBvX+ouJfJ0EOlP/AYqBQwoPQURicbSYVo
z5oX7e7fOWYy7HTNqjWsi14zGQoLiKPDBSQUVxJo3isL/HEe32at4Hwu2SRpQhg2MbVPQGoI2E+y
ZBB0L/mxXNCa8SQ2lj4vzwvqtiYokYxY4VdC9+esEIxQT9cnAN5WDLv7UHGNpnK1z3dxn6iFqi+Y
GEBWhubQqEkCwgxfb5xv36KMpuEfoViy6iqH9RRtNAUNqgu+AJsCOFSvKotLInQT3ffHJGmADyYk
PJ/G+loL46xlccYtWlM2o3mmf651oiVJX98sUIIVUey2wi/fAzDMsGHxTpSBGolKia6fqb4Dg+PL
BMwDFJZ/xhk/AJi2GRDKKQycz+HVX8d5tzDM4Xwfdq/ueNVzKExbYpwNoVYZijbFJPkD+Gclmpzb
Y2wBdqKmxZdQaONqAoFulNpuYT9oQEQMlT7ekLjIhxZvoY2cU7kgNePEcpyyP7L4WaDEiYml17hk
g2zcAgaSEmYxnOqkJSnI4olBT6G2w5Uhnaz4jOjVS7y0iEe32w4TQsA7kE88ZDey7vxqEpMgEbLZ
QEKn6jViKIwtGe3dYIeU48EVsgG+3KhtDumJD8sLGDJiTRqo3ytVQ2st0c76dWwKwxR+dTNqzdhp
5g8Z7/pLnhtofQElmG4sI5ntQVQjvNpn5Rx+fYaMkx1uw/m3pQcJtPd96EMrNqGCe42Y8nKMC+ZF
eQr34jr7MqARMoQhvsXjUt2O7RIsKgHvn1wcBnto5iln6pcTu51rMRTCnBbz5/khBexPDc36QuMd
7kaoRdkFxvID//Z94vtM8fMRSmuJSaWiQ2kznN0i/P5Ra8Z6+iX690yDSASUAGHKKQoBp0BJkGbV
032DxV0MPXk+F9Xtgnuq3ah6E+JaJv2tdv1N7hEtxpkxt2FCU4/zhKFQuJfC/GnEBImGBERKLyeb
J0Ephpqt9wNLcRvKRi2+P72oRVUB9hsJv6ZcwPiasLHJ8SPYeVBA2Qi/zEi2PYzQirJRSlZ9qbRr
/ROgHtKCu2XcJzSu9SEIFo53OmpuOulSajm61fEkyj/WaQ2AJfrQsmvAwMwC8FEgiGnpKJYqwMYz
db9gP2JE0/TjEzmlug9AS/7+NPhLq6oCn3tz+FW5wM+IzaTviY8xLO3sjU9pYrKv8M8ZwHyafGgS
4+9FmcZKkLg/hGwC5eGcIPF9+GqI70377N86mnsot82uvh2Gr31U6Ce2i6GkxPc2jipvo/D2Z2hJ
vocXK83UFwZQpv7kQwwVAw7f+iwMSvaDPm/1Uw2uT/K86s9N2AeViNSfTmCjKCiRCVvht90GXYls
mxKnn1H7Wm5ai+Md37VFf0+JpIUTjU4NDn0o9cl3rU2Tg5OWRkYsFhW1II5rSzh2F5RIICi7zXdq
cJzcMEPjpxRrFRNSob2VQUNSmFqsdUEJ7cZshSJ1pwbHGbd+bbS2GLROChgrjeRnT2jBpRu7a+vc
A3etC8quda0Lyq517f+4E7RgAfDP9wAAAABJRU5ErkJggg==

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/window-new.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABm0lEQVR4AWIgFgAqoweYraIwDuB5
ynaN2eaM7IZsa2bGlD1vYd6ya6wZ2e7Fh3uPrl/8e85rb9+z/Xb8vzhQbYZDtVsD1WFfum0zOLf4
5PmDlQTVvHx1Gd8/rwWPzoBrjEq1RnjqbQrplw1AzQquA85cwN0F+Bd1mwqhN1meC0gmkxg4+0RF
hy8sQvj3UEh2CrqSwcXUm9DnbM4FxOMxjN90vaIDV3fg7fspYA2bocQZJPNvMDMXEMQC+L6f4/le
mufBd98gZh9EwpqDpD0RCXsOvn7cQgFtWuUC9EbHcWATxyaOZqfZxPoM37pJrsBzXuDp87sovAW4
rgtLKagSUsv2JbVEh9OZ4gDbtiG4ABeCWg6uiXSbwzgYZ7TXKg/QTzBNE4ZpwDA0E2ZBn9oc2lse
IKVEQ0NDRn1KfX1DgcwctUKK8gDGOOqiUURLRaKIRCKZPrU0ZoyVB5jMRCgUJiGEwiRUHX1aeYCS
MvWDOKUzLfvTGMvJrZW+wYNHd1briSZa2aykWpA2pB3pQnqRfqR/pu1J2pPWJFf/AQXhve7200II
AAAAAElFTkSuQmCC

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/s_vars.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAB0klEQVR4AY2TNZTUUBiFcS2XDu1o
cKdE+gp3twa3Bu9xd3d3aNEGd7d4MnFPuOR/h33rMud8Yzf3S541AcAoXp0K+hcMaoBuBc14r5Kg
fxRFVpqmeZZlqI0ix44dO7ZySTXBICp7ngff9zm2bcM0TSiKwiSSJGHnzp1cUl5uSgK6IAxDxHHM
PgnXdWFZFlRVZYIgCEA32bt3L5NUEVh+QmUOCajgOA40TasxJOpwQfuu/Ycvvq5ixmWZhXNv61hy
W4Nuh3wouq6zJxFFsaqg59rXZSO3fXi15JaG2WeZAAtualhxX8eiKypUM2ASehKaD8MwwAW9Nn0b
N/G8Ei6+qWL2aRmCEbFQNGPMuaSA/p98RsaVpwYbDs0Jibhg7GnJXn1Hx7gTQvbyu0cB59VPHxNP
iVh+TcGEQ3/g+RFJGFzQfenHcaMPC+GCczKmHvgDQWNPwJ5kxjEB9P/YA79x+aHBJ5f2Q5U56Dr1
adnQVc9fzT4uYPKOnyycfkTAvDMS5u7/Dc2KkCQJQWWi5iq06tB7+OydPzF6yw8Wjt/3G3P3/kbJ
5uXK1BDwjVSdNE1rpS7BXwoaSc4F/yUDignyKWhMubjWpQNYWdCZJGRtJP2p8w8HzcqYlw2KtgAA
AABJRU5ErkJggg==

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/s_top.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAo0lEQVR4AWPwySykCA8iA/bt2/ef
WEyxAfQJg71790rv379/3549e5RINuDQoUOSQKfehDr5IdAgBaINACqWAGq6AdX8F0rfO3jwoCxB
A4DOFQc6/RpIE9QQbSC+AOXfAXkL0wCEs0WBiq5AFd8EeQPqIhGgxksgcSB9CySOKxoPwxTt2rVL
CiiGbvhVqOHHcaYDoG2nMJ2J8B5IM83TAf0NAABfpaT0abqhcAAAAABJRU5ErkJggg==

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/s_theme.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACy0lEQVR4AXRSA5AcQRSdUsqMbdu2
bZ5t27Zt27Zt2/bOno2XrpjD1sMHBeCfb70d961aGw7LKivW6gqLjxWlZm+dio1f3f3z3F/ABnue
bXW2XOGtvgroTbIGozgIjAJ/dMebo9pFCDm6j1oyte89+xcBAXPL1dlyzvQkWGCyIRmLdexA3WEs
Vt3CRHUsxiuj0Z1kg1J7HiSpXjP+QdDowLuKWPboitDHfAwL4HsEi8E3sVJzEugWIyRHMBiliYFw
NYwWB4PO90e84oWlGPmzJ74QEMsGXZEGX1RXAk4DmWJfSMYyBLBYfhnjGSzwin0N5cQrsIp9AGZh
IOr9FREhfcKVgDlPV1uzLU372WCG5ROmDF5hMeAKJkLZMBCpQVRV0R+iBK2EG3As5IIKIRkIU0dP
vCVCJA7XUSTLrn3JBCwngWk9bYzdvImRVCuMlUVgrDQMY8UhGIrRR3YwB8xj7yIh6D16vaUwmOKI
AJF9NFVu/qGdLgoCHagHWuQjhixECDgc1e7iSFa7jnJnQTBJzMIu9tjvGI5nju7odhXAcKoTfAR3
zVAlJq9nvqhVRIGR6YSBCA2SqBCQLAMAFatwDnSuD045BoElPo+QhKHDlhUjhMCTbyuoAsPnNhWO
fGgKUkV3nDnoPF8wCwJRRtZIllFkywk6yxO+Dkp46OABazs1DMWao9FfGW7cGxu/VIE0xq00jVu6
xHJCovLlyQY/BdA53l+AdKY7en3l0GHDgnarj+gPVMVggg0SNe/AmXPtp786kVg+GiV7aolBgN1u
wl/sdlh/RKcdJ4aT7NEVboBU3Udw4lhj+a9W/vKGSR4NqSJJHElzRo+XNIaTHQjYDsW2XER13ZIj
+xpFANR/CYLEDp7wF9m7RNTQGqSBos+bnPB/TbEhyMkbZ8QJ6+LJTAi8OF2xCBjKn+clS52fnSg+
AehkY2zqQARFGACfTM1hiNmumgAAAABJRU5ErkJggg==

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/s_status.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACH0lEQVR4AWL8//8/AyWABZlz7ty5
+YC+yRncji6Mwu+ZmWv/jG2bbWy7iruwiZM6Ttr0T/rnsrxoYtuuoqPRRvbsmMXaXu+3vgMhxKo4
jj0zY2arKIqS+fSiRYuW/xJw5cqVKmM4VV1dvaioqJTQmFAKm01ramqqaWpqWAb8DLh8+fK0xPzP
P/90LCsr49HjF5i98WuUVmBmaWBhGP66BfO4oUuXLnbj+wGxMV+7csEA1BdNnjLdtvFLQNJjYWEh
6XQaW1lKBgwcZqvrT9W11r9PkJClMZlHRtjoVy6fM7M0Uvau/cy5f04AWIB5bAEDB49Iqn9Jof/w
GTiG/AVgIUll+al/JyKt31D06hE7yx+jT2zUcvus9E+AL2ZrtLKgk/eG0+BPZdezsVBQAn93Au0U
rLm5rNxolW3BRLNmwEZWnyIrrfn//xJ6VaW4mS+EjIDIKCcB3jopz1t2ZcFhmyD5FlzXxfb9bYpI
ISIQeY3yBTqUkBf4IvaqqCIIgkrHJDjb2tpKNpuloqKC4pIiNCkLio1RhBqZ0xDE4CcSxhiaMDG+
HxY7a9euHXv//v1Z9fX1F9raWigqTNGtaye6dOmIzIPwEwDWSCDQkcQPAjJRljiK8QA2b95cB9Tt
27dvys2bNw+Zr3awEALZ4QCiDFSg0L6EUgFC2V9s2snghz5//DsP3/ZEpzRoo4nvWnSJR+p53gsv
9pGedvKuikvEB77osGdM5SYIAAAAAElFTkSuQmCC

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/s_rights.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABlElEQVR4AcSSA6hfUQDGf3dXs23b
tsJDrmUvt6wpLXPMroUxc3G2bTz/zWue4czWd6wPdZQ4jvkd/H8CraOjYxuwCSCKIgShGD9sYRh+
Nr5tB5X29vZg8ODBKoB0I+dfHOX85s2boZYuVF3X2XM1xLOqFB+eIvbrdBsyg6ET5tDc+wmTJ09m
24kSluNh2WlzfA5vniwcqNqHqgsfHCBov8zLlhZeZC3inbcQ8H2fXet6pPZNGQsQBGjvFoiLwxaw
du4oNhoaZ6/c4aaqyounT5/mQzQ2Nr4hEJ2AH0RcyoxE04r07tuXq94yCgUHer8hWL58uVQXrj9z
UGp5xJAJEzmuLaTwyqP7QIPh9TZ58eLFi992MKpXhbv5/kQD+zNgmIFTcegTZYEe4iKLFi2S2d9B
rCXBlqYV8sCyLFzXTS+MkbZN06Rfv35fJ2hpaSGTyTBo0CDGjx9Pz549+RT37t3jxYsXjBkzhjlz
5ggClPQz3EtJZqSNxYsXK+fOnYu/8Ptka25uVpJt3rz5P9Q71wc+MwEA4UA56LRrcQ0AAAAASUVO
RK5CYII=

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/s_replication.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABVklEQVR4AZSSNWKFUBBFLxrd/0Li
3ZeejkWEFoc3MxeL63/uZxQkv/Xb+7shyzI2bcv9fs/nouD+eBx/ehvih3J1dZ32fb8+yPN8PYvj
KPnh6c8AJw5KwszQhCGIbX06wDmY6vrpQmU5mtf0A7zaqKIAPTUQEajZ+ilcTYAnwM0A1TctwA16
MmAYekRhuEp9hTjnTgeMziFJU/ADYPQBBEG4qswFNo54enxE09TwyoOmruHmz4lzCBZH0iOMVV0P
RqIfBkwzt7BgMDIyYnj/4cMvrK5FmIwJ5s+ff+bcuXPnJ0+enArkEu+CpKQkGSCOYGZm5mJjY5MG
sZcuXaqCTS08lC9dutR8+/btCyB88eLFJydPnf5/+MT5/6dOnfoPYj98+PAlTH7JkiVpMH0sMINW
rVp1mYWFhRUY+szARGTIwcEhjWyRhobGjevXrx8HsYHyt2HiAN8iIe1lQo+jAAAAAElFTkSuQmCC

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/s_reload.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAB1klEQVR4AbWTA5YcARBAc445QGzb
XNu2bdu2bdu2jb7MvJ9BuGbjofDLV4Bz/ZcDcBmzdHQaMhPs+02w6TbEsl1PMG3WdjwW4DZhJXIZ
tViMnQuifDOHBqGM2p0S8lfS8BtwQ69SdVGrVFF0KMBZ4py0EEGjUE7FVj4120VUbRVSuJZByXoO
/n3uqOV/WzwQ4Dxi4Rg9G0j9rjxq2Xou4WO+hAx5k7uUQuFqJnmSTOwbzfmW+t5xH8BhwFQoXs+i
bCNHFs24QVOsX6MWoVOuHKFRpCBOno0hazGJqLFgPsW/FvYBbHqMJOkWUbGZT8iID/rVahG/dSq5
X30VMj7yNfkdH+Nf8TbqOfsAkk5LGpcnix444IF2mdIfwI/0jxw7RtMmbSFjPp7MxUQyFhJRK/gu
Vsr+XCPVfUl6y4fYlxwJMKxVd/TotidnKUUGSV2Iw7rWmM+JbzAp08OgWIsXwY84cg80ixUW3Tvs
SZ2PJWoqmPiZCGKnQomaDCFiIhDNHGUeeN7mUIBK3leRQuanRctqQwIHvYmWOQYRNu5PyKgvqhkK
3HG5sQ+w75d02lHS6c1XoU94FvgA9SwlVNJ/SJyvc6Zjuud+i9vO+5xPDrjtdO3QMf4EDtK86uth
iPsAAAAASUVORK5CYII=

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/s_loggoff.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACOUlEQVR4AZRSA49dQRg9F7Vt2zbD
9lfUbVjbdhvWRpwiqN2ocW3b7Xrvnfmw781db7STnJzoaPJ5qorKvqdH52wX4QXMlB1WRvj8+PzX
Ity5apPmeP/hKRr6VanYYP369SoiKAIzF/O03gofgqqNm6N2h84QFuj7x7A2RrEBM6N169YAAM/z
yrDqEzQYPAqAhzjnL9jGUBVYS/BLGygUd6KrxeIiuDYpRBlfYPMyIdZAhSs2uJF/EZkmA17NEjEA
EBkIW3CaUwA8qAiMiUoMXjR8gJbNWqAB18fpd0fAxCDLjve2GQglSic7E2hiQDYxwMTd4x+1b9Me
fbr2AQmhe+dusCm2bHH27HnYJDnZThGaNfmFN0owJkY4Yde4k+1btu/Tp2tvZEQZyLN5TmjEolZY
G0QM65IJnBLUqfUfDev/RZUgH9npBlcX3Z08ftOIQflR1KtXj56oFlRH4IXwOUTMxs2wNoJQ7Bpk
/Asg1Bix+VHyiXdW3es9bulIzY/yQUR4+/Y9mMTtFxZXVchCbNrE4m8cAiKuWfEndvzVDe+9V/A1
wKJBy8vcAj07lPwB2RRieF7ojozIFN+BS57aYxaU1YlKw9g4EadYrHFQTQzC0ga+72Nav1lOVLqB
tcmEmg3aOKY4D9AfYCaEhw4d0hcvXjiDgq1fvx6W/lHoCKVvDNdO7mJg5+BmYOPgYmBlYwe7AJix
GFjS0tIYCeXCOSlyYh/efFH++/e3JtBWNaBGGSYWtgigFDMAJJigdsmJrWsAAAAASUVORK5CYII=

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/s_lock.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACYklEQVR4AW2RNXQkRxRFb/fwLDMz
M2SbmZntzJGZBJGUmUPluZnt1M7NzGJmZmlmCrf+EcM753XxrferI+89y/XRRx9tdM5VWWtvBG8P
Jng0+EdjTE1lZeU0y7QC8OGHH14Nh7/av3//sc2bNxPHMWFMsVhkaGiItqAAeqy6uvqv1QA5vDEs
/nnixImTSim6urqYmZlBEiSTSfbs2YOotra2Ocxdfu211woAMXOSjS/t27fvpNaaxsbG1qmpqaOh
nxZLv6GhoVfAId3JUEoZzCkJcwqTN/L5PC0tLYRDD5SVlXWwpI633377jo6OjtqjR48ie9cD7JKa
w23Sb2OVZE7ShT2SdteKN+j87mn/Y8sZBiZysshDF34j4TXeGryZs9aWd/+6jjzqnuwY9x/4jTPP
/xHNJfCeJx6/lYiYKJEj4l5wESSzgAersWaKt+6cAacRNX/yw1IJchN4zPBnJDM7iaKN4FKQ2wre
wewEdrIJVejBmVlyx8rwqoQoBpCIOLlJMf7/74zX/gZxRNc3NXR+/T74AuP1/we34Y3Ce4vXalkC
o8F7vNVsPXOaOL0TIoctWf4dznEYxdYTxyjOZPAhAd4JYFkCrREqATD2318hxS8QG1zRUSqUwIdk
DXWMN3bOlesEoJclkIFQbbjp1FES+R0QK44/+QLHtYHJAbac2E96MjWXwPnVAIVQnZE3+D8ANkF2
IyTT4AQwTmFsCD0zxabDm/G4AFoFkBIyB58hdyRBlM7M/cI4Bc6CKrCpMIXVJbyMvZeHXwZQJVq/
qpJYsiB08bK+AWul/mA71xcQcBNQL7jZSo1CSwAAAABJRU5ErkJggg==

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/s_link.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAQAAAC1+jfqAAAA30lEQVR4AWMYMkCPO6206d2c/5UP
08wTJCrvzvnf9C6tVI8bKq3F5tHV///Z/9v/9/+vu1d+6NqP2/8P/e//79GlxQbR71fw4dK70G0e
f5L/T/hf/j/5v8ef0G1LHhZ80PODKOiq/96f7sNl83n3/zP/D/xf/d/msw9Xf3r9d70usAKdzJT3
k0v8dtr9cvnvD4Qu/+1++e2cXJLyXicTrEBV0/N61/vlb9f8n/o//38ZkFzzf/nbrvee11U1Ia5k
tjJwv5/4JeN7xs+QuBDnjE8Z3xO/uN+3MmBgHhyhDAASZG6qRiLOyQAAAABJRU5ErkJggg==

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/s_lang.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACWklEQVR4AXyRA5BlOQBFd8e2VRjb
tm3bZtu2bdt2F9q2bdvulzt5Y/w/tyrOOUkl/wH4q9xSCp5BiwMtA7SASwmlZRk3gY9LRCGGhhlw
i39CGSsp4gRPomWYIQTtvQQNnQTVbQQVrQSlzQRFjQyKaWEjZh0HToIl7wzCwaamnaCSgiVNBIUN
DPLqGWTXMsio/ipQcU3BP2/Anl5GTy2gcG4dgywKp1ezgmGwkbCN/wk+2zJj1Kdds2R0z09vfyWo
OMS+ASv5HvYm6VUMK+X8BkL7ZvAYnh0H9TNjoHFtPt7wSeCWYiC7CRbBOT9EbV397Jidz/rtF7QO
jQtyEzqNcPU7ULm5Eu/3TMDj7ZMhemmVLd1YXNfa8x3so0XiO/dDoHdlpk1VnCs601yQ6a6ABGtB
pHlrgk9aPcMkMJsFu2nh+b7/L8H1c9f4850ESF+uD1Doi/48fyTYi5Fb8r7NFHz2E+IgmHvOceR/
W42MXbVkSZH1S+Tb86HY/h2s1eTIiE36BrOOm4zkKph2yuX/kXvd5IX0SpjgZkDINxY8rnF4ZxMH
83TgjVLh8IgddtKTDhn9z1Gw+4oqv4CcH5zzCHgTgeeRwINg4IYbcNuBQD6E4DGvJ9lzXlyQo6BG
bS0SXfXw1rUBjwKA+24EN20JrlgQXDAFrqk3IsXTECWyq8BRUGx4NsZO6D7O80TiSQjwNBR4HEgL
be95A0efBMBL6i7y9T/P7yBWA24tyxbaPSFZzzhsWaNq8OYnutE7v+pF7fqhG779q0rApjcmgXN7
901I0Lm1PEcImwEA3ojcdGrjfoUAAAAASUVORK5CYII=

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/s_host.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACFklEQVR4AXxTM5hcURg9D+t9a3vb
2GhiW2WqqAyqtOlitWEV20YXD5rYtjW6d//z7qzxz/fPeTq4srTW6KoCgcDOeDw+NxaLuYIQ9Dsa
jRL3dioQDodzhbAtLy9vTlpaJiJCglLwvxZOfn4ezp07AxcdVCgUmkByUVFRZVZWFp49fwO6K6Wh
tAIEEyIWiUTg3rt3L5JIJFKl/Y8aYxK/ffvWNjK+fv0GJeSx4yb6z1ySq6pq8P37D7A0fxrSguYC
CkBBfi5OHD+G7j360p3vTAKqkrx8WwCABcuSf/PnI/vXz59Ys2ig7xgMXAfTlk+ebhIwKl35YX5B
IWzbhiVNbLymgFbGsUevAbyWNnNgM4HSNLThOE6rtpPI4uTR8ZP3DDu+b+KwTIKYWR5xsuC4bqO7
QUlFNCtnHHc82Io/v+JMYQT4p7UZAh3rSzIZB6YsvP0RTyYwjssKV0AVGEExNwJ2cpzsJw/RYTm2
Q4HkXjAr1ZQgJcXFqvl9kFBUjePv34jvkJqaAtuSjwFB8y5BpllGk0DGteHq1cvDGzeKYIHnefVc
nffv30ckXRqHRl6Pnr1QW10BVllpMfhNq7OwefPmJSIybdDgoaM8Lw+HDu75J2u+27KsQfK8Z8td
ypZ395sENm3aVCxL9nHkyNHI9jz5IAHXsUV045+NGzdmo5Nyk8joX6XvHDiwrz9d2A2D2ngNX3YH
AIbxoDgxJA5OAAAAAElFTkSuQmCC

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/s_db.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAQAAAC1+jfqAAABD0lEQVR4AVyRs2ItURhG1/Fpr21b
L3EVtOnyUuli8wFiJ11cxbadzMz+jrn+mc217RIpUqTwxrLOgHJVYN7rjYyZ0qwpMZ35DgBCdHxs
Hx/Tpk7kyNaeFtWnlv7mR0Ixoa17SUbpWBpVQ4UQbgB9ukc2jzB/knswiC2CBPAhztlnjVcYSBe8
HHCJsDnmCi9KF4TwEMQbDgsbAYbYIdyJGWyscDjhsKO5MKQL0Q47KlixWbJniDXbUTEmWOmbNNFO
g4jNBobr1AwO+9whQAwXD/jFOlbaEoXDZzPc5CUPecq3sDDF0Kb1L/kWoupFRUnZYYWaVKcihdb7
vLOrTQwigxLds3j/qPz59/tG8U+EGABe3bTkL09GswAAAABJRU5ErkJggg==

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/s_collapseall.png

iVBORw0KGgoAAAANSUhEUgAAABcAAAAUCAQAAADMt26FAAAAVklEQVR4AWOgF1hstOzsyv/oEKfi
lf8vYUJcGiCKT/7f8J8oG1aCFRO2AaEcohiHhqGhvAwVkqicrm5HaCBNOSLVYMJlZ/GkHEyzFxsR
m4jBioHK6QAAW1WWhDTRaxwAAAAASUVORK5CYII=

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/s_cog.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAQAAAC1+jfqAAABgUlEQVR4AVWRQ9okQRiE++kD9L6O
0PcY27Zt27Zt254pG2ObOV7VNvP9rTQ+RUSBRj0e6uuOrg9t/Fa7PS5npbjo//7ON879vlG8Ujpf
bmTweG8mI+FplvjAe66Iy9o5cVIe3Vtr8GjuO/7xFit/oF7wjEvqXB4juMnaudUG0XxHveMZr3nL
i+r9CTEBs9Xk+bUp3OXPSAi5wz4OY+FhcpPVy6tTBKnz1fj/ipR7LPFmNlvQbKNnY5Gy7v/Kr0vT
giN/8YKQjOMsa1bls6fZORzu4PGesbKgyy88wSPlMlurDbY3O4XFTQyeMFgWjqYbvx76/xCPhAPe
7mbbKlOY3OM2w/73+to1rS7y3HIXExefM5zE5AHXOcPo5bU8nJ1/Qj3HJeYxIT4JLveJmaBG1sA8
NvceHzjB0ny5crAYrybkJ3jCIrrMreVh8d6JcpiYoS0VMT5DRB+tl+ggW+9tJNbE8pjSnOLi3/e5
Qt/ffYr9Sh0axGro44f20jvrXZrIXQEJiF0IczJH8AAAAABJRU5ErkJggg==

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/s_asci.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAAAAAA6mKC9AAAAAnRSTlMA/1uRIrUAAABNSURBVHgB
Y/zPgAqIEij/9+fPn9+/f//6/evXXqwqCoDSQHkwOINVRSpYOwTcwqoi8hcUABU+x6rCG6YACD5j
VWH7EygLkv8DBER4DgChelgBwxulGgAAAABJRU5ErkJggg==

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/console.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAA60lEQVR4AbTPMW6AIACF4R7HxQlG
V1dcXR11cvFSXsPLKFoikdgYgdcqbSTGtjWmJD8T+fJ4AfCo/arruvkIN2t8AH0/QAiBUUooNeFt
nrEsC7TWMNbgdHYEPtC2LXjHMQwOknKEmk6QsT8DX3HeOej1WDR/QuuqYY29BigliKIIcRyDJQxp
miLLMhRFjrIsUVXV1gZdA0EQIAxDEEoPiB1QnjtITep7wOUgSunlIiHE74APEe9rCWPoOP8rcFpE
3KLt7V3Ahx4Arn8E/N73HETjwSA9lGamIzADwBgIOIBYAogVCGAJkFqYPgBapaHlaM5KIQAAAABJ
RU5ErkJggg==

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/b_tblops.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAB4ElEQVR4AZWRs4KcYRRA513yKrFT
pUqZdm3bHHtirm3btu1t4sXJ3WmC8W9851wpAI+n1WoNMJvNMyaT6cxgMJz9/c8jbLFYAgT8urW1
xcnJCVqtFp8EAs9sbGywu7tLfX09KpXKN4Ferz+T6IyOjqJUKjsARV5eHjk5OWRlZZ15FEjK58vL
y3R3d5Ofn9+em5vbWVRUxOzsLOnp6e4FGo3mtqR8OTU1RV9fH01NTTQ0NNDR0UFXVxepqakzTsHs
4k1lxvuFUUn5rLe3l6GhIeROT08PnZ2dtLW1kZKS8jUpKSnAAc78uK401++ir9kh5+McExMTVFdX
k5mZeXmVskQ9S05OnklMTAxwaGL6FVy7Q9PoKQ0jJ+SUbBBtmiAjI+N7WlraNcds/xKkvl9XGgRu
FPB92z6vm/eo7Dsi8c0qzzIn+h3hvwTJb1eV+qodGoZPeNu6j7ZqG4uUUdJzSKRthSfJ059cCuIF
VlfuUDckcMs+6sptTJJJcdcBEdYVHiVOFrmblCLStkzt0LE9ZWX5FkZpXlHnASHmFR7Eu4ftAn/d
otR6jKluFymDzwIHC3wndrzUE2wXPC+cH5JG8bnjgA9tBwQalrgV7R52aOLT9OlpaRT3Yse5Eek9
jJy/AXJq+VFMYm1KAAAAAElFTkSuQmCC

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/b_sqlhelp.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABx0lEQVR4AY2Tg3LdYRDF0zxEB+Uz
VK/XPkBsG9fj2Lad0bVtnu5JcrfGzpzLPb/F9/1rADxI4qXovejTP/RWVFv1KYDmXC4XKxaL5VKp
hN9J/kdbW1uzQn4CfKI5lUohnU6r4vE4otEo/H4/CPF6vWhvb1dITX19/fOV1XW32WwuLywsYGZm
BsvLyzg9PUUoFEIymUQsFkMgECAAmUwGLNLd3f0IsdpsB1dXV/5wOIx8Pg/pAjTc3t5ienoaNCQS
CQSDwV9GetiJwWI4kaSwUBVAE2UwGDi3jsKO2InH44ECxkxjp1IhyooulwsOhwM7OzugYXx8nECF
sBPug90qQGa/koTE/f09+OfJyQkoxsjICBMVwq64E4IUYDAYb2WzmcvLSxCwv78PijEwMKDzFgoF
jqjjKcBkMp8SUN365uYmtra2wOjp6VEAuyCAYjffAUyncsaZ6+trcP69vT0cHx+D0draSiPFDiia
fwTIpfi8traW4XZ5fJyPnRDU39+v5p+lgImJidrBwcEvnZ2dZxaLBZOTk5DfsLS0RCABv5MCqtf4
Gb/IjxUR/lNlBVASH2RBaf7xP2bJTfIB/B7wihBS/1Pv6fkKS5b7POByH6YAAAAASUVORK5CYII=

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/b_sql.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACb0lEQVR4AU3RA6xsRxjA8f/gnNV7
e/3sqEFt24pTt3HDKmrj2m7UsIjqoA5r23av13vPOYPOyTT79kvGM7+R9t4DcMUzfxwG3L9nsnrk
oHCUqXCOoXFtoAssARZYBZaBx4FXNTFwxhy+/6Z1R153/Bzj0c/dxCCk1TW7LS+gm1l+Xerx0k/9
U4Grx4GNzVQA8EfLkgiBFqA0VBLJjopESUmi4MBtNbZMNKYfff/ve0aALYpmQ4Nx0M0FSoLyoA0o
BVIA3rJ1QnH9k79zx8U7eefnZG4cmF6fSvoZ9NcsUgo0xMUhKQIqwAHCdnj351U+/r39914gzzdO
1BTtoWGQ+QB4lARp/z8NvsTAK+Y7GQ+89mMHuGIEmDzfubGZ0F7zGAAPygqCAzYC2kucB5vYMN/s
fuGao1fGTpDt3DRR4Zt5i5AgiYtltAAQHnxIJsuwhbEAGuCMm16uaSXT8rVza5F4CMkDgYuLASmh
sJZef2CAzggwWT7XaFSR8ZHAgxDxFD7WAUEtgeVeVs6ff/3m83wE4vHrupGiJaigWCfAexxxsXPx
B+pasrg6LOf/DTH0sVc/OQvcdNg+O/i34/l13hIOQzWVVBNPIiBJBamCZh1+/GNQPvj8CAjfdzJw
9kff/MLqUNPLPIX1ZIUgNw5jHc57picmuPK0Tfy7PCCsWWQEFMVB55+wX+2Gi49gPKynhAICeHjk
5b+pJ9DtDQhrlseBX/5davPEa98wua7GZLPKZKPCREjr6ymVVFLRkguP3RhKWFzplsCfI8AZ8/Sb
H3y7LaSdwExMTMXERDVNkmo1odko8Tqff/fH98BbxOA/iwcuZ6cIc5EAAAAASUVORK5CYII=

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/b_plus.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAVklEQVR4AWPwySykCKNwVq5c+Z8I
fBaINYDYCKQHRfOlS5eIwiC1MAPQNZNkCEEDysrKQHjIGIDQhA9TbMBwC0SKExJVk7ImEPuAJIjE
RqAMBTOAIgwAAnGjlqctK00AAAAASUVORK5CYII=

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/b_plugin.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABx0lEQVR4AaVSM4BeYRCc88W2bZRX
x2afLmYXN3GXLm6CNk1sdLGb2LbxZnZz/57xqpvm42pmstwddUEuasHaG8vvmGmAZC7pyPqizROQ
guyawcuawzCgT8M+6NW4VxalIqSjZoLVQzd9+sd/PxNP8PPfT5C8BaQjOFh3c4WbCZJBFqv3a9Y3
i0bcfH3rK6kMskli16R9zWpwIBN6N+gFc4O5w2FZMoM70L9V/yZywd1w6dHV2kmUBEWw4dWPZ/jy
5wvojGTZWTkwc/Ro0gskUxJQuPPhDhrnNUGbBu3x/tcHyBWdyf/GSggtGrbA9D0TnSRI4fCsE1lV
fLDkzGwvbhl3Pt6AzGAu0A1yRfKOjTpHNw7DmSvncXzumawqPiAVn6lYodLg6CAns1rsHfG3YoTF
p2c5KTQtbBqfMhIGJyYwOrGofu/ZfTx/8+KfpHypIkFkG9CmHwTH42+P0L/54DJFYn309QFklgnG
iflnC2qQmJAghBvvrmFgyyF49OYxXn14DUlo2aQlurbvApnSVWDCqDCgxWBQFsH7ZxzMAoAxW4d7
53adkIiglJKAxOV7V+JDqUR/Koilnb14HpL9lulbrVauC/4Dx8Rt0PMiD2YAAAAASUVORK5CYII=

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/b_newdb.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACEElEQVR4AWL8/x9AOjXA2AFEwfk6
27Z9UW3bCtu4CmrbjlPbDGrbto1vm+8l2do3ySyfZuFHXSD/enL8+PFgCtiVOMDn85VQX0j0Ee5R
/4z61cTj3bt39wofrkA4l9F4a2JiYlVKSgrCw8MRFhYG3jcajTCbzXjz5g3UavU5Wuvfq1ev92Cw
AfPIkSMnX79+zen8v4Lb7fbfvHnTv3379vXCTwqAwZPy5ORk/Anp6emgJB1+OANa5CBQKpUICQlB
cHAwFAoFr8Fms0Gn0+H9+/fIz89nW/wygFwuh16vh8Ph4Dk8Hg9MJhOcTifv8drPAwhNMpmMK2Bj
Jkg3B+E9kQher/fXFbCxcJJIJGws1iCVStnm9xKEA5Or4Tk7P1Jex3PDXVhummCzWxN2jl826cDc
27N+CMDGTHYUAW69PQet4jFaNq2PjLhCnLy/T3LpnnJm/WFpMdKvAzBFdnYU5V57cwo1JdXwSr2o
Tm0Dr8SN+pUNQRgqArADXxXoJfIV4mtoTEooJBHoWjocjJGtViA/qQqEkK8lDLx48eKO0tLS8Ozs
bA7Ch8hVwGw14v6HC7j94RzGtVmLeUcGIUTGSeD45jdu2rQplwJNIvaiE4/mv8Byjj/aA33kXTSs
aozClFo8/XQTF+6cw7uXxsW//M4rVqyIJOcCoo8O9dHOl4unAxgCIBKAGUBg005MeVYBAPKroEJ3
LRIFAAAAAElFTkSuQmCC

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/b_import.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAB80lEQVR4AaSSA8weMQBA32G2bdu2
bSMYo9nBrGjxbNu2bdu2ecXaLPfjC6Z3V7evdLTW/A/+ooPvRhhHD6lVZqUUUoGwqbR5jTBpdJBI
oU29Ojm+c56yWIHSunersklS8+cwavmtomHeNzY7mPV35iOUQEhBoEyQQXRq6sK2YRXGEwQyXgyB
xtKxYDf+hM/fjFRIogVSYVl66AV/QtPSKfkRU2APJ6RD5bSsOPyctpXSEbL62HNalY8uv/rwLfYK
AiNQWuN7sProCzzPZc2xFzgumN/C+hMvQGvi+FAgU0J+BBFb0DbjObQom8Z0fknDaUOJM2duuAKa
lU1LyK0nHxBCxV6BVibjwqbTL6kzqisyYQK2m7yleqtKvE2cCC9ZYrzkScmcLCmLTV72W6rdBPGM
wNi01jQpnYb3JcvzNn9mvPgetcb0xDWiT0CigT1wEiTASZQQjMwx9cSPB6s34ttXZ9l5/hXO3E2U
7lzfDIzP7ilrsVQ4UIHPk2aGKzCpCSbvGhF2BUIINL+2UKNIavYt3UaxNnVoXCoNljWrj9KyfBpC
rj98z8QVV5g3sIITfQZaUzhrYp6++UqudAl4t/cgrx9/wD6yQpniYgfFRCmtYtyCPjx66c3iP6RK
ZO/XBikUVmyf7s9hAx8+/9gMY1OcnQEDBxOf4tVcwwAAAABJRU5ErkJggg==

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/b_home.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACpUlEQVR4AYxSM4BtVxR91e3rX3/b
ts2xbTzbiMa2bdu2bXeDd2OvnNzYKc7ZXNssAH/7yn2PUeTtq2Kf2FfFO0X9k98/givYJ7aqeCe/
qBGd/qJeenarXnme+l8BKvyOUwRobA94jNFsL4zl+aE74g0atJeMDfrL1L8GqOKcpGqEp40dQc8w
ns8mj4PxQj4mSqTojDFDjfaKsUp1hfrbAFX8U1St5AzdGfoCEwU8dEe+Rb3uGuoM19EeZYaRQgUa
w0xRKLlM5/AuUn8IUCs6Q9VLz9HdYa8xUSREd5QJGj+8g6nJceZV6u6gIcgUPVkilOtfI9njHB3t
cIZiApABUWRAdHfEW0wUS0ippqh//y4GB/qxs7ODvb09LC7MIVt4A8XqF2iK90a64BECTE7Q+udH
KVaD6mJPd9S7n/s0J+B7GB0Zwu7uLgP+5S3MzyHG5TJS2PdRFmiDSJfrkN452MMik31cr7/yXXu0
OSrUN79fXV78JfNf3sbaCjTPTiDU/iokNw98R95jZgZkso9LlZc7wkKCvv/8888ZZz6fD6FQCJFI
BLFYzOg+/fRTBAV8BNGdo5M/gv+yxoCAgE9omgZxZoBxcXFITEyEXC7/JQAT1NLS8tDf3oHBYPjE
aDQyzjKZDMnJyUhLS4NGo/k1AIfDgYmJyW8BfJsdTzqVWVibpb1oNAt6/W1mWzpIECiVSmRmZiI7
OxskMKPLnU6DU4klzJJfTD0Ju6O+pr7wmkXAm+xKNyhauPCtdIJTmB22trag1WqRl5eHwsJCfPjh
h1hfX4eyUYiQfj3UbXzYZZriFPvopyySuYVEWyfRem6xr9E/zDfT+3VGRsbd9vZ2sEZguPzv6en5
HxQUdDewyO+1Z7PzD+s6s1NAzW9UkhX3g/xBEQYAjX2shzHogH4AAAAASUVORK5CYII=

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/b_help.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACiElEQVR4AaRSw2IcCBjeZ0leY63T
2qxtu7Ft27bHtm17wnH1DQ61e/htfATgg+AFBdOQyKbr43ep2piBrImGiKpwaF0RMqzKdu8uSXay
X5uAoo3+SlJH3EZfAiZvFHpXKANGTwRqZwRT3IB7nO379aUJCMrwr2vyvbDFH4PUvIVRmgPlM1qU
TGnQRTCBow5A5w6hl+wIdxFsvz6TYFm6m7Uo3naZfFGwtUHkp4I6CEY4glHYgxHMcJ24PSrHhtgN
lX0X9YsGV82cLutxgmleIEfpCENk3EbOmArX+6SIxO+n4EEaMnz+mAy3hyRgqPygK/0oHJXnPE4w
SHMbdKlZewgWXO2T4FKPCI5ABEsCJygKD6Lx+ynqwuk2JuqX1JBbt3CjR2h4nKB93RrVu/aQMyLD
xW4hznRwUs4srAjt2ArF4d2Kop+kw4kmOi52sqC27+BMMyv6OEHtnC6qc+7h1rAMp9tZONXKxMkW
Jvai92Dzh3C2mY6jtWQcScHZZipUjm0crKI8SVA0qjAobNtoXtbhTBsHJ5sZON5Iw7E6SgYOVxJw
uGIdhyrWUDIqgNDox5+Fa09GSM2Tsy50gqX242I753FgcDcG/04U+8tXM3C4fBkEsR0jqXG+v73w
ZIlnm9lZpxoYLp7Wjw2RA6ebqDhUtYGmOUkG0sEHSxcwQdWDKnPi26szrq8uTz85Yxr2l5N+/beU
EGaqPKDIXSge4eF4zRqOVqwgr5+FDaEVZKkDn1+YDH9ybvzXl77yzznLv/5wZ9E9SNCAr/dBZg1m
gKv1omtZgeSscpY/s8haFow3M7mUrFV2LFpTa1+w6rZN7orPVtnLP5tnLr1tmrGk1jhtMdbMRBEG
ANevBaKs4AxcAAAAAElFTkSuQmCC

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/b_group.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACcUlEQVR4AZWQQ3gkCQCFa814bdu2
7R3brdi22ojV5tie2LZt235xvlyiw1+uJwIAcS2E+DVe9VTlrbDbnQAQK6HT6S/w+KwakSRiKjgs
qJ/DZUWw2V7PL70nYiT3KSvTbcfGBkuQe3Pb2I0g4umVAgyWL+36zavjdfV1qKmpRnJKInh8zqCv
r6/BvEBk+F3CvrbrU4Mt7og9zZl2POAx7UmhT+/9hKxyOOA56UHxhZAlQ1t7K7q7u9De0QYunzVG
p9P1FgQCCYP0818Njw0kQ2Bpjb6ePtRXNmDfx6SGpWuOZQDaZwWqqsvnE7C5zCvLFeY3ENzp1Voh
nLb8zwpDg4O4cSISlB9Mlq99jDnIzctGXkEuVGohQq0+H5CTtb5aFlAY3x8QI30T7mRPVFVVwm6v
G1yPLVw77PeAO9Vn3jkpOQECfy5yzrpATtWqWhaQ0R5syjxHg9lOK7S2toD0qylMdixcU383hzPV
HRWVpYiJjYTQ3wUtOaegMXt8SELRfpkQ0bRePW713HBZVCh+/PgXBAcH48vXv8VPn/wKuVyOn97/
HXv+3A+pXAx3d0cEOm9F5Q1PRPv9PiqjadkREsqDJqky0lhbpC3abphumMJz9lDQtK8RsyrR1ekn
0N3duSlqUpVzOzQQMqpWp5TyIDaL2uIpSMkPTs6PKKToQRXqDfr+pzaEKtQLErL2ZBhZT2deQETW
xlkpG4yDz26Ic1IWZDT9Sckh4t55ATlNF51lkUhivrshOkquQ2n88EoBnYmmDAU6iq6gvejymnTM
0pylgZymN1uBuGtRQJuvMNIfP2H1zOhGmP12QkjSCgdAzAAB46C0lTpRvAAAAABJRU5ErkJggg==

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/b_export.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAByUlEQVR4AaSTQ7xXURDHf9c327Zt
LcMm2162y7b3LbPrcZ1dm2y7Z+tguvM+f2Z8DwbHGIOI8D8YBy9mryXCQkW6sdYaSgOSpWKdIAMZ
LQpKUuDXtwD03TKjDWxNtGh83yq18ResP/68a1i3ldY8GMkv90NqCakkhA6KElEZ+MJtywdsgRDK
i5mAwEzrOB9/QmGJhJAKYWw+K3P0chr+hFG9a6IsdgK+nDBTB9fFiStfMGlQPYQ5ff0LxveP2hl5
JfE7EEpDE8G2gs7X0mBZJhKup8EwgSCDSb6ZBhDBsYEOjSqiTChE2J38jnKLyijhRhoxSSxjOHXt
c5z97EMuDdnYjyZuvYrAhLEt4Q0dPjcMYTzfg1fBhV/RAxfW2ef6DhzXwZIee7Bw33CEGGELqcGM
mzAOTGWnEqq4VVHFqxqyK6OiUxGWaWH9wbVYeGc4mjdtCtdx8PTFi8M2/zom4VTCb3fQtlvLuB1c
XHO9NlYeekJZ+aV09m46MefusYwSXGyc/fhtTvkdzN4duoMl+x/R8rEtQv+ei2YZiYUfseXYAw3A
OrBkIH8kurLh6LPuZUpX4vfloqSGKJ9I4kfk5JekhnXj6yjNzgDJilEHxeVEjwAAAABJRU5ErkJg
gg==

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/b_engine.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAQAAAC1+jfqAAABVUlEQVR4AWWMM4NeQRhGz0Vs27bK
2LbLr4nxB1KnThtbZWzbts01796ZedY+Z/jKExdqaZaWut7qIeee673b7i7MsZTgne+rgy0GtqYe
dRFpZPCVf9e1ZP4PAODspS9yqkisRzq8WxSJr36tqEo73FRKCB3iD7WpRQ1ENsn8oBuOSgUhKeQi
DOlEhKhigRABtQkLjDEIOIhpUWmCKUp5WN7wh550RWwcF+1IO71phe8QFoPBYvnHCERXetL7wtRO
dvm0ukUT4gItAZbWQBqXqM1QLI12nsz2Ha6kXxylOW14xmpa/HuV3ZbBiZXyLcm0oBYAWSQT0Yyf
xCjO4Ds/Cea/+DbHr9mGFjRkMP+JaMwd5alfQ8vJ7f8memJfF7fBzfcb1cXwmtF8ohe5fKAr2/ke
egIAtjQw3Y17sD4z0WjmsGP/ebwkOpB9/vJkRHUXaZJK3uQDbvXGsK/2+g4AAAAASUVORK5CYII=

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/b_docs.png

iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACiElEQVR4AaRSw2IcCBjeZ0leY63T
2qxtu7Ft27bHtm17wnH1DQ61e/htfATgg+AFBdOQyKbr43ep2piBrImGiKpwaF0RMqzKdu8uSXay
X5uAoo3+SlJH3EZfAiZvFHpXKANGTwRqZwRT3IB7nO379aUJCMrwr2vyvbDFH4PUvIVRmgPlM1qU
TGnQRTCBow5A5w6hl+wIdxFsvz6TYFm6m7Uo3naZfFGwtUHkp4I6CEY4glHYgxHMcJ24PSrHhtgN
lX0X9YsGV82cLutxgmleIEfpCENk3EbOmArX+6SIxO+n4EEaMnz+mAy3hyRgqPygK/0oHJXnPE4w
SHMbdKlZewgWXO2T4FKPCI5ABEsCJygKD6Lx+ynqwuk2JuqX1JBbt3CjR2h4nKB93RrVu/aQMyLD
xW4hznRwUs4srAjt2ArF4d2Kop+kw4kmOi52sqC27+BMMyv6OEHtnC6qc+7h1rAMp9tZONXKxMkW
Jvai92Dzh3C2mY6jtWQcScHZZipUjm0crKI8SVA0qjAobNtoXtbhTBsHJ5sZON5Iw7E6SgYOVxJw
uGIdhyrWUDIqgNDox5+Fa09GSM2Tsy50gqX242I753FgcDcG/04U+8tXM3C4fBkEsR0jqXG+v73w
ZIlnm9lZpxoYLp7Wjw2RA6ebqDhUtYGmOUkG0sEHSxcwQdWDKnPi26szrq8uTz85Yxr2l5N+/beU
EGaqPKDIXSge4eF4zRqOVqwgr5+FDaEVZKkDn1+YDH9ybvzXl77yzznLv/5wZ9E9SNCAr/dBZg1m
gKv1omtZgeSscpY/s8haFow3M7mUrFV2LFpTa1+w6rZN7orPVtnLP5tnLr1tmrGk1jhtMdbMRBEG
ANevBaKs4AxcAAAAAElFTkSuQmCC

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/img/ajax_clock_small.gif

R0lGODlhEAAQAPQAAP///wAAAPDw8IqKiuDg4EZGRnp6egAAAFhYWCQkJKysrL6+vhQUFJycnAQE
BDY2NmhoaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAkK
AAAAIf8LTkVUU0NBUEUyLjADAQAAACwAAAAAEAAQAAAFdyAgAgIJIeWoAkRCCMdBkKtIHIngyMKs
ErPBYbADpkSCwhDmQCBethRB6Vj4kFCkQPG4IlWDgrNRIwnO4UKBXDufzQvDMaoSDBgFb886MiQa
dgNABAokfCwzBA8LCg0Egl8jAggGAA1kBIA1BAYzlyILczULC2UhACH5BAkKAAAALAAAAAAQABAA
AAV2ICACAmlAZTmOREEIyUEQjLKKxPHADhEvqxlgcGgkGI1DYSVAIAWMx+lwSKkICJ0QsHi9RgKB
wnVTiRQQgwF4I4UFDQQEwi6/3YSGWRRmjhEETAJfIgMFCnAKM0KDV4EEEAQLiF18TAYNXDaSe3x6
mjidN1s3IQAh+QQJCgAAACwAAAAAEAAQAAAFeCAgAgLZDGU5jgRECEUiCI+yioSDwDJyLKsXoHFQ
xBSHAoAAFBhqtMJg8DgQBgfrEsJAEAg4YhZIEiwgKtHiMBgtpg3wbUZXGO7kOb1MUKRFMysCChAo
ggJCIg0GC2aNe4gqQldfL4l/Ag1AXySJgn5LcoE3QXI3IQAh+QQJCgAAACwAAAAAEAAQAAAFdiAg
AgLZNGU5joQhCEjxIssqEo8bC9BRjy9Ag7GILQ4QEoE0gBAEBcOpcBA0DoxSK/e8LRIHn+i1cK0I
yKdg0VAoljYIg+GgnRrwVS/8IAkICyosBIQpBAMoKy9dImxPhS+GKkFrkX+TigtLlIyKXUF+Njag
NiEAIfkECQoAAAAsAAAAABAAEAAABWwgIAICaRhlOY4EIgjH8R7LKhKHGwsMvb4AAy3WODBIBBKC
sYA9TjuhDNDKEVSERezQEL0WrhXucRUQGuik7bFlngzqVW9LMl9XWvLdjFaJtDFqZ1cEZUB0dUgv
L3dgP4WJZn4jkomWNpSTIyEAIfkECQoAAAAsAAAAABAAEAAABX4gIAICuSxlOY6CIgiD8RrEKgqG
OwxwUrMlAoSwIzAGpJpgoSDAGifDY5kopBYDlEpAQBwevxfBtRIUGi8xwWkDNBCIwmC9Vq0aiQQD
QuK+VgQPDXV9hCJjBwcFYU5pLwwHXQcMKSmNLQcIAExlbH8JBwttaX0ABAcNbWVbKyEAIfkECQoA
AAAsAAAAABAAEAAABXkgIAICSRBlOY7CIghN8zbEKsKoIjdFzZaEgUBHKChMJtRwcWpAWoWnifm6
ESAMhO8lQK0EEAV3rFopIBCEcGwDKAqPh4HUrY4ICHH1dSoTFgcHUiZjBhAJB2AHDykpKAwHAwdz
f19KkASIPl9cDgcnDkdtNwiMJCshACH5BAkKAAAALAAAAAAQABAAAAV3ICACAkkQZTmOAiosiyAo
xCq+KPxCNVsSMRgBsiClWrLTSWFoIQZHl6pleBh6suxKMIhlvzbAwkBWfFWrBQTxNLq2RG2yhSUk
Ds2b63AYDAoJXAcFRwADeAkJDX0AQCsEfAQMDAIPBz0rCgcxky0JRWE1AmwpKyEAIfkECQoAAAAs
AAAAABAAEAAABXkgIAICKZzkqJ4nQZxLqZKv4NqNLKK2/Q4Ek4lFXChsg5ypJjs1II3gEDUSRInE
GYAw6B6zM4JhrDAtEosVkLUtHA7RHaHAGJQEjsODcEg0FBAFVgkQJQ1pAwcDDw8KcFtSInwJAowC
CA6RIwqZAgkPNgVpWndjdyohACH5BAkKAAAALAAAAAAQABAAAAV5ICACAimc5KieLEuUKvm2xAKL
qDCfC2GaO9eL0LABWTiBYmA06W6kHgvCqEJiAIJiu3gcvgUsscHUERm+kaCxyxa+zRPk0SgJEgfI
vbAdIAQLCAYlCj4DBw0IBQsMCjIqBAcPAooCBg9pKgsJLwUFOhCZKyQDA3YqIQAh+QQJCgAAACwA
AAAAEAAQAAAFdSAgAgIpnOSonmxbqiThCrJKEHFbo8JxDDOZYFFb+A41E4H4OhkOipXwBElYITDA
ckFEOBgMQ3arkMkUBdxIUGZpEb7kaQBRlASPg0FQQHAbEEMGDSVEAA1QBhAED1E0NgwFAooCDWlj
aQIQCE5qMHcNhCkjIQAh+QQJCgAAACwAAAAAEAAQAAAFeSAgAgIpnOSoLgxxvqgKLEcCC65KEABy
KK8cSpA4DAiHQ/DkKhGKh4ZCtCyZGo6F6iYYPAqFgYy02xkSaLEMV34tELyRYNEsCQyHlvWkGCzs
PgMCEAY7Cg04Uk48LAsDhRA8MVQPEF0GAgqYYwSRlycNcWskCkApIyEAOw==

------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: text/css
Content-Transfer-Encoding: quoted-printable
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/css/theme.css?v=5.2.1

@charset "utf-8";

:root { --bs-blue: #0d6efd; --bs-indigo: #6610f2; --bs-purple: #6f42c1; --b=
s-pink: #d63384; --bs-red: #dc3545; --bs-orange: #fd7e14; --bs-yellow: #ffc=
107; --bs-green: #198754; --bs-teal: #20c997; --bs-cyan: #0dcaf0; --bs-blac=
k: #000; --bs-white: #fff; --bs-gray: #6c757d; --bs-gray-dark: #343a40; --b=
s-gray-100: #f8f9fa; --bs-gray-200: #e9ecef; --bs-gray-300: #dee2e6; --bs-g=
ray-400: #ced4da; --bs-gray-500: #adb5bd; --bs-gray-600: #6c757d; --bs-gray=
-700: #495057; --bs-gray-800: #343a40; --bs-gray-900: #212529; --bs-primary=
: #ddd; --bs-secondary: #ddd; --bs-success: #198754; --bs-info: #0dcaf0; --=
bs-warning: #ffc107; --bs-danger: #dc3545; --bs-light: #f8f9fa; --bs-dark: =
#212529; --bs-primary-rgb: 221, 221, 221; --bs-secondary-rgb: 221, 221, 221=
; --bs-success-rgb: 25, 135, 84; --bs-info-rgb: 13, 202, 240; --bs-warning-=
rgb: 255, 193, 7; --bs-danger-rgb: 220, 53, 69; --bs-light-rgb: 248, 249, 2=
50; --bs-dark-rgb: 33, 37, 41; --bs-white-rgb: 255, 255, 255; --bs-black-rg=
b: 0, 0, 0; --bs-body-color-rgb: 68, 68, 68; --bs-body-bg-rgb: 255, 255, 25=
5; --bs-font-sans-serif: system-ui, -apple-system, "Segoe UI", Roboto, "Hel=
vetica Neue", "Noto Sans", "Liberation Sans", Arial, sans-serif, "Apple Col=
or Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; --bs-fo=
nt-monospace: monospace; --bs-gradient: linear-gradient(180deg, rgba(255, 2=
55, 255, 0.15), rgba(255, 255, 255, 0)); --bs-body-font-family: sans-serif;=
 --bs-body-font-size: 0.82rem; --bs-body-font-weight: 400; --bs-body-line-h=
eight: 1.5; --bs-body-color: #444; --bs-body-bg: #fff; --bs-border-width: 1=
px; --bs-border-style: solid; --bs-border-color: #dee2e6; --bs-border-color=
-translucent: rgba(0, 0, 0, 0.175); --bs-border-radius: 0.25rem; --bs-borde=
r-radius-sm: 0.25rem; --bs-border-radius-lg: 0.5rem; --bs-border-radius-xl:=
 1rem; --bs-border-radius-2xl: 2rem; --bs-border-radius-pill: 50rem; --bs-l=
ink-color: #235a81; --bs-link-hover-color: #235a81; --bs-code-color: #d6338=
4; --bs-highlight-bg: #fff3cd; }

*, ::before, ::after { box-sizing: border-box; }

@media (prefers-reduced-motion: no-preference) {
  :root { scroll-behavior: smooth; }
}

body { margin: 0px; font-family: var(--bs-body-font-family); font-size: var=
(--bs-body-font-size); font-weight: var(--bs-body-font-weight); line-height=
: var(--bs-body-line-height); color: var(--bs-body-color); text-align: var(=
--bs-body-text-align); background-color: var(--bs-body-bg); text-size-adjus=
t: 100%; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); }

hr { margin: 1rem 0px; color: inherit; border-width: 1px 0px 0px; border-ri=
ght-style: initial; border-bottom-style: initial; border-left-style: initia=
l; border-color: initial; border-image: initial; border-top-style: solid; o=
pacity: 0.25; }

h6, .h6, h5, .h5, h4, .h4, h3, .h3, h2, .h2, h1, .h1 { margin-top: 0px; mar=
gin-bottom: 0.5rem; font-weight: 500; line-height: 1.2; }

h1, .h1 { font-size: 140%; }

h2, .h2 { font-size: 2em; }

h3, .h3 { font-size: 1rem; }

h4, .h4 { font-size: 1.23rem; }

h5, .h5 { font-size: 1.025rem; }

h6, .h6 { font-size: 0.82rem; }

p { margin-top: 0px; margin-bottom: 1rem; }

abbr[title] { text-decoration: underline dotted; cursor: help; text-decorat=
ion-skip-ink: none; }

address { margin-bottom: 1rem; font-style: normal; line-height: inherit; }

ol, ul { padding-left: 2rem; }

ol, ul, dl { margin-top: 0px; margin-bottom: 1rem; }

ol ol, ul ul, ol ul, ul ol { margin-bottom: 0px; }

dt { font-weight: 700; }

dd { margin-bottom: 0.5rem; margin-left: 0px; }

blockquote { margin: 0px 0px 1rem; }

b, strong { font-weight: bolder; }

small, .small { font-size: 0.875em; }

mark, .mark { padding: 0.1875em; background-color: var(--bs-highlight-bg); =
}

sub, sup { position: relative; font-size: 0.75em; line-height: 0; vertical-=
align: baseline; }

sub { bottom: -0.25em; }

sup { top: -0.5em; }

a { color: var(--bs-link-color); text-decoration: none; }

a:hover { color: var(--bs-link-hover-color); text-decoration: underline; }

a:not([href]):not([class]), a:not([href]):not([class]):hover { color: inher=
it; text-decoration: none; }

pre, code, kbd, samp { font-family: var(--bs-font-monospace); font-size: 1e=
m; }

pre { display: block; margin-top: 0px; margin-bottom: 1rem; overflow: auto;=
 font-size: 0.875em; }

pre code { font-size: inherit; color: inherit; word-break: normal; }

code { font-size: 0.875em; color: var(--bs-code-color); overflow-wrap: brea=
k-word; }

a > code { color: inherit; }

kbd { padding: 0.1875rem 0.375rem; font-size: 0.875em; color: var(--bs-body=
-bg); background-color: var(--bs-body-color); border-radius: 0.25rem; }

kbd kbd { padding: 0px; font-size: 1em; }

figure { margin: 0px 0px 1rem; }

img, svg { vertical-align: middle; }

table { caption-side: bottom; border-collapse: collapse; }

caption { padding-top: 0.1em; padding-bottom: 0.1em; color: rgb(0, 0, 0); t=
ext-align: left; }

th { text-align: -webkit-match-parent; }

thead, tbody, tfoot, tr, td, th { border-color: inherit; border-style: soli=
d; border-width: 0px; }

label { display: inline-block; }

button { border-radius: 0px; }

button:focus:not(:focus-visible) { outline: 0px; }

input, button, select, optgroup, textarea { margin: 0px; font-family: inher=
it; font-size: inherit; line-height: inherit; }

button, select { text-transform: none; }

[role=3D"button"] { cursor: pointer; }

select { overflow-wrap: normal; }

select:disabled { opacity: 1; }

[list]:not([type=3D"date"]):not([type=3D"datetime-local"]):not([type=3D"mon=
th"]):not([type=3D"week"]):not([type=3D"time"])::-webkit-calendar-picker-in=
dicator { display: none !important; }

button, [type=3D"button"], [type=3D"reset"], [type=3D"submit"] { appearance=
: button; }

button:not(:disabled), [type=3D"button"]:not(:disabled), [type=3D"reset"]:n=
ot(:disabled), [type=3D"submit"]:not(:disabled) { cursor: pointer; }

textarea { resize: vertical; }

fieldset { min-width: 0px; padding: 0px; margin: 0px; border: 0px; }

legend { float: left; width: 100%; padding: 0px; margin-bottom: 0.5rem; fon=
t-size: calc(1.275rem + 0.3vw); line-height: inherit; }

@media (min-width: 1200px) {
  legend { font-size: 1.5rem; }
}

legend + * { clear: left; }

::-webkit-datetime-edit-fields-wrapper, ::-webkit-datetime-edit-text, ::-we=
bkit-datetime-edit-minute, ::-webkit-datetime-edit-hour-field, ::-webkit-da=
tetime-edit-day-field, ::-webkit-datetime-edit-month-field, ::-webkit-datet=
ime-edit-year-field { padding: 0px; }

::-webkit-inner-spin-button { height: auto; }

[type=3D"search"] { outline-offset: -2px; appearance: textfield; }

::-webkit-search-decoration { appearance: none; }

::-webkit-color-swatch-wrapper { padding: 0px; }

::-webkit-file-upload-button { font: inherit; appearance: button; }

::file-selector-button { font: inherit; appearance: button; }

output { display: inline-block; }

iframe { border: 0px; }

summary { display: list-item; cursor: pointer; }

progress { vertical-align: baseline; }

[hidden] { display: none !important; }

.lead { font-size: 1.025rem; font-weight: 300; }

.display-1 { font-size: calc(1.625rem + 4.5vw); font-weight: 300; line-heig=
ht: 1.2; }

@media (min-width: 1200px) {
  .display-1 { font-size: 5rem; }
}

.display-2 { font-size: calc(1.575rem + 3.9vw); font-weight: 300; line-heig=
ht: 1.2; }

@media (min-width: 1200px) {
  .display-2 { font-size: 4.5rem; }
}

.display-3 { font-size: calc(1.525rem + 3.3vw); font-weight: 300; line-heig=
ht: 1.2; }

@media (min-width: 1200px) {
  .display-3 { font-size: 4rem; }
}

.display-4 { font-size: calc(1.475rem + 2.7vw); font-weight: 300; line-heig=
ht: 1.2; }

@media (min-width: 1200px) {
  .display-4 { font-size: 3.5rem; }
}

.display-5 { font-size: calc(1.425rem + 2.1vw); font-weight: 300; line-heig=
ht: 1.2; }

@media (min-width: 1200px) {
  .display-5 { font-size: 3rem; }
}

.display-6 { font-size: calc(1.375rem + 1.5vw); font-weight: 300; line-heig=
ht: 1.2; }

@media (min-width: 1200px) {
  .display-6 { font-size: 2.5rem; }
}

.list-unstyled { padding-left: 0px; list-style: none; }

.list-inline { padding-left: 0px; list-style: none; }

.list-inline-item { display: inline-block; }

.list-inline-item:not(:last-child) { margin-right: 0.5rem; }

.initialism { font-size: 0.875em; text-transform: uppercase; }

.blockquote { margin-bottom: 1rem; font-size: 1.025rem; }

.blockquote > :last-child { margin-bottom: 0px; }

.blockquote-footer { margin-top: -1rem; margin-bottom: 1rem; font-size: 0.8=
75em; color: rgb(108, 117, 125); }

.blockquote-footer::before { content: "=E2=80=94=C2=A0"; }

.container, .container-fluid, .container-xxl, .container-xl, .container-lg,=
 .container-md, .container-sm { --bs-gutter-x: 1.5rem; --bs-gutter-y: 0; wi=
dth: 100%; padding-right: calc(var(--bs-gutter-x)*.5); padding-left: calc(v=
ar(--bs-gutter-x)*.5); margin-right: auto; margin-left: auto; }

@media (min-width: 576px) {
  .container-sm, .container { max-width: 540px; }
}

@media (min-width: 768px) {
  .container-md, .container-sm, .container { max-width: 720px; }
}

@media (min-width: 992px) {
  .container-lg, .container-md, .container-sm, .container { max-width: 960p=
x; }
}

@media (min-width: 1200px) {
  .container-xl, .container-lg, .container-md, .container-sm, .container { =
max-width: 1140px; }
}

@media (min-width: 1400px) {
  .container-xxl, .container-xl, .container-lg, .container-md, .container-s=
m, .container { max-width: 1320px; }
}

.row { --bs-gutter-x: 1.5rem; --bs-gutter-y: 0; display: flex; flex-wrap: w=
rap; margin-top: calc(-1*var(--bs-gutter-y)); margin-right: calc(-0.5*var(-=
-bs-gutter-x)); margin-left: calc(-0.5*var(--bs-gutter-x)); }

.row > * { flex-shrink: 0; width: 100%; max-width: 100%; padding-right: cal=
c(var(--bs-gutter-x)*.5); padding-left: calc(var(--bs-gutter-x)*.5); margin=
-top: var(--bs-gutter-y); }

.col { flex: 1 0 0%; }

.row-cols-auto > * { flex: 0 0 auto; width: auto; }

.row-cols-1 > * { flex: 0 0 auto; width: 100%; }

.row-cols-2 > * { flex: 0 0 auto; width: 50%; }

.row-cols-3 > * { flex: 0 0 auto; width: 33.3333%; }

.row-cols-4 > * { flex: 0 0 auto; width: 25%; }

.row-cols-5 > * { flex: 0 0 auto; width: 20%; }

.row-cols-6 > * { flex: 0 0 auto; width: 16.6667%; }

.col-auto { flex: 0 0 auto; width: auto; }

.col-1 { flex: 0 0 auto; width: 8.33333%; }

.col-2 { flex: 0 0 auto; width: 16.6667%; }

.col-3 { flex: 0 0 auto; width: 25%; }

.col-4 { flex: 0 0 auto; width: 33.3333%; }

.col-5 { flex: 0 0 auto; width: 41.6667%; }

.col-6 { flex: 0 0 auto; width: 50%; }

.col-7 { flex: 0 0 auto; width: 58.3333%; }

.col-8 { flex: 0 0 auto; width: 66.6667%; }

.col-9 { flex: 0 0 auto; width: 75%; }

.col-10 { flex: 0 0 auto; width: 83.3333%; }

.col-11 { flex: 0 0 auto; width: 91.6667%; }

.col-12 { flex: 0 0 auto; width: 100%; }

.offset-1 { margin-left: 8.33333%; }

.offset-2 { margin-left: 16.6667%; }

.offset-3 { margin-left: 25%; }

.offset-4 { margin-left: 33.3333%; }

.offset-5 { margin-left: 41.6667%; }

.offset-6 { margin-left: 50%; }

.offset-7 { margin-left: 58.3333%; }

.offset-8 { margin-left: 66.6667%; }

.offset-9 { margin-left: 75%; }

.offset-10 { margin-left: 83.3333%; }

.offset-11 { margin-left: 91.6667%; }

.g-0, .gx-0 { --bs-gutter-x: 0; }

.g-0, .gy-0 { --bs-gutter-y: 0; }

.g-1, .gx-1 { --bs-gutter-x: 0.25rem; }

.g-1, .gy-1 { --bs-gutter-y: 0.25rem; }

.g-2, .gx-2 { --bs-gutter-x: 0.5rem; }

.g-2, .gy-2 { --bs-gutter-y: 0.5rem; }

.g-3, .gx-3 { --bs-gutter-x: 1rem; }

.g-3, .gy-3 { --bs-gutter-y: 1rem; }

.g-4, .gx-4 { --bs-gutter-x: 1.5rem; }

.g-4, .gy-4 { --bs-gutter-y: 1.5rem; }

.g-5, .gx-5 { --bs-gutter-x: 3rem; }

.g-5, .gy-5 { --bs-gutter-y: 3rem; }

@media (min-width: 576px) {
  .col-sm { flex: 1 0 0%; }
  .row-cols-sm-auto > * { flex: 0 0 auto; width: auto; }
  .row-cols-sm-1 > * { flex: 0 0 auto; width: 100%; }
  .row-cols-sm-2 > * { flex: 0 0 auto; width: 50%; }
  .row-cols-sm-3 > * { flex: 0 0 auto; width: 33.3333%; }
  .row-cols-sm-4 > * { flex: 0 0 auto; width: 25%; }
  .row-cols-sm-5 > * { flex: 0 0 auto; width: 20%; }
  .row-cols-sm-6 > * { flex: 0 0 auto; width: 16.6667%; }
  .col-sm-auto { flex: 0 0 auto; width: auto; }
  .col-sm-1 { flex: 0 0 auto; width: 8.33333%; }
  .col-sm-2 { flex: 0 0 auto; width: 16.6667%; }
  .col-sm-3 { flex: 0 0 auto; width: 25%; }
  .col-sm-4 { flex: 0 0 auto; width: 33.3333%; }
  .col-sm-5 { flex: 0 0 auto; width: 41.6667%; }
  .col-sm-6 { flex: 0 0 auto; width: 50%; }
  .col-sm-7 { flex: 0 0 auto; width: 58.3333%; }
  .col-sm-8 { flex: 0 0 auto; width: 66.6667%; }
  .col-sm-9 { flex: 0 0 auto; width: 75%; }
  .col-sm-10 { flex: 0 0 auto; width: 83.3333%; }
  .col-sm-11 { flex: 0 0 auto; width: 91.6667%; }
  .col-sm-12 { flex: 0 0 auto; width: 100%; }
  .offset-sm-0 { margin-left: 0px; }
  .offset-sm-1 { margin-left: 8.33333%; }
  .offset-sm-2 { margin-left: 16.6667%; }
  .offset-sm-3 { margin-left: 25%; }
  .offset-sm-4 { margin-left: 33.3333%; }
  .offset-sm-5 { margin-left: 41.6667%; }
  .offset-sm-6 { margin-left: 50%; }
  .offset-sm-7 { margin-left: 58.3333%; }
  .offset-sm-8 { margin-left: 66.6667%; }
  .offset-sm-9 { margin-left: 75%; }
  .offset-sm-10 { margin-left: 83.3333%; }
  .offset-sm-11 { margin-left: 91.6667%; }
  .g-sm-0, .gx-sm-0 { --bs-gutter-x: 0; }
  .g-sm-0, .gy-sm-0 { --bs-gutter-y: 0; }
  .g-sm-1, .gx-sm-1 { --bs-gutter-x: 0.25rem; }
  .g-sm-1, .gy-sm-1 { --bs-gutter-y: 0.25rem; }
  .g-sm-2, .gx-sm-2 { --bs-gutter-x: 0.5rem; }
  .g-sm-2, .gy-sm-2 { --bs-gutter-y: 0.5rem; }
  .g-sm-3, .gx-sm-3 { --bs-gutter-x: 1rem; }
  .g-sm-3, .gy-sm-3 { --bs-gutter-y: 1rem; }
  .g-sm-4, .gx-sm-4 { --bs-gutter-x: 1.5rem; }
  .g-sm-4, .gy-sm-4 { --bs-gutter-y: 1.5rem; }
  .g-sm-5, .gx-sm-5 { --bs-gutter-x: 3rem; }
  .g-sm-5, .gy-sm-5 { --bs-gutter-y: 3rem; }
}

@media (min-width: 768px) {
  .col-md { flex: 1 0 0%; }
  .row-cols-md-auto > * { flex: 0 0 auto; width: auto; }
  .row-cols-md-1 > * { flex: 0 0 auto; width: 100%; }
  .row-cols-md-2 > * { flex: 0 0 auto; width: 50%; }
  .row-cols-md-3 > * { flex: 0 0 auto; width: 33.3333%; }
  .row-cols-md-4 > * { flex: 0 0 auto; width: 25%; }
  .row-cols-md-5 > * { flex: 0 0 auto; width: 20%; }
  .row-cols-md-6 > * { flex: 0 0 auto; width: 16.6667%; }
  .col-md-auto { flex: 0 0 auto; width: auto; }
  .col-md-1 { flex: 0 0 auto; width: 8.33333%; }
  .col-md-2 { flex: 0 0 auto; width: 16.6667%; }
  .col-md-3 { flex: 0 0 auto; width: 25%; }
  .col-md-4 { flex: 0 0 auto; width: 33.3333%; }
  .col-md-5 { flex: 0 0 auto; width: 41.6667%; }
  .col-md-6 { flex: 0 0 auto; width: 50%; }
  .col-md-7 { flex: 0 0 auto; width: 58.3333%; }
  .col-md-8 { flex: 0 0 auto; width: 66.6667%; }
  .col-md-9 { flex: 0 0 auto; width: 75%; }
  .col-md-10 { flex: 0 0 auto; width: 83.3333%; }
  .col-md-11 { flex: 0 0 auto; width: 91.6667%; }
  .col-md-12 { flex: 0 0 auto; width: 100%; }
  .offset-md-0 { margin-left: 0px; }
  .offset-md-1 { margin-left: 8.33333%; }
  .offset-md-2 { margin-left: 16.6667%; }
  .offset-md-3 { margin-left: 25%; }
  .offset-md-4 { margin-left: 33.3333%; }
  .offset-md-5 { margin-left: 41.6667%; }
  .offset-md-6 { margin-left: 50%; }
  .offset-md-7 { margin-left: 58.3333%; }
  .offset-md-8 { margin-left: 66.6667%; }
  .offset-md-9 { margin-left: 75%; }
  .offset-md-10 { margin-left: 83.3333%; }
  .offset-md-11 { margin-left: 91.6667%; }
  .g-md-0, .gx-md-0 { --bs-gutter-x: 0; }
  .g-md-0, .gy-md-0 { --bs-gutter-y: 0; }
  .g-md-1, .gx-md-1 { --bs-gutter-x: 0.25rem; }
  .g-md-1, .gy-md-1 { --bs-gutter-y: 0.25rem; }
  .g-md-2, .gx-md-2 { --bs-gutter-x: 0.5rem; }
  .g-md-2, .gy-md-2 { --bs-gutter-y: 0.5rem; }
  .g-md-3, .gx-md-3 { --bs-gutter-x: 1rem; }
  .g-md-3, .gy-md-3 { --bs-gutter-y: 1rem; }
  .g-md-4, .gx-md-4 { --bs-gutter-x: 1.5rem; }
  .g-md-4, .gy-md-4 { --bs-gutter-y: 1.5rem; }
  .g-md-5, .gx-md-5 { --bs-gutter-x: 3rem; }
  .g-md-5, .gy-md-5 { --bs-gutter-y: 3rem; }
}

@media (min-width: 992px) {
  .col-lg { flex: 1 0 0%; }
  .row-cols-lg-auto > * { flex: 0 0 auto; width: auto; }
  .row-cols-lg-1 > * { flex: 0 0 auto; width: 100%; }
  .row-cols-lg-2 > * { flex: 0 0 auto; width: 50%; }
  .row-cols-lg-3 > * { flex: 0 0 auto; width: 33.3333%; }
  .row-cols-lg-4 > * { flex: 0 0 auto; width: 25%; }
  .row-cols-lg-5 > * { flex: 0 0 auto; width: 20%; }
  .row-cols-lg-6 > * { flex: 0 0 auto; width: 16.6667%; }
  .col-lg-auto { flex: 0 0 auto; width: auto; }
  .col-lg-1 { flex: 0 0 auto; width: 8.33333%; }
  .col-lg-2 { flex: 0 0 auto; width: 16.6667%; }
  .col-lg-3 { flex: 0 0 auto; width: 25%; }
  .col-lg-4 { flex: 0 0 auto; width: 33.3333%; }
  .col-lg-5 { flex: 0 0 auto; width: 41.6667%; }
  .col-lg-6 { flex: 0 0 auto; width: 50%; }
  .col-lg-7 { flex: 0 0 auto; width: 58.3333%; }
  .col-lg-8 { flex: 0 0 auto; width: 66.6667%; }
  .col-lg-9 { flex: 0 0 auto; width: 75%; }
  .col-lg-10 { flex: 0 0 auto; width: 83.3333%; }
  .col-lg-11 { flex: 0 0 auto; width: 91.6667%; }
  .col-lg-12 { flex: 0 0 auto; width: 100%; }
  .offset-lg-0 { margin-left: 0px; }
  .offset-lg-1 { margin-left: 8.33333%; }
  .offset-lg-2 { margin-left: 16.6667%; }
  .offset-lg-3 { margin-left: 25%; }
  .offset-lg-4 { margin-left: 33.3333%; }
  .offset-lg-5 { margin-left: 41.6667%; }
  .offset-lg-6 { margin-left: 50%; }
  .offset-lg-7 { margin-left: 58.3333%; }
  .offset-lg-8 { margin-left: 66.6667%; }
  .offset-lg-9 { margin-left: 75%; }
  .offset-lg-10 { margin-left: 83.3333%; }
  .offset-lg-11 { margin-left: 91.6667%; }
  .g-lg-0, .gx-lg-0 { --bs-gutter-x: 0; }
  .g-lg-0, .gy-lg-0 { --bs-gutter-y: 0; }
  .g-lg-1, .gx-lg-1 { --bs-gutter-x: 0.25rem; }
  .g-lg-1, .gy-lg-1 { --bs-gutter-y: 0.25rem; }
  .g-lg-2, .gx-lg-2 { --bs-gutter-x: 0.5rem; }
  .g-lg-2, .gy-lg-2 { --bs-gutter-y: 0.5rem; }
  .g-lg-3, .gx-lg-3 { --bs-gutter-x: 1rem; }
  .g-lg-3, .gy-lg-3 { --bs-gutter-y: 1rem; }
  .g-lg-4, .gx-lg-4 { --bs-gutter-x: 1.5rem; }
  .g-lg-4, .gy-lg-4 { --bs-gutter-y: 1.5rem; }
  .g-lg-5, .gx-lg-5 { --bs-gutter-x: 3rem; }
  .g-lg-5, .gy-lg-5 { --bs-gutter-y: 3rem; }
}

@media (min-width: 1200px) {
  .col-xl { flex: 1 0 0%; }
  .row-cols-xl-auto > * { flex: 0 0 auto; width: auto; }
  .row-cols-xl-1 > * { flex: 0 0 auto; width: 100%; }
  .row-cols-xl-2 > * { flex: 0 0 auto; width: 50%; }
  .row-cols-xl-3 > * { flex: 0 0 auto; width: 33.3333%; }
  .row-cols-xl-4 > * { flex: 0 0 auto; width: 25%; }
  .row-cols-xl-5 > * { flex: 0 0 auto; width: 20%; }
  .row-cols-xl-6 > * { flex: 0 0 auto; width: 16.6667%; }
  .col-xl-auto { flex: 0 0 auto; width: auto; }
  .col-xl-1 { flex: 0 0 auto; width: 8.33333%; }
  .col-xl-2 { flex: 0 0 auto; width: 16.6667%; }
  .col-xl-3 { flex: 0 0 auto; width: 25%; }
  .col-xl-4 { flex: 0 0 auto; width: 33.3333%; }
  .col-xl-5 { flex: 0 0 auto; width: 41.6667%; }
  .col-xl-6 { flex: 0 0 auto; width: 50%; }
  .col-xl-7 { flex: 0 0 auto; width: 58.3333%; }
  .col-xl-8 { flex: 0 0 auto; width: 66.6667%; }
  .col-xl-9 { flex: 0 0 auto; width: 75%; }
  .col-xl-10 { flex: 0 0 auto; width: 83.3333%; }
  .col-xl-11 { flex: 0 0 auto; width: 91.6667%; }
  .col-xl-12 { flex: 0 0 auto; width: 100%; }
  .offset-xl-0 { margin-left: 0px; }
  .offset-xl-1 { margin-left: 8.33333%; }
  .offset-xl-2 { margin-left: 16.6667%; }
  .offset-xl-3 { margin-left: 25%; }
  .offset-xl-4 { margin-left: 33.3333%; }
  .offset-xl-5 { margin-left: 41.6667%; }
  .offset-xl-6 { margin-left: 50%; }
  .offset-xl-7 { margin-left: 58.3333%; }
  .offset-xl-8 { margin-left: 66.6667%; }
  .offset-xl-9 { margin-left: 75%; }
  .offset-xl-10 { margin-left: 83.3333%; }
  .offset-xl-11 { margin-left: 91.6667%; }
  .g-xl-0, .gx-xl-0 { --bs-gutter-x: 0; }
  .g-xl-0, .gy-xl-0 { --bs-gutter-y: 0; }
  .g-xl-1, .gx-xl-1 { --bs-gutter-x: 0.25rem; }
  .g-xl-1, .gy-xl-1 { --bs-gutter-y: 0.25rem; }
  .g-xl-2, .gx-xl-2 { --bs-gutter-x: 0.5rem; }
  .g-xl-2, .gy-xl-2 { --bs-gutter-y: 0.5rem; }
  .g-xl-3, .gx-xl-3 { --bs-gutter-x: 1rem; }
  .g-xl-3, .gy-xl-3 { --bs-gutter-y: 1rem; }
  .g-xl-4, .gx-xl-4 { --bs-gutter-x: 1.5rem; }
  .g-xl-4, .gy-xl-4 { --bs-gutter-y: 1.5rem; }
  .g-xl-5, .gx-xl-5 { --bs-gutter-x: 3rem; }
  .g-xl-5, .gy-xl-5 { --bs-gutter-y: 3rem; }
}

@media (min-width: 1400px) {
  .col-xxl { flex: 1 0 0%; }
  .row-cols-xxl-auto > * { flex: 0 0 auto; width: auto; }
  .row-cols-xxl-1 > * { flex: 0 0 auto; width: 100%; }
  .row-cols-xxl-2 > * { flex: 0 0 auto; width: 50%; }
  .row-cols-xxl-3 > * { flex: 0 0 auto; width: 33.3333%; }
  .row-cols-xxl-4 > * { flex: 0 0 auto; width: 25%; }
  .row-cols-xxl-5 > * { flex: 0 0 auto; width: 20%; }
  .row-cols-xxl-6 > * { flex: 0 0 auto; width: 16.6667%; }
  .col-xxl-auto { flex: 0 0 auto; width: auto; }
  .col-xxl-1 { flex: 0 0 auto; width: 8.33333%; }
  .col-xxl-2 { flex: 0 0 auto; width: 16.6667%; }
  .col-xxl-3 { flex: 0 0 auto; width: 25%; }
  .col-xxl-4 { flex: 0 0 auto; width: 33.3333%; }
  .col-xxl-5 { flex: 0 0 auto; width: 41.6667%; }
  .col-xxl-6 { flex: 0 0 auto; width: 50%; }
  .col-xxl-7 { flex: 0 0 auto; width: 58.3333%; }
  .col-xxl-8 { flex: 0 0 auto; width: 66.6667%; }
  .col-xxl-9 { flex: 0 0 auto; width: 75%; }
  .col-xxl-10 { flex: 0 0 auto; width: 83.3333%; }
  .col-xxl-11 { flex: 0 0 auto; width: 91.6667%; }
  .col-xxl-12 { flex: 0 0 auto; width: 100%; }
  .offset-xxl-0 { margin-left: 0px; }
  .offset-xxl-1 { margin-left: 8.33333%; }
  .offset-xxl-2 { margin-left: 16.6667%; }
  .offset-xxl-3 { margin-left: 25%; }
  .offset-xxl-4 { margin-left: 33.3333%; }
  .offset-xxl-5 { margin-left: 41.6667%; }
  .offset-xxl-6 { margin-left: 50%; }
  .offset-xxl-7 { margin-left: 58.3333%; }
  .offset-xxl-8 { margin-left: 66.6667%; }
  .offset-xxl-9 { margin-left: 75%; }
  .offset-xxl-10 { margin-left: 83.3333%; }
  .offset-xxl-11 { margin-left: 91.6667%; }
  .g-xxl-0, .gx-xxl-0 { --bs-gutter-x: 0; }
  .g-xxl-0, .gy-xxl-0 { --bs-gutter-y: 0; }
  .g-xxl-1, .gx-xxl-1 { --bs-gutter-x: 0.25rem; }
  .g-xxl-1, .gy-xxl-1 { --bs-gutter-y: 0.25rem; }
  .g-xxl-2, .gx-xxl-2 { --bs-gutter-x: 0.5rem; }
  .g-xxl-2, .gy-xxl-2 { --bs-gutter-y: 0.5rem; }
  .g-xxl-3, .gx-xxl-3 { --bs-gutter-x: 1rem; }
  .g-xxl-3, .gy-xxl-3 { --bs-gutter-y: 1rem; }
  .g-xxl-4, .gx-xxl-4 { --bs-gutter-x: 1.5rem; }
  .g-xxl-4, .gy-xxl-4 { --bs-gutter-y: 1.5rem; }
  .g-xxl-5, .gx-xxl-5 { --bs-gutter-x: 3rem; }
  .g-xxl-5, .gy-xxl-5 { --bs-gutter-y: 3rem; }
}

.table { --bs-table-color: var(--bs-body-color); --bs-table-bg: #fff; --bs-=
table-border-color: #fff; --bs-table-accent-bg: transparent; --bs-table-str=
iped-color: var(--bs-body-color); --bs-table-striped-bg: #dfdfdf; --bs-tabl=
e-active-color: var(--bs-body-color); --bs-table-active-bg: rgba(0, 0, 0, 0=
.1); --bs-table-hover-color: #000; --bs-table-hover-bg: rgba(0, 0, 0, 0.075=
); width: 100%; margin-bottom: 1rem; color: var(--bs-table-color); vertical=
-align: top; border-color: var(--bs-table-border-color); }

.table > :not(caption) > * > * { padding: 0.1em 0.3em; background-color: va=
r(--bs-table-bg); border-bottom-width: 0px; box-shadow: inset 0 0 0 9999px =
var(--bs-table-accent-bg); }

.table > tbody { vertical-align: inherit; }

.table > thead { vertical-align: bottom; }

.table-group-divider { border-top: 0px solid currentcolor; }

.caption-top { caption-side: top; }

.table-sm > :not(caption) > * > * { padding: 0.1em 0.3em; }

.table-bordered > :not(caption) > * { border-width: 0px; }

.table-bordered > :not(caption) > * > * { border-width: 0px; }

.table-borderless > :not(caption) > * > * { border-bottom-width: 0px; }

.table-borderless > :not(:first-child) { border-top-width: 0px; }

.table-striped > tbody > tr:nth-of-type(2n) > * { --bs-table-accent-bg: var=
(--bs-table-striped-bg); color: var(--bs-table-striped-color); }

.table-striped-columns > :not(caption) > tr > :nth-child(2n) { --bs-table-a=
ccent-bg: var(--bs-table-striped-bg); color: var(--bs-table-striped-color);=
 }

.table-active { --bs-table-accent-bg: var(--bs-table-active-bg); color: var=
(--bs-table-active-color); }

.table-hover > tbody > tr:hover > * { --bs-table-accent-bg: var(--bs-table-=
hover-bg); color: var(--bs-table-hover-color); }

.table-primary { --bs-table-color: #000; --bs-table-bg: #f8f8f8; --bs-table=
-border-color: #dfdfdf; --bs-table-striped-bg: #ececec; --bs-table-striped-=
color: #000; --bs-table-active-bg: #dfdfdf; --bs-table-active-color: #000; =
--bs-table-hover-bg: #e5e5e5; --bs-table-hover-color: #000; color: var(--bs=
-table-color); border-color: var(--bs-table-border-color); }

.table-secondary { --bs-table-color: #000; --bs-table-bg: #f8f8f8; --bs-tab=
le-border-color: #dfdfdf; --bs-table-striped-bg: #ececec; --bs-table-stripe=
d-color: #000; --bs-table-active-bg: #dfdfdf; --bs-table-active-color: #000=
; --bs-table-hover-bg: #e5e5e5; --bs-table-hover-color: #000; color: var(--=
bs-table-color); border-color: var(--bs-table-border-color); }

.table-success { --bs-table-color: #000; --bs-table-bg: #d1e7dd; --bs-table=
-border-color: #bcd0c7; --bs-table-striped-bg: #c7dbd2; --bs-table-striped-=
color: #000; --bs-table-active-bg: #bcd0c7; --bs-table-active-color: #000; =
--bs-table-hover-bg: #c1d6cc; --bs-table-hover-color: #000; color: var(--bs=
-table-color); border-color: var(--bs-table-border-color); }

.table-info { --bs-table-color: #000; --bs-table-bg: #cff4fc; --bs-table-bo=
rder-color: #badce3; --bs-table-striped-bg: #c5e8ef; --bs-table-striped-col=
or: #000; --bs-table-active-bg: #badce3; --bs-table-active-color: #000; --b=
s-table-hover-bg: #bfe2e9; --bs-table-hover-color: #000; color: var(--bs-ta=
ble-color); border-color: var(--bs-table-border-color); }

.table-warning { --bs-table-color: #000; --bs-table-bg: #fff3cd; --bs-table=
-border-color: #e6dbb9; --bs-table-striped-bg: #f2e7c3; --bs-table-striped-=
color: #000; --bs-table-active-bg: #e6dbb9; --bs-table-active-color: #000; =
--bs-table-hover-bg: #ece1be; --bs-table-hover-color: #000; color: var(--bs=
-table-color); border-color: var(--bs-table-border-color); }

.table-danger { --bs-table-color: #000; --bs-table-bg: #f8d7da; --bs-table-=
border-color: #dfc2c4; --bs-table-striped-bg: #eccccf; --bs-table-striped-c=
olor: #000; --bs-table-active-bg: #dfc2c4; --bs-table-active-color: #000; -=
-bs-table-hover-bg: #e5c7ca; --bs-table-hover-color: #000; color: var(--bs-=
table-color); border-color: var(--bs-table-border-color); }

.table-light { --bs-table-color: #000; --bs-table-bg: #f8f9fa; --bs-table-b=
order-color: #dfe0e1; --bs-table-striped-bg: #ecedee; --bs-table-striped-co=
lor: #000; --bs-table-active-bg: #dfe0e1; --bs-table-active-color: #000; --=
bs-table-hover-bg: #e5e6e7; --bs-table-hover-color: #000; color: var(--bs-t=
able-color); border-color: var(--bs-table-border-color); }

.table-dark { --bs-table-color: #fff; --bs-table-bg: #212529; --bs-table-bo=
rder-color: #373b3e; --bs-table-striped-bg: #2c3034; --bs-table-striped-col=
or: #fff; --bs-table-active-bg: #373b3e; --bs-table-active-color: #fff; --b=
s-table-hover-bg: #323539; --bs-table-hover-color: #fff; color: var(--bs-ta=
ble-color); border-color: var(--bs-table-border-color); }

.table-responsive { overflow-x: auto; }

@media (max-width: 575.98px) {
  .table-responsive-sm { overflow-x: auto; }
}

@media (max-width: 767.98px) {
  .table-responsive-md { overflow-x: auto; }
}

@media (max-width: 991.98px) {
  .table-responsive-lg { overflow-x: auto; }
}

@media (max-width: 1199.98px) {
  .table-responsive-xl { overflow-x: auto; }
}

@media (max-width: 1399.98px) {
  .table-responsive-xxl { overflow-x: auto; }
}

.form-label { margin-bottom: 0.5rem; }

.col-form-label { padding-top: calc(1px + 0.375rem); padding-bottom: calc(1=
px + 0.375rem); margin-bottom: 0px; font-size: inherit; line-height: 1.5; }

.col-form-label-lg { padding-top: calc(1px + 0.5rem); padding-bottom: calc(=
1px + 0.5rem); font-size: 1.025rem; }

.col-form-label-sm { padding-top: calc(1px + 0.25rem); padding-bottom: calc=
(1px + 0.25rem); font-size: 0.7175rem; }

.form-text { margin-top: 0.25rem; font-size: 0.875em; color: rgb(108, 117, =
125); }

.form-control { display: block; width: 100%; padding: 0.375rem 0.75rem; fon=
t-size: 0.82rem; font-weight: 400; line-height: 1.5; color: rgb(68, 68, 68)=
; background-color: rgb(255, 255, 255); background-clip: padding-box; borde=
r: 1px solid rgb(206, 212, 218); appearance: none; border-radius: 0.25rem; =
box-shadow: rgba(0, 0, 0, 0.075) 0px 1px 2px inset; }

.form-control[type=3D"file"] { overflow: hidden; }

.form-control[type=3D"file"]:not(:disabled):not([readonly]) { cursor: point=
er; }

.form-control:focus { color: rgb(68, 68, 68); background-color: rgb(255, 25=
5, 255); border-color: rgb(238, 238, 238); outline: 0px; box-shadow: rgba(0=
, 0, 0, 0.075) 0px 1px 2px inset, rgba(221, 221, 221, 0.25) 0px 0px 0px 0.2=
5rem; }

.form-control::-webkit-date-and-time-value { height: 1.5em; }

.form-control::placeholder { color: rgb(108, 117, 125); opacity: 1; }

.form-control:disabled { background-color: rgb(233, 236, 239); opacity: 1; =
}

.form-control::-webkit-file-upload-button { padding: 0.375rem 0.75rem; marg=
in: -0.375rem -0.75rem; margin-inline-end: 0.75rem; color: rgb(68, 68, 68);=
 background-color: rgb(233, 236, 239); background-image: var(--bs-gradient)=
; pointer-events: none; border-color: inherit; border-style: solid; border-=
width: 0px; border-inline-end-width: 1px; border-radius: 0px; }

.form-control::file-selector-button { padding: 0.375rem 0.75rem; margin: -0=
.375rem -0.75rem; margin-inline-end: 0.75rem; color: rgb(68, 68, 68); backg=
round-color: rgb(233, 236, 239); background-image: var(--bs-gradient); poin=
ter-events: none; border-color: inherit; border-style: solid; border-width:=
 0px; border-inline-end-width: 1px; border-radius: 0px; }

.form-control:hover:not(:disabled):not([readonly])::-webkit-file-upload-but=
ton { background-color: rgb(221, 224, 227); }

.form-control:hover:not(:disabled):not([readonly])::file-selector-button { =
background-color: rgb(221, 224, 227); }

.form-control-plaintext { display: block; width: 100%; padding: 0.375rem 0p=
x; margin-bottom: 0px; line-height: 1.5; color: rgb(68, 68, 68); background=
-color: rgba(0, 0, 0, 0); border-style: solid; border-color: rgba(0, 0, 0, =
0); border-image: initial; border-width: 1px 0px; }

.form-control-plaintext:focus { outline: 0px; }

.form-control-plaintext.form-control-sm, .form-control-plaintext.form-contr=
ol-lg { padding-right: 0px; padding-left: 0px; }

.form-control-sm { min-height: calc(1.5em + 2px + 0.5rem); padding: 0.25rem=
 0.5rem; font-size: 0.7175rem; border-radius: 0.25rem; }

.form-control-sm::-webkit-file-upload-button { padding: 0.25rem 0.5rem; mar=
gin: -0.25rem -0.5rem; margin-inline-end: 0.5rem; }

.form-control-sm::file-selector-button { padding: 0.25rem 0.5rem; margin: -=
0.25rem -0.5rem; margin-inline-end: 0.5rem; }

.form-control-lg { min-height: calc(1.5em + 2px + 1rem); padding: 0.5rem 1r=
em; font-size: 1.025rem; border-radius: 0.5rem; }

.form-control-lg::-webkit-file-upload-button { padding: 0.5rem 1rem; margin=
: -0.5rem -1rem; margin-inline-end: 1rem; }

.form-control-lg::file-selector-button { padding: 0.5rem 1rem; margin: -0.5=
rem -1rem; margin-inline-end: 1rem; }

textarea.form-control { min-height: calc(1.5em + 2px + 0.75rem); }

textarea.form-control-sm { min-height: calc(1.5em + 2px + 0.5rem); }

textarea.form-control-lg { min-height: calc(1.5em + 2px + 1rem); }

.form-control-color { width: 3rem; height: calc(1.5em + 2px + 0.75rem); pad=
ding: 0.375rem; }

.form-control-color:not(:disabled):not([readonly]) { cursor: pointer; }

.form-control-color::-webkit-color-swatch { border-radius: 0.25rem; }

.form-control-color.form-control-sm { height: calc(1.5em + 2px + 0.5rem); }

.form-control-color.form-control-lg { height: calc(1.5em + 2px + 1rem); }

.form-select { display: block; width: 100%; padding: 0.375rem 2.25rem 0.375=
rem 0.75rem; font-size: 0.82rem; font-weight: 400; line-height: 1.5; color:=
 rgb(68, 68, 68); background-color: rgb(255, 255, 255); background-image: u=
rl("data:image/svg+xml,%3csvg xmlns=3D'http://www.w3.org/2000/svg' viewBox=
=3D'0 0 16 16'%3e%3cpath fill=3D'none' stroke=3D'%23343a40' stroke-linecap=
=3D'round' stroke-linejoin=3D'round' stroke-width=3D'2' d=3D'm2 5 6 6 6-6'/=
%3e%3c/svg%3e"); background-repeat: no-repeat; background-position: right 0=
.75rem center; background-size: 16px 12px; border: 1px solid rgb(206, 212, =
218); border-radius: 0.25rem; box-shadow: rgba(0, 0, 0, 0.075) 0px 1px 2px =
inset; appearance: none; }

.form-select:focus { border-color: rgb(238, 238, 238); outline: 0px; box-sh=
adow: rgba(0, 0, 0, 0.075) 0px 1px 2px inset, rgba(221, 221, 221, 0.25) 0px=
 0px 0px 0.25rem; }

.form-select[multiple], .form-select[size]:not([size=3D"1"]) { padding-righ=
t: 0.75rem; background-image: none; }

.form-select:disabled { background-color: rgb(233, 236, 239); }

.form-select-sm { padding-top: 0.25rem; padding-bottom: 0.25rem; padding-le=
ft: 0.5rem; font-size: 0.7175rem; border-radius: 0.25rem; }

.form-select-lg { padding-top: 0.5rem; padding-bottom: 0.5rem; padding-left=
: 1rem; font-size: 1.025rem; border-radius: 0.5rem; }

.form-check { display: block; min-height: 1.23rem; padding-left: 1.5em; mar=
gin-bottom: 0.125rem; }

.form-check .form-check-input { float: left; margin-left: -1.5em; }

.form-check-reverse { padding-right: 1.5em; padding-left: 0px; text-align: =
right; }

.form-check-reverse .form-check-input { float: right; margin-right: -1.5em;=
 margin-left: 0px; }

.form-check-input { width: 1em; height: 1em; margin-top: 0.25em; vertical-a=
lign: top; background-color: rgb(255, 255, 255); background-repeat: no-repe=
at; background-position: center center; background-size: contain; border: 1=
px solid rgba(0, 0, 0, 0.25); appearance: none; print-color-adjust: exact; =
}

.form-check-input[type=3D"checkbox"] { border-radius: 0.25em; }

.form-check-input[type=3D"radio"] { border-radius: 50%; }

.form-check-input:active { filter: brightness(90%); }

.form-check-input:focus { border-color: rgb(238, 238, 238); outline: 0px; b=
ox-shadow: rgba(221, 221, 221, 0.25) 0px 0px 0px 0.25rem; }

.form-check-input:checked { background-color: rgb(0, 117, 255); border-colo=
r: rgb(0, 117, 255); }

.form-check-input:checked[type=3D"checkbox"] { background-image: url("data:=
image/svg+xml,%3csvg xmlns=3D'http://www.w3.org/2000/svg' viewBox=3D'0 0 20=
 20'%3e%3cpath fill=3D'none' stroke=3D'%23fff' stroke-linecap=3D'round' str=
oke-linejoin=3D'round' stroke-width=3D'3' d=3D'm6 10 3 3 6-6'/%3e%3c/svg%3e=
"),var(--bs-gradient); }

.form-check-input:checked[type=3D"radio"] { background-image: url("data:ima=
ge/svg+xml,%3csvg xmlns=3D'http://www.w3.org/2000/svg' viewBox=3D'-4 -4 8 8=
'%3e%3ccircle r=3D'2' fill=3D'%23fff'/%3e%3c/svg%3e"),var(--bs-gradient); }

.form-check-input[type=3D"checkbox"]:indeterminate { background-color: rgb(=
221, 221, 221); border-color: rgb(221, 221, 221); background-image: url("da=
ta:image/svg+xml,%3csvg xmlns=3D'http://www.w3.org/2000/svg' viewBox=3D'0 0=
 20 20'%3e%3cpath fill=3D'none' stroke=3D'%23fff' stroke-linecap=3D'round' =
stroke-linejoin=3D'round' stroke-width=3D'3' d=3D'M6 10h8'/%3e%3c/svg%3e"),=
var(--bs-gradient); }

.form-check-input:disabled { pointer-events: none; filter: none; opacity: 0=
.5; }

.form-check-input[disabled] ~ .form-check-label, .form-check-input:disabled=
 ~ .form-check-label { cursor: default; opacity: 0.5; }

.form-switch { padding-left: 2.5em; }

.form-switch .form-check-input { width: 2em; margin-left: -2.5em; backgroun=
d-image: url("data:image/svg+xml,%3csvg xmlns=3D'http://www.w3.org/2000/svg=
' viewBox=3D'-4 -4 8 8'%3e%3ccircle r=3D'3' fill=3D'rgba%280, 0, 0, 0.25%29=
'/%3e%3c/svg%3e"); background-position: left center; border-radius: 2em; }

.form-switch .form-check-input:focus { background-image: url("data:image/sv=
g+xml,%3csvg xmlns=3D'http://www.w3.org/2000/svg' viewBox=3D'-4 -4 8 8'%3e%=
3ccircle r=3D'3' fill=3D'%23eeeeee'/%3e%3c/svg%3e"); }

.form-switch .form-check-input:checked { background-position: right center;=
 background-image: url("data:image/svg+xml,%3csvg xmlns=3D'http://www.w3.or=
g/2000/svg' viewBox=3D'-4 -4 8 8'%3e%3ccircle r=3D'3' fill=3D'%23fff'/%3e%3=
c/svg%3e"),var(--bs-gradient); }

.form-switch.form-check-reverse { padding-right: 2.5em; padding-left: 0px; =
}

.form-switch.form-check-reverse .form-check-input { margin-right: -2.5em; m=
argin-left: 0px; }

.form-check-inline { display: inline-block; margin-right: 1rem; }

.btn-check { position: absolute; clip: rect(0px, 0px, 0px, 0px); pointer-ev=
ents: none; }

.btn-check[disabled] + .btn, .btn-check:disabled + .btn { pointer-events: n=
one; filter: none; opacity: 0.65; }

.form-range { width: 100%; height: 1.5rem; padding: 0px; background-color: =
rgba(0, 0, 0, 0); appearance: none; }

.form-range:focus { outline: 0px; }

.form-range:focus::-webkit-slider-thumb { box-shadow: rgb(255, 255, 255) 0p=
x 0px 0px 1px, rgba(221, 221, 221, 0.25) 0px 0px 0px 0.25rem; }

.form-range::-webkit-slider-thumb { width: 1rem; height: 1rem; margin-top: =
-0.25rem; background-color: rgb(221, 221, 221); background-image: var(--bs-=
gradient); border: 0px; border-radius: 1rem; box-shadow: rgba(0, 0, 0, 0.1)=
 0px 0.1rem 0.25rem; appearance: none; }

.form-range::-webkit-slider-thumb:active { background-color: rgb(245, 245, =
245); background-image: var(--bs-gradient); }

.form-range::-webkit-slider-runnable-track { width: 100%; height: 0.5rem; c=
olor: rgba(0, 0, 0, 0); cursor: pointer; background-color: rgb(222, 226, 23=
0); border-color: rgba(0, 0, 0, 0); border-radius: 1rem; box-shadow: rgba(0=
, 0, 0, 0.075) 0px 1px 2px inset; }

.form-range:disabled { pointer-events: none; }

.form-range:disabled::-webkit-slider-thumb { background-color: rgb(173, 181=
, 189); }

.form-floating { position: relative; }

.form-floating > .form-control, .form-floating > .form-control-plaintext, .=
form-floating > .form-select { height: calc(2px + 3.5rem); line-height: 1.2=
5; }

.form-floating > label { position: absolute; top: 0px; left: 0px; width: 10=
0%; height: 100%; padding: 1rem 0.75rem; overflow: hidden; text-align: star=
t; text-overflow: ellipsis; white-space: nowrap; pointer-events: none; bord=
er: 1px solid rgba(0, 0, 0, 0); transform-origin: 0px 0px; }

.form-floating > .form-control, .form-floating > .form-control-plaintext { =
padding: 1rem 0.75rem; }

.form-floating > .form-control::placeholder, .form-floating > .form-control=
-plaintext::placeholder { color: rgba(0, 0, 0, 0); }

.form-floating > .form-control:focus, .form-floating > .form-control:not(:p=
laceholder-shown), .form-floating > .form-control-plaintext:focus, .form-fl=
oating > .form-control-plaintext:not(:placeholder-shown) { padding-top: 1.6=
25rem; padding-bottom: 0.625rem; }

.form-floating > .form-control:-webkit-autofill, .form-floating > .form-con=
trol-plaintext:-webkit-autofill { padding-top: 1.625rem; padding-bottom: 0.=
625rem; }

.form-floating > .form-select { padding-top: 1.625rem; padding-bottom: 0.62=
5rem; }

.form-floating > .form-control:focus ~ label, .form-floating > .form-contro=
l:not(:placeholder-shown) ~ label, .form-floating > .form-control-plaintext=
 ~ label, .form-floating > .form-select ~ label { opacity: 0.65; transform:=
 scale(0.85) translateY(-0.5rem) translateX(0.15rem); }

.form-floating > .form-control:-webkit-autofill ~ label { opacity: 0.65; tr=
ansform: scale(0.85) translateY(-0.5rem) translateX(0.15rem); }

.form-floating > .form-control-plaintext ~ label { border-width: 1px 0px; }

.input-group { position: relative; display: flex; flex-wrap: wrap; align-it=
ems: stretch; width: 100%; }

.input-group > .form-control, .input-group > .form-select, .input-group > .=
form-floating { position: relative; flex: 1 1 auto; width: 1%; min-width: 0=
px; }

.input-group > .form-control:focus, .input-group > .form-select:focus, .inp=
ut-group > .form-floating:focus-within { z-index: 5; }

.input-group .btn { position: relative; z-index: 2; }

.input-group .btn:focus { z-index: 5; }

.input-group-text { display: flex; align-items: center; padding: 0.375rem 0=
.75rem; font-size: 0.82rem; font-weight: 400; line-height: 1.5; color: rgb(=
68, 68, 68); text-align: center; white-space: nowrap; background-color: rgb=
(233, 236, 239); border: 1px solid rgb(206, 212, 218); border-radius: 0.25r=
em; }

.input-group-lg > .form-control, .input-group-lg > .form-select, .input-gro=
up-lg > .input-group-text, .input-group-lg > .btn { padding: 0.5rem 1rem; f=
ont-size: 1.025rem; border-radius: 0.5rem; }

.input-group-sm > .form-control, .input-group-sm > .form-select, .input-gro=
up-sm > .input-group-text, .input-group-sm > .btn { padding: 0.25rem 0.5rem=
; font-size: 0.7175rem; border-radius: 0.25rem; }

.input-group-lg > .form-select, .input-group-sm > .form-select { padding-ri=
ght: 3rem; }

.input-group:not(.has-validation) > :not(:last-child):not(.dropdown-toggle)=
:not(.dropdown-menu):not(.form-floating), .input-group:not(.has-validation)=
 > .dropdown-toggle:nth-last-child(n+3), .input-group:not(.has-validation) =
> .form-floating:not(:last-child) > .form-control, .input-group:not(.has-va=
lidation) > .form-floating:not(:last-child) > .form-select { border-top-rig=
ht-radius: 0px; border-bottom-right-radius: 0px; }

.input-group.has-validation > :nth-last-child(n+3):not(.dropdown-toggle):no=
t(.dropdown-menu):not(.form-floating), .input-group.has-validation > .dropd=
own-toggle:nth-last-child(n+4), .input-group.has-validation > .form-floatin=
g:nth-last-child(n+3) > .form-control, .input-group.has-validation > .form-=
floating:nth-last-child(n+3) > .form-select { border-top-right-radius: 0px;=
 border-bottom-right-radius: 0px; }

.input-group > :not(:first-child):not(.dropdown-menu):not(.valid-tooltip):n=
ot(.valid-feedback):not(.invalid-tooltip):not(.invalid-feedback) { margin-l=
eft: -1px; border-top-left-radius: 0px; border-bottom-left-radius: 0px; }

.input-group > .form-floating:not(:first-child) > .form-control, .input-gro=
up > .form-floating:not(:first-child) > .form-select { border-top-left-radi=
us: 0px; border-bottom-left-radius: 0px; }

.valid-feedback { display: none; width: 100%; margin-top: 0.25rem; font-siz=
e: 0.875em; color: rgb(25, 135, 84); }

.valid-tooltip { position: absolute; top: 100%; z-index: 5; display: none; =
max-width: 100%; padding: 0.25rem 0.5rem; margin-top: 0.1rem; font-size: 0.=
7175rem; color: rgb(255, 255, 255); background-color: rgba(25, 135, 84, 0.9=
); border-radius: 0.25rem; }

.was-validated :valid ~ .valid-feedback, .was-validated :valid ~ .valid-too=
ltip, .is-valid ~ .valid-feedback, .is-valid ~ .valid-tooltip { display: bl=
ock; }

.was-validated .form-control:valid, .form-control.is-valid { border-color: =
rgb(25, 135, 84); padding-right: calc(1.5em + 0.75rem); background-image: u=
rl("data:image/svg+xml,%3csvg xmlns=3D'http://www.w3.org/2000/svg' viewBox=
=3D'0 0 8 8'%3e%3cpath fill=3D'%23198754' d=3D'M2.3 6.73.6 4.53c-.4-1.04.46=
-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'=
/%3e%3c/svg%3e"); background-repeat: no-repeat; background-position: right =
calc(0.375em + 0.1875rem) center; background-size: calc(0.75em + 0.375rem) =
calc(0.75em + 0.375rem); }

.was-validated .form-control:valid:focus, .form-control.is-valid:focus { bo=
rder-color: rgb(25, 135, 84); box-shadow: rgba(25, 135, 84, 0.25) 0px 0px 0=
px 0.25rem; }

.was-validated textarea.form-control:valid, textarea.form-control.is-valid =
{ padding-right: calc(1.5em + 0.75rem); background-position: right calc(0.3=
75em + 0.1875rem) top calc(0.375em + 0.1875rem); }

.was-validated .form-select:valid, .form-select.is-valid { border-color: rg=
b(25, 135, 84); }

.was-validated .form-select:valid:not([multiple]):not([size]), .was-validat=
ed .form-select:valid:not([multiple])[size=3D"1"], .form-select.is-valid:no=
t([multiple]):not([size]), .form-select.is-valid:not([multiple])[size=3D"1"=
] { padding-right: 4.125rem; background-image: url("data:image/svg+xml,%3cs=
vg xmlns=3D'http://www.w3.org/2000/svg' viewBox=3D'0 0 16 16'%3e%3cpath fil=
l=3D'none' stroke=3D'%23343a40' stroke-linecap=3D'round' stroke-linejoin=3D=
'round' stroke-width=3D'2' d=3D'm2 5 6 6 6-6'/%3e%3c/svg%3e"), url("data:im=
age/svg+xml,%3csvg xmlns=3D'http://www.w3.org/2000/svg' viewBox=3D'0 0 8 8'=
%3e%3cpath fill=3D'%23198754' d=3D'M2.3 6.73.6 4.53c-.4-1.04.46-1.4 1.1-.8l=
1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3e%3c/svg%=
3e"); background-position: right 0.75rem center, right 2.25rem center; back=
ground-size: 16px 12px, calc(0.75em + 0.375rem) calc(0.75em + 0.375rem); }

.was-validated .form-select:valid:focus, .form-select.is-valid:focus { bord=
er-color: rgb(25, 135, 84); box-shadow: rgba(25, 135, 84, 0.25) 0px 0px 0px=
 0.25rem; }

.was-validated .form-control-color:valid, .form-control-color.is-valid { wi=
dth: calc(1.5em + 3.75rem); }

.was-validated .form-check-input:valid, .form-check-input.is-valid { border=
-color: rgb(25, 135, 84); }

.was-validated .form-check-input:valid:checked, .form-check-input.is-valid:=
checked { background-color: rgb(25, 135, 84); }

.was-validated .form-check-input:valid:focus, .form-check-input.is-valid:fo=
cus { box-shadow: rgba(25, 135, 84, 0.25) 0px 0px 0px 0.25rem; }

.was-validated .form-check-input:valid ~ .form-check-label, .form-check-inp=
ut.is-valid ~ .form-check-label { color: rgb(25, 135, 84); }

.form-check-inline .form-check-input ~ .valid-feedback { margin-left: 0.5em=
; }

.was-validated .input-group > .form-control:not(:focus):valid, .input-group=
 > .form-control:not(:focus).is-valid, .was-validated .input-group > .form-=
select:not(:focus):valid, .input-group > .form-select:not(:focus).is-valid,=
 .was-validated .input-group > .form-floating:not(:focus-within):valid, .in=
put-group > .form-floating:not(:focus-within).is-valid { z-index: 3; }

.invalid-feedback { display: none; width: 100%; margin-top: 0.25rem; font-s=
ize: 0.875em; color: rgb(220, 53, 69); }

.invalid-tooltip { position: absolute; top: 100%; z-index: 5; display: none=
; max-width: 100%; padding: 0.25rem 0.5rem; margin-top: 0.1rem; font-size: =
0.7175rem; color: rgb(255, 255, 255); background-color: rgba(220, 53, 69, 0=
.9); border-radius: 0.25rem; }

.was-validated :invalid ~ .invalid-feedback, .was-validated :invalid ~ .inv=
alid-tooltip, .is-invalid ~ .invalid-feedback, .is-invalid ~ .invalid-toolt=
ip { display: block; }

.was-validated .form-control:invalid, .form-control.is-invalid { border-col=
or: rgb(220, 53, 69); padding-right: calc(1.5em + 0.75rem); background-imag=
e: url("data:image/svg+xml,%3csvg xmlns=3D'http://www.w3.org/2000/svg' view=
Box=3D'0 0 12 12' width=3D'12' height=3D'12' fill=3D'none' stroke=3D'%23dc3=
545'%3e%3ccircle cx=3D'6' cy=3D'6' r=3D'4.5'/%3e%3cpath stroke-linejoin=3D'=
round' d=3D'M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx=3D'6' cy=3D'8.2' r=3D'.6' f=
ill=3D'%23dc3545' stroke=3D'none'/%3e%3c/svg%3e"); background-repeat: no-re=
peat; background-position: right calc(0.375em + 0.1875rem) center; backgrou=
nd-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem); }

.was-validated .form-control:invalid:focus, .form-control.is-invalid:focus =
{ border-color: rgb(220, 53, 69); box-shadow: rgba(220, 53, 69, 0.25) 0px 0=
px 0px 0.25rem; }

.was-validated textarea.form-control:invalid, textarea.form-control.is-inva=
lid { padding-right: calc(1.5em + 0.75rem); background-position: right calc=
(0.375em + 0.1875rem) top calc(0.375em + 0.1875rem); }

.was-validated .form-select:invalid, .form-select.is-invalid { border-color=
: rgb(220, 53, 69); }

.was-validated .form-select:invalid:not([multiple]):not([size]), .was-valid=
ated .form-select:invalid:not([multiple])[size=3D"1"], .form-select.is-inva=
lid:not([multiple]):not([size]), .form-select.is-invalid:not([multiple])[si=
ze=3D"1"] { padding-right: 4.125rem; background-image: url("data:image/svg+=
xml,%3csvg xmlns=3D'http://www.w3.org/2000/svg' viewBox=3D'0 0 16 16'%3e%3c=
path fill=3D'none' stroke=3D'%23343a40' stroke-linecap=3D'round' stroke-lin=
ejoin=3D'round' stroke-width=3D'2' d=3D'm2 5 6 6 6-6'/%3e%3c/svg%3e"), url(=
"data:image/svg+xml,%3csvg xmlns=3D'http://www.w3.org/2000/svg' viewBox=3D'=
0 0 12 12' width=3D'12' height=3D'12' fill=3D'none' stroke=3D'%23dc3545'%3e=
%3ccircle cx=3D'6' cy=3D'6' r=3D'4.5'/%3e%3cpath stroke-linejoin=3D'round' =
d=3D'M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx=3D'6' cy=3D'8.2' r=3D'.6' fill=3D'=
%23dc3545' stroke=3D'none'/%3e%3c/svg%3e"); background-position: right 0.75=
rem center, right 2.25rem center; background-size: 16px 12px, calc(0.75em +=
 0.375rem) calc(0.75em + 0.375rem); }

.was-validated .form-select:invalid:focus, .form-select.is-invalid:focus { =
border-color: rgb(220, 53, 69); box-shadow: rgba(220, 53, 69, 0.25) 0px 0px=
 0px 0.25rem; }

.was-validated .form-control-color:invalid, .form-control-color.is-invalid =
{ width: calc(1.5em + 3.75rem); }

.was-validated .form-check-input:invalid, .form-check-input.is-invalid { bo=
rder-color: rgb(220, 53, 69); }

.was-validated .form-check-input:invalid:checked, .form-check-input.is-inva=
lid:checked { background-color: rgb(220, 53, 69); }

.was-validated .form-check-input:invalid:focus, .form-check-input.is-invali=
d:focus { box-shadow: rgba(220, 53, 69, 0.25) 0px 0px 0px 0.25rem; }

.was-validated .form-check-input:invalid ~ .form-check-label, .form-check-i=
nput.is-invalid ~ .form-check-label { color: rgb(220, 53, 69); }

.form-check-inline .form-check-input ~ .invalid-feedback { margin-left: 0.5=
em; }

.was-validated .input-group > .form-control:not(:focus):invalid, .input-gro=
up > .form-control:not(:focus).is-invalid, .was-validated .input-group > .f=
orm-select:not(:focus):invalid, .input-group > .form-select:not(:focus).is-=
invalid, .was-validated .input-group > .form-floating:not(:focus-within):in=
valid, .input-group > .form-floating:not(:focus-within).is-invalid { z-inde=
x: 4; }

.btn { --bs-btn-padding-x: 0.75rem; --bs-btn-padding-y: 0.375rem; --bs-btn-=
font-family: ; --bs-btn-font-size: 0.82rem; --bs-btn-font-weight: 400; --bs=
-btn-line-height: 1.15; --bs-btn-color: #444; --bs-btn-bg: transparent; --b=
s-btn-border-width: 1px; --bs-btn-border-color: transparent; --bs-btn-borde=
r-radius: 0.85rem; --bs-btn-hover-border-color: transparent; --bs-btn-box-s=
hadow: inset 0 1px 0 rgba(255, 255, 255, 0.15), 0 1px 1px rgba(0, 0, 0, 0.0=
75); --bs-btn-disabled-opacity: 0.65; --bs-btn-focus-box-shadow: 0 0 0 0.25=
rem rgba(var(--bs-btn-focus-shadow-rgb), .5); display: inline-block; paddin=
g: var(--bs-btn-padding-y) var(--bs-btn-padding-x); font-family: var(--bs-b=
tn-font-family); font-size: var(--bs-btn-font-size); font-weight: var(--bs-=
btn-font-weight); line-height: var(--bs-btn-line-height); color: var(--bs-b=
tn-color); text-align: center; vertical-align: middle; cursor: pointer; use=
r-select: none; border: var(--bs-btn-border-width) solid var(--bs-btn-borde=
r-color); border-radius: var(--bs-btn-border-radius); background-color: var=
(--bs-btn-bg); background-image: var(--bs-gradient); box-shadow: var(--bs-b=
tn-box-shadow); }

.btn:hover { color: var(--bs-btn-hover-color); text-decoration: none; backg=
round-color: var(--bs-btn-hover-bg); border-color: var(--bs-btn-hover-borde=
r-color); }

.btn-check + .btn:hover { color: var(--bs-btn-color); background-color: var=
(--bs-btn-bg); border-color: var(--bs-btn-border-color); }

.btn:focus-visible { color: var(--bs-btn-hover-color); background-color: va=
r(--bs-btn-hover-bg); background-image: var(--bs-gradient); border-color: v=
ar(--bs-btn-hover-border-color); outline: 0px; box-shadow: var(--bs-btn-box=
-shadow),var(--bs-btn-focus-box-shadow); }

.btn-check:focus-visible + .btn { border-color: var(--bs-btn-hover-border-c=
olor); outline: 0px; box-shadow: var(--bs-btn-box-shadow),var(--bs-btn-focu=
s-box-shadow); }

.btn-check:checked + .btn, :not(.btn-check) + .btn:active, .btn:first-child=
:active, .btn.active, .btn.show { color: var(--bs-btn-active-color); backgr=
ound-color: var(--bs-btn-active-bg); background-image: none; border-color: =
var(--bs-btn-active-border-color); box-shadow: var(--bs-btn-active-shadow);=
 }

.btn-check:checked + .btn:focus-visible, :not(.btn-check) + .btn:active:foc=
us-visible, .btn:first-child:active:focus-visible, .btn.active:focus-visibl=
e, .btn.show:focus-visible { box-shadow: var(--bs-btn-active-shadow),var(--=
bs-btn-focus-box-shadow); }

.btn:disabled, .btn.disabled, fieldset:disabled .btn { color: var(--bs-btn-=
disabled-color); pointer-events: none; background-color: var(--bs-btn-disab=
led-bg); background-image: none; border-color: var(--bs-btn-disabled-border=
-color); opacity: var(--bs-btn-disabled-opacity); box-shadow: none; }

.btn-primary { --bs-btn-color: #000; --bs-btn-bg: #ddd; --bs-btn-border-col=
or: #ddd; --bs-btn-hover-color: #000; --bs-btn-hover-bg: #e2e2e2; --bs-btn-=
hover-border-color: #e0e0e0; --bs-btn-focus-shadow-rgb: 188, 188, 188; --bs=
-btn-active-color: #000; --bs-btn-active-bg: #e4e4e4; --bs-btn-active-borde=
r-color: #e0e0e0; --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.1=
25); --bs-btn-disabled-color: #000; --bs-btn-disabled-bg: #ddd; --bs-btn-di=
sabled-border-color: #ddd; }

.btn-secondary { --bs-btn-color: #000; --bs-btn-bg: #ddd; --bs-btn-border-c=
olor: #ddd; --bs-btn-hover-color: #000; --bs-btn-hover-bg: #e2e2e2; --bs-bt=
n-hover-border-color: #e0e0e0; --bs-btn-focus-shadow-rgb: 188, 188, 188; --=
bs-btn-active-color: #000; --bs-btn-active-bg: #e4e4e4; --bs-btn-active-bor=
der-color: #e0e0e0; --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0=
.125); --bs-btn-disabled-color: #000; --bs-btn-disabled-bg: #ddd; --bs-btn-=
disabled-border-color: #ddd; }

.btn-success { --bs-btn-color: #fff; --bs-btn-bg: #198754; --bs-btn-border-=
color: #198754; --bs-btn-hover-color: #fff; --bs-btn-hover-bg: #157347; --b=
s-btn-hover-border-color: #146c43; --bs-btn-focus-shadow-rgb: 60, 153, 110;=
 --bs-btn-active-color: #fff; --bs-btn-active-bg: #146c43; --bs-btn-active-=
border-color: #13653f; --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0=
, 0.125); --bs-btn-disabled-color: #fff; --bs-btn-disabled-bg: #198754; --b=
s-btn-disabled-border-color: #198754; }

.btn-info { --bs-btn-color: #000; --bs-btn-bg: #0dcaf0; --bs-btn-border-col=
or: #0dcaf0; --bs-btn-hover-color: #000; --bs-btn-hover-bg: #31d2f2; --bs-b=
tn-hover-border-color: #25cff2; --bs-btn-focus-shadow-rgb: 11, 172, 204; --=
bs-btn-active-color: #000; --bs-btn-active-bg: #3dd5f3; --bs-btn-active-bor=
der-color: #25cff2; --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0=
.125); --bs-btn-disabled-color: #000; --bs-btn-disabled-bg: #0dcaf0; --bs-b=
tn-disabled-border-color: #0dcaf0; }

.btn-warning { --bs-btn-color: #000; --bs-btn-bg: #ffc107; --bs-btn-border-=
color: #ffc107; --bs-btn-hover-color: #000; --bs-btn-hover-bg: #ffca2c; --b=
s-btn-hover-border-color: #ffc720; --bs-btn-focus-shadow-rgb: 217, 164, 6; =
--bs-btn-active-color: #000; --bs-btn-active-bg: #ffcd39; --bs-btn-active-b=
order-color: #ffc720; --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0,=
 0.125); --bs-btn-disabled-color: #000; --bs-btn-disabled-bg: #ffc107; --bs=
-btn-disabled-border-color: #ffc107; }

.btn-danger { --bs-btn-color: #fff; --bs-btn-bg: #dc3545; --bs-btn-border-c=
olor: #dc3545; --bs-btn-hover-color: #fff; --bs-btn-hover-bg: #bb2d3b; --bs=
-btn-hover-border-color: #b02a37; --bs-btn-focus-shadow-rgb: 225, 83, 97; -=
-bs-btn-active-color: #fff; --bs-btn-active-bg: #b02a37; --bs-btn-active-bo=
rder-color: #a52834; --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, =
0.125); --bs-btn-disabled-color: #fff; --bs-btn-disabled-bg: #dc3545; --bs-=
btn-disabled-border-color: #dc3545; }

.btn-light { --bs-btn-color: #000; --bs-btn-bg: #f8f9fa; --bs-btn-border-co=
lor: #f8f9fa; --bs-btn-hover-color: #000; --bs-btn-hover-bg: #d3d4d5; --bs-=
btn-hover-border-color: #c6c7c8; --bs-btn-focus-shadow-rgb: 211, 212, 213; =
--bs-btn-active-color: #000; --bs-btn-active-bg: #c6c7c8; --bs-btn-active-b=
order-color: #babbbc; --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0,=
 0.125); --bs-btn-disabled-color: #000; --bs-btn-disabled-bg: #f8f9fa; --bs=
-btn-disabled-border-color: #f8f9fa; }

.btn-dark { --bs-btn-color: #fff; --bs-btn-bg: #212529; --bs-btn-border-col=
or: #212529; --bs-btn-hover-color: #fff; --bs-btn-hover-bg: #424649; --bs-b=
tn-hover-border-color: #373b3e; --bs-btn-focus-shadow-rgb: 66, 70, 73; --bs=
-btn-active-color: #fff; --bs-btn-active-bg: #4d5154; --bs-btn-active-borde=
r-color: #373b3e; --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.1=
25); --bs-btn-disabled-color: #fff; --bs-btn-disabled-bg: #212529; --bs-btn=
-disabled-border-color: #212529; }

.btn-outline-primary { --bs-btn-color: #ddd; --bs-btn-border-color: #ddd; -=
-bs-btn-hover-color: #000; --bs-btn-hover-bg: #ddd; --bs-btn-hover-border-c=
olor: #ddd; --bs-btn-focus-shadow-rgb: 221, 221, 221; --bs-btn-active-color=
: #000; --bs-btn-active-bg: #ddd; --bs-btn-active-border-color: #ddd; --bs-=
btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125); --bs-btn-disabled-=
color: #ddd; --bs-btn-disabled-bg: transparent; --bs-btn-disabled-border-co=
lor: #ddd; --bs-gradient: none; }

.btn-outline-secondary { --bs-btn-color: #ddd; --bs-btn-border-color: #ddd;=
 --bs-btn-hover-color: #000; --bs-btn-hover-bg: #ddd; --bs-btn-hover-border=
-color: #ddd; --bs-btn-focus-shadow-rgb: 221, 221, 221; --bs-btn-active-col=
or: #000; --bs-btn-active-bg: #ddd; --bs-btn-active-border-color: #ddd; --b=
s-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125); --bs-btn-disable=
d-color: #ddd; --bs-btn-disabled-bg: transparent; --bs-btn-disabled-border-=
color: #ddd; --bs-gradient: none; }

.btn-outline-success { --bs-btn-color: #198754; --bs-btn-border-color: #198=
754; --bs-btn-hover-color: #fff; --bs-btn-hover-bg: #198754; --bs-btn-hover=
-border-color: #198754; --bs-btn-focus-shadow-rgb: 25, 135, 84; --bs-btn-ac=
tive-color: #fff; --bs-btn-active-bg: #198754; --bs-btn-active-border-color=
: #198754; --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125); --=
bs-btn-disabled-color: #198754; --bs-btn-disabled-bg: transparent; --bs-btn=
-disabled-border-color: #198754; --bs-gradient: none; }

.btn-outline-info { --bs-btn-color: #0dcaf0; --bs-btn-border-color: #0dcaf0=
; --bs-btn-hover-color: #000; --bs-btn-hover-bg: #0dcaf0; --bs-btn-hover-bo=
rder-color: #0dcaf0; --bs-btn-focus-shadow-rgb: 13, 202, 240; --bs-btn-acti=
ve-color: #000; --bs-btn-active-bg: #0dcaf0; --bs-btn-active-border-color: =
#0dcaf0; --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125); --bs=
-btn-disabled-color: #0dcaf0; --bs-btn-disabled-bg: transparent; --bs-btn-d=
isabled-border-color: #0dcaf0; --bs-gradient: none; }

.btn-outline-warning { --bs-btn-color: #ffc107; --bs-btn-border-color: #ffc=
107; --bs-btn-hover-color: #000; --bs-btn-hover-bg: #ffc107; --bs-btn-hover=
-border-color: #ffc107; --bs-btn-focus-shadow-rgb: 255, 193, 7; --bs-btn-ac=
tive-color: #000; --bs-btn-active-bg: #ffc107; --bs-btn-active-border-color=
: #ffc107; --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125); --=
bs-btn-disabled-color: #ffc107; --bs-btn-disabled-bg: transparent; --bs-btn=
-disabled-border-color: #ffc107; --bs-gradient: none; }

.btn-outline-danger { --bs-btn-color: #dc3545; --bs-btn-border-color: #dc35=
45; --bs-btn-hover-color: #fff; --bs-btn-hover-bg: #dc3545; --bs-btn-hover-=
border-color: #dc3545; --bs-btn-focus-shadow-rgb: 220, 53, 69; --bs-btn-act=
ive-color: #fff; --bs-btn-active-bg: #dc3545; --bs-btn-active-border-color:=
 #dc3545; --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125); --b=
s-btn-disabled-color: #dc3545; --bs-btn-disabled-bg: transparent; --bs-btn-=
disabled-border-color: #dc3545; --bs-gradient: none; }

.btn-outline-light { --bs-btn-color: #f8f9fa; --bs-btn-border-color: #f8f9f=
a; --bs-btn-hover-color: #000; --bs-btn-hover-bg: #f8f9fa; --bs-btn-hover-b=
order-color: #f8f9fa; --bs-btn-focus-shadow-rgb: 248, 249, 250; --bs-btn-ac=
tive-color: #000; --bs-btn-active-bg: #f8f9fa; --bs-btn-active-border-color=
: #f8f9fa; --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125); --=
bs-btn-disabled-color: #f8f9fa; --bs-btn-disabled-bg: transparent; --bs-btn=
-disabled-border-color: #f8f9fa; --bs-gradient: none; }

.btn-outline-dark { --bs-btn-color: #212529; --bs-btn-border-color: #212529=
; --bs-btn-hover-color: #fff; --bs-btn-hover-bg: #212529; --bs-btn-hover-bo=
rder-color: #212529; --bs-btn-focus-shadow-rgb: 33, 37, 41; --bs-btn-active=
-color: #fff; --bs-btn-active-bg: #212529; --bs-btn-active-border-color: #2=
12529; --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125); --bs-b=
tn-disabled-color: #212529; --bs-btn-disabled-bg: transparent; --bs-btn-dis=
abled-border-color: #212529; --bs-gradient: none; }

.btn-link { --bs-btn-font-weight: 400; --bs-btn-color: var(--bs-link-color)=
; --bs-btn-bg: transparent; --bs-btn-border-color: transparent; --bs-btn-ho=
ver-color: var(--bs-link-hover-color); --bs-btn-hover-border-color: transpa=
rent; --bs-btn-active-color: var(--bs-link-hover-color); --bs-btn-active-bo=
rder-color: transparent; --bs-btn-disabled-color: #6c757d; --bs-btn-disable=
d-border-color: transparent; --bs-btn-box-shadow: none; --bs-btn-focus-shad=
ow-rgb: 188, 188, 188; text-decoration: none; background-image: none; }

.btn-link:hover, .btn-link:focus-visible { text-decoration: underline; }

.btn-link:focus-visible { color: var(--bs-btn-color); }

.btn-link:hover { color: var(--bs-btn-hover-color); }

.btn-lg, .btn-group-lg > .btn { --bs-btn-padding-y: 0.5rem; --bs-btn-paddin=
g-x: 1rem; --bs-btn-font-size: 1.025rem; --bs-btn-border-radius: 0.5rem; }

.btn-sm, .btn-group-sm > .btn { --bs-btn-padding-y: 0.25rem; --bs-btn-paddi=
ng-x: 0.5rem; --bs-btn-font-size: 0.7175rem; --bs-btn-border-radius: 0.25re=
m; }

.fade:not(.show) { opacity: 0; }

.collapse:not(.show) { display: none; }

.collapsing { height: 0px; overflow: hidden; }

.collapsing.collapse-horizontal { width: 0px; height: auto; }

.dropup, .dropend, .dropdown, .dropstart, .dropup-center, .dropdown-center =
{ position: relative; }

.dropdown-toggle { white-space: nowrap; }

.dropdown-menu { --bs-dropdown-zindex: 1000; --bs-dropdown-min-width: 10rem=
; --bs-dropdown-padding-x: 0; --bs-dropdown-padding-y: 0; --bs-dropdown-spa=
cer: 0.125rem; --bs-dropdown-font-size: 0.82rem; --bs-dropdown-color: #444;=
 --bs-dropdown-bg: #fff; --bs-dropdown-border-color: var(--bs-border-color-=
translucent); --bs-dropdown-border-radius: 0.25rem; --bs-dropdown-border-wi=
dth: 1px; --bs-dropdown-inner-border-radius: calc(0.25rem - 1px); --bs-drop=
down-divider-bg: var(--bs-border-color-translucent); --bs-dropdown-divider-=
margin-y: 0.5rem; --bs-dropdown-box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1=
5); --bs-dropdown-link-color: #212529; --bs-dropdown-link-hover-color: #1e2=
125; --bs-dropdown-link-hover-bg: #e9ecef; --bs-dropdown-link-active-color:=
 #fff; --bs-dropdown-link-active-bg: #ddd; --bs-dropdown-link-disabled-colo=
r: #adb5bd; --bs-dropdown-item-padding-x: 0; --bs-dropdown-item-padding-y: =
0; --bs-dropdown-header-color: #6c757d; --bs-dropdown-header-padding-x: 0; =
--bs-dropdown-header-padding-y: 0; position: absolute; z-index: var(--bs-dr=
opdown-zindex); display: none; min-width: var(--bs-dropdown-min-width); pad=
ding: var(--bs-dropdown-padding-y) var(--bs-dropdown-padding-x); margin: 0p=
x; font-size: var(--bs-dropdown-font-size); color: var(--bs-dropdown-color)=
; text-align: left; list-style: none; background-color: var(--bs-dropdown-b=
g); background-clip: padding-box; border: var(--bs-dropdown-border-width) s=
olid var(--bs-dropdown-border-color); border-radius: var(--bs-dropdown-bord=
er-radius); box-shadow: var(--bs-dropdown-box-shadow); }

.dropdown-menu[data-bs-popper] { top: 100%; left: 0px; margin-top: var(--bs=
-dropdown-spacer); }

.dropdown-menu > .dropdown-item:first-child, .dropdown-menu > li:first-chil=
d .dropdown-item { border-top-left-radius: var(--bs-dropdown-inner-border-r=
adius); border-top-right-radius: var(--bs-dropdown-inner-border-radius); }

.dropdown-menu > .dropdown-item:last-child, .dropdown-menu > li:last-child =
.dropdown-item { border-bottom-right-radius: var(--bs-dropdown-inner-border=
-radius); border-bottom-left-radius: var(--bs-dropdown-inner-border-radius)=
; }

.dropdown-menu-start { --bs-position: start; }

.dropdown-menu-start[data-bs-popper] { right: auto; left: 0px; }

.dropdown-menu-end { --bs-position: end; }

.dropdown-menu-end[data-bs-popper] { right: 0px; left: auto; }

@media (min-width: 576px) {
  .dropdown-menu-sm-start { --bs-position: start; }
  .dropdown-menu-sm-start[data-bs-popper] { right: auto; left: 0px; }
  .dropdown-menu-sm-end { --bs-position: end; }
  .dropdown-menu-sm-end[data-bs-popper] { right: 0px; left: auto; }
}

@media (min-width: 768px) {
  .dropdown-menu-md-start { --bs-position: start; }
  .dropdown-menu-md-start[data-bs-popper] { right: auto; left: 0px; }
  .dropdown-menu-md-end { --bs-position: end; }
  .dropdown-menu-md-end[data-bs-popper] { right: 0px; left: auto; }
}

@media (min-width: 992px) {
  .dropdown-menu-lg-start { --bs-position: start; }
  .dropdown-menu-lg-start[data-bs-popper] { right: auto; left: 0px; }
  .dropdown-menu-lg-end { --bs-position: end; }
  .dropdown-menu-lg-end[data-bs-popper] { right: 0px; left: auto; }
}

@media (min-width: 1200px) {
  .dropdown-menu-xl-start { --bs-position: start; }
  .dropdown-menu-xl-start[data-bs-popper] { right: auto; left: 0px; }
  .dropdown-menu-xl-end { --bs-position: end; }
  .dropdown-menu-xl-end[data-bs-popper] { right: 0px; left: auto; }
}

@media (min-width: 1400px) {
  .dropdown-menu-xxl-start { --bs-position: start; }
  .dropdown-menu-xxl-start[data-bs-popper] { right: auto; left: 0px; }
  .dropdown-menu-xxl-end { --bs-position: end; }
  .dropdown-menu-xxl-end[data-bs-popper] { right: 0px; left: auto; }
}

.dropup .dropdown-menu[data-bs-popper] { top: auto; bottom: 100%; margin-to=
p: 0px; margin-bottom: var(--bs-dropdown-spacer); }

.dropend .dropdown-menu[data-bs-popper] { top: 0px; right: auto; left: 100%=
; margin-top: 0px; margin-left: var(--bs-dropdown-spacer); }

.dropend .dropdown-toggle::after { vertical-align: 0px; }

.dropstart .dropdown-menu[data-bs-popper] { top: 0px; right: 100%; left: au=
to; margin-top: 0px; margin-right: var(--bs-dropdown-spacer); }

.dropstart .dropdown-toggle::before { vertical-align: 0px; }

.dropdown-divider { height: 0px; margin: var(--bs-dropdown-divider-margin-y=
) 0; overflow: hidden; border-top: 1px solid var(--bs-dropdown-divider-bg);=
 opacity: 1; }

.dropdown-item { display: block; width: 100%; padding: var(--bs-dropdown-it=
em-padding-y) var(--bs-dropdown-item-padding-x); clear: both; font-weight: =
400; color: var(--bs-dropdown-link-color); text-align: inherit; white-space=
: nowrap; background-color: rgba(0, 0, 0, 0); border: 0px; }

.dropdown-item:hover, .dropdown-item:focus { color: var(--bs-dropdown-link-=
hover-color); text-decoration: none; background-color: var(--bs-dropdown-li=
nk-hover-bg); background-image: var(--bs-gradient); }

.dropdown-item.active, .dropdown-item:active { color: var(--bs-dropdown-lin=
k-active-color); text-decoration: none; background-color: var(--bs-dropdown=
-link-active-bg); background-image: var(--bs-gradient); }

.dropdown-item.disabled, .dropdown-item:disabled { color: var(--bs-dropdown=
-link-disabled-color); pointer-events: none; background-color: rgba(0, 0, 0=
, 0); background-image: none; }

.dropdown-menu.show { display: block; }

.dropdown-header { display: block; padding: var(--bs-dropdown-header-paddin=
g-y) var(--bs-dropdown-header-padding-x); margin-bottom: 0px; font-size: 0.=
7175rem; color: var(--bs-dropdown-header-color); white-space: nowrap; }

.dropdown-item-text { display: block; padding: var(--bs-dropdown-item-paddi=
ng-y) var(--bs-dropdown-item-padding-x); color: var(--bs-dropdown-link-colo=
r); }

.dropdown-menu-dark { --bs-dropdown-color: #dee2e6; --bs-dropdown-bg: #343a=
40; --bs-dropdown-border-color: var(--bs-border-color-translucent); --bs-dr=
opdown-box-shadow: ; --bs-dropdown-link-color: #dee2e6; --bs-dropdown-link-=
hover-color: #fff; --bs-dropdown-divider-bg: var(--bs-border-color-transluc=
ent); --bs-dropdown-link-hover-bg: rgba(255, 255, 255, 0.15); --bs-dropdown=
-link-active-color: #fff; --bs-dropdown-link-active-bg: #ddd; --bs-dropdown=
-link-disabled-color: #adb5bd; --bs-dropdown-header-color: #adb5bd; }

.btn-group, .btn-group-vertical { position: relative; display: inline-flex;=
 vertical-align: middle; }

.btn-group > .btn, .btn-group-vertical > .btn { position: relative; flex: 1=
 1 auto; }

.btn-group > .btn-check:checked + .btn, .btn-group > .btn-check:focus + .bt=
n, .btn-group > .btn:hover, .btn-group > .btn:focus, .btn-group > .btn:acti=
ve, .btn-group > .btn.active, .btn-group-vertical > .btn-check:checked + .b=
tn, .btn-group-vertical > .btn-check:focus + .btn, .btn-group-vertical > .b=
tn:hover, .btn-group-vertical > .btn:focus, .btn-group-vertical > .btn:acti=
ve, .btn-group-vertical > .btn.active { z-index: 1; }

.btn-toolbar { display: flex; flex-wrap: wrap; justify-content: flex-start;=
 }

.btn-toolbar .input-group { width: auto; }

.btn-group { border-radius: 0.85rem; }

.btn-group > :not(.btn-check:first-child) + .btn, .btn-group > .btn-group:n=
ot(:first-child) { margin-left: -1px; }

.btn-group > .btn:not(:last-child):not(.dropdown-toggle), .btn-group > .btn=
.dropdown-toggle-split:first-child, .btn-group > .btn-group:not(:last-child=
) > .btn { border-top-right-radius: 0px; border-bottom-right-radius: 0px; }

.btn-group > .btn:nth-child(n+3), .btn-group > :not(.btn-check) + .btn, .bt=
n-group > .btn-group:not(:first-child) > .btn { border-top-left-radius: 0px=
; border-bottom-left-radius: 0px; }

.dropdown-toggle-split { padding-right: 0.5625rem; padding-left: 0.5625rem;=
 }

.dropdown-toggle-split::after, .dropup .dropdown-toggle-split::after, .drop=
end .dropdown-toggle-split::after { margin-left: 0px; }

.dropstart .dropdown-toggle-split::before { margin-right: 0px; }

.btn-sm + .dropdown-toggle-split, .btn-group-sm > .btn + .dropdown-toggle-s=
plit { padding-right: 0.375rem; padding-left: 0.375rem; }

.btn-lg + .dropdown-toggle-split, .btn-group-lg > .btn + .dropdown-toggle-s=
plit { padding-right: 0.75rem; padding-left: 0.75rem; }

.btn-group.show .dropdown-toggle { box-shadow: rgba(0, 0, 0, 0.125) 0px 3px=
 5px inset; }

.btn-group.show .dropdown-toggle.btn-link { box-shadow: none; }

.btn-group-vertical { flex-direction: column; align-items: flex-start; just=
ify-content: center; }

.btn-group-vertical > .btn, .btn-group-vertical > .btn-group { width: 100%;=
 }

.btn-group-vertical > .btn:not(:first-child), .btn-group-vertical > .btn-gr=
oup:not(:first-child) { margin-top: -1px; }

.btn-group-vertical > .btn:not(:last-child):not(.dropdown-toggle), .btn-gro=
up-vertical > .btn-group:not(:last-child) > .btn { border-bottom-right-radi=
us: 0px; border-bottom-left-radius: 0px; }

.btn-group-vertical > .btn ~ .btn, .btn-group-vertical > .btn-group:not(:fi=
rst-child) > .btn { border-top-left-radius: 0px; border-top-right-radius: 0=
px; }

.nav { --bs-nav-link-padding-x: 1rem; --bs-nav-link-padding-y: 0.5rem; --bs=
-nav-link-font-weight: ; --bs-nav-link-color: var(--bs-link-color); --bs-na=
v-link-hover-color: var(--bs-link-hover-color); --bs-nav-link-disabled-colo=
r: #6c757d; display: flex; flex-wrap: wrap; padding-left: 0px; margin-botto=
m: 0px; list-style: none; }

.nav-link { display: block; padding: var(--bs-nav-link-padding-y) var(--bs-=
nav-link-padding-x); font-size: var(--bs-nav-link-font-size); font-weight: =
var(--bs-nav-link-font-weight); color: var(--bs-nav-link-color); }

.nav-link:hover, .nav-link:focus { color: var(--bs-nav-link-hover-color); t=
ext-decoration: none; }

.nav-link.disabled { color: var(--bs-nav-link-disabled-color); pointer-even=
ts: none; cursor: default; }

.nav-tabs { --bs-nav-tabs-border-width: 1px; --bs-nav-tabs-border-color: #a=
aa; --bs-nav-tabs-border-radius: 0.25rem; --bs-nav-tabs-link-hover-border-c=
olor: #d5d5d5 #d5d5d5 #aaa; --bs-nav-tabs-link-active-color: #000; --bs-nav=
-tabs-link-active-bg: #fff; --bs-nav-tabs-link-active-border-color: #aaa #a=
aa #fff; border-bottom: var(--bs-nav-tabs-border-width) solid var(--bs-nav-=
tabs-border-color); }

.nav-tabs .nav-link { margin-bottom: calc(-1*var(--bs-nav-tabs-border-width=
)); background: none; border: var(--bs-nav-tabs-border-width) solid rgba(0,=
0,0,0); border-top-left-radius: var(--bs-nav-tabs-border-radius); border-to=
p-right-radius: var(--bs-nav-tabs-border-radius); }

.nav-tabs .nav-link:hover, .nav-tabs .nav-link:focus { isolation: isolate; =
border-color: var(--bs-nav-tabs-link-hover-border-color); }

.nav-tabs .nav-link.disabled, .nav-tabs .nav-link:disabled { color: var(--b=
s-nav-link-disabled-color); background-color: rgba(0, 0, 0, 0); border-colo=
r: rgba(0, 0, 0, 0); }

.nav-tabs .nav-link.active, .nav-tabs .nav-item.show .nav-link { color: var=
(--bs-nav-tabs-link-active-color); background-color: var(--bs-nav-tabs-link=
-active-bg); border-color: var(--bs-nav-tabs-link-active-border-color); }

.nav-tabs .dropdown-menu { margin-top: calc(-1*var(--bs-nav-tabs-border-wid=
th)); border-top-left-radius: 0px; border-top-right-radius: 0px; }

.nav-pills { --bs-nav-pills-border-radius: 0.25rem; --bs-nav-pills-link-act=
ive-color: #fff; --bs-nav-pills-link-active-bg: #ddd; }

.nav-pills .nav-link { background: none; border: 0px; border-radius: var(--=
bs-nav-pills-border-radius); }

.nav-pills .nav-link:disabled { color: var(--bs-nav-link-disabled-color); b=
ackground-color: rgba(0, 0, 0, 0); border-color: rgba(0, 0, 0, 0); }

.nav-pills .nav-link.active, .nav-pills .show > .nav-link { color: var(--bs=
-nav-pills-link-active-color); background-color: var(--bs-nav-pills-link-ac=
tive-bg); background-image: var(--bs-gradient); }

.nav-fill > .nav-link, .nav-fill .nav-item { flex: 1 1 auto; text-align: ce=
nter; }

.nav-justified > .nav-link, .nav-justified .nav-item { flex-basis: 0px; fle=
x-grow: 1; text-align: center; }

.nav-fill .nav-item .nav-link, .nav-justified .nav-item .nav-link { width: =
100%; }

.tab-content > .tab-pane { display: none; }

.tab-content > .active { display: block; }

.navbar { --bs-navbar-padding-x: 0; --bs-navbar-padding-y: 0; --bs-navbar-c=
olor: #235a81; --bs-navbar-hover-color: #235a81; --bs-navbar-disabled-color=
: #235a81; --bs-navbar-active-color: #235a81; --bs-navbar-brand-padding-y: =
0.34625rem; --bs-navbar-brand-margin-end: 1rem; --bs-navbar-brand-font-size=
: 1.025rem; --bs-navbar-brand-color: #235a81; --bs-navbar-brand-hover-color=
: #235a81; --bs-navbar-nav-link-padding-x: 0.5rem; --bs-navbar-toggler-padd=
ing-y: 0.25rem; --bs-navbar-toggler-padding-x: 0.75rem; --bs-navbar-toggler=
-font-size: 1.025rem; --bs-navbar-toggler-icon-bg: url("data:image/svg+xml,=
%3csvg xmlns=3D'http://www.w3.org/2000/svg' viewBox=3D'0 0 30 30'%3e%3cpath=
 stroke=3D'%23235a81' stroke-linecap=3D'round' stroke-miterlimit=3D'10' str=
oke-width=3D'2' d=3D'M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e"); --bs-navbar-=
toggler-border-color: rgba(0, 0, 0, 0.1); --bs-navbar-toggler-border-radius=
: 0.85rem; --bs-navbar-toggler-focus-width: 0.25rem; --bs-navbar-toggler-tr=
ansition: box-shadow 0.15s ease-in-out; position: relative; display: flex; =
flex-wrap: wrap; align-items: center; justify-content: space-between; paddi=
ng: var(--bs-navbar-padding-y) var(--bs-navbar-padding-x); background-image=
: var(--bs-gradient); }

.navbar > .container, .navbar > .container-fluid, .navbar > .container-sm, =
.navbar > .container-md, .navbar > .container-lg, .navbar > .container-xl, =
.navbar > .container-xxl { display: flex; flex-wrap: inherit; align-items: =
center; justify-content: space-between; }

.navbar-brand { padding-top: var(--bs-navbar-brand-padding-y); padding-bott=
om: var(--bs-navbar-brand-padding-y); margin-right: var(--bs-navbar-brand-m=
argin-end); font-size: var(--bs-navbar-brand-font-size); color: var(--bs-na=
vbar-brand-color); white-space: nowrap; }

.navbar-brand:hover, .navbar-brand:focus { color: var(--bs-navbar-brand-hov=
er-color); text-decoration: none; }

.navbar-nav { --bs-nav-link-padding-x: 0; --bs-nav-link-padding-y: 0.5rem; =
--bs-nav-link-font-weight: ; --bs-nav-link-color: var(--bs-navbar-color); -=
-bs-nav-link-hover-color: var(--bs-navbar-hover-color); --bs-nav-link-disab=
led-color: var(--bs-navbar-disabled-color); display: flex; flex-direction: =
column; padding-left: 0px; margin-bottom: 0px; list-style: none; }

.navbar-nav .show > .nav-link, .navbar-nav .nav-link.active { color: var(--=
bs-navbar-active-color); }

.navbar-nav .dropdown-menu { position: static; }

.navbar-text { padding-top: 0.5rem; padding-bottom: 0.5rem; color: var(--bs=
-navbar-color); }

.navbar-text a, .navbar-text a:hover, .navbar-text a:focus { color: var(--b=
s-navbar-active-color); }

.navbar-collapse { flex-basis: 100%; flex-grow: 1; align-items: center; }

.navbar-toggler { padding: var(--bs-navbar-toggler-padding-y) var(--bs-navb=
ar-toggler-padding-x); font-size: var(--bs-navbar-toggler-font-size); line-=
height: 1; color: var(--bs-navbar-color); background-color: rgba(0, 0, 0, 0=
); border: var(--bs-border-width) solid var(--bs-navbar-toggler-border-colo=
r); border-radius: var(--bs-navbar-toggler-border-radius); }

.navbar-toggler:hover { text-decoration: none; }

.navbar-toggler:focus { text-decoration: none; outline: 0px; box-shadow: 0 =
0 0 var(--bs-navbar-toggler-focus-width); }

.navbar-toggler-icon { display: inline-block; width: 1.5em; height: 1.5em; =
vertical-align: middle; background-image: var(--bs-navbar-toggler-icon-bg);=
 background-repeat: no-repeat; background-position: center center; backgrou=
nd-size: 100%; }

.navbar-nav-scroll { max-height: var(--bs-scroll-height, 75vh); overflow-y:=
 auto; }

@media (min-width: 576px) {
  .navbar-expand-sm { flex-wrap: nowrap; justify-content: flex-start; }
  .navbar-expand-sm .navbar-nav { flex-direction: row; }
  .navbar-expand-sm .navbar-nav .dropdown-menu { position: absolute; }
  .navbar-expand-sm .navbar-nav .nav-link { padding-right: var(--bs-navbar-=
nav-link-padding-x); padding-left: var(--bs-navbar-nav-link-padding-x); }
  .navbar-expand-sm .navbar-nav-scroll { overflow: visible; }
  .navbar-expand-sm .navbar-collapse { display: flex !important; flex-basis=
: auto; }
  .navbar-expand-sm .navbar-toggler { display: none; }
  .navbar-expand-sm .offcanvas { position: static; z-index: auto; flex-grow=
: 1; box-shadow: none; width: auto !important; height: auto !important; vis=
ibility: visible !important; background-color: rgba(0, 0, 0, 0) !important;=
 border: 0px !important; transform: none !important; }
  .navbar-expand-sm .offcanvas .offcanvas-header { display: none; }
  .navbar-expand-sm .offcanvas .offcanvas-body { display: flex; flex-grow: =
0; padding: 0px; overflow-y: visible; }
}

@media (min-width: 768px) {
  .navbar-expand-md { flex-wrap: nowrap; justify-content: flex-start; }
  .navbar-expand-md .navbar-nav { flex-direction: row; }
  .navbar-expand-md .navbar-nav .dropdown-menu { position: absolute; }
  .navbar-expand-md .navbar-nav .nav-link { padding-right: var(--bs-navbar-=
nav-link-padding-x); padding-left: var(--bs-navbar-nav-link-padding-x); }
  .navbar-expand-md .navbar-nav-scroll { overflow: visible; }
  .navbar-expand-md .navbar-collapse { display: flex !important; flex-basis=
: auto; }
  .navbar-expand-md .navbar-toggler { display: none; }
  .navbar-expand-md .offcanvas { position: static; z-index: auto; flex-grow=
: 1; box-shadow: none; width: auto !important; height: auto !important; vis=
ibility: visible !important; background-color: rgba(0, 0, 0, 0) !important;=
 border: 0px !important; transform: none !important; }
  .navbar-expand-md .offcanvas .offcanvas-header { display: none; }
  .navbar-expand-md .offcanvas .offcanvas-body { display: flex; flex-grow: =
0; padding: 0px; overflow-y: visible; }
}

@media (min-width: 992px) {
  .navbar-expand-lg { flex-wrap: nowrap; justify-content: flex-start; }
  .navbar-expand-lg .navbar-nav { flex-direction: row; }
  .navbar-expand-lg .navbar-nav .dropdown-menu { position: absolute; }
  .navbar-expand-lg .navbar-nav .nav-link { padding-right: var(--bs-navbar-=
nav-link-padding-x); padding-left: var(--bs-navbar-nav-link-padding-x); }
  .navbar-expand-lg .navbar-nav-scroll { overflow: visible; }
  .navbar-expand-lg .navbar-collapse { display: flex !important; flex-basis=
: auto; }
  .navbar-expand-lg .navbar-toggler { display: none; }
  .navbar-expand-lg .offcanvas { position: static; z-index: auto; flex-grow=
: 1; box-shadow: none; width: auto !important; height: auto !important; vis=
ibility: visible !important; background-color: rgba(0, 0, 0, 0) !important;=
 border: 0px !important; transform: none !important; }
  .navbar-expand-lg .offcanvas .offcanvas-header { display: none; }
  .navbar-expand-lg .offcanvas .offcanvas-body { display: flex; flex-grow: =
0; padding: 0px; overflow-y: visible; }
}

@media (min-width: 1200px) {
  .navbar-expand-xl { flex-wrap: nowrap; justify-content: flex-start; }
  .navbar-expand-xl .navbar-nav { flex-direction: row; }
  .navbar-expand-xl .navbar-nav .dropdown-menu { position: absolute; }
  .navbar-expand-xl .navbar-nav .nav-link { padding-right: var(--bs-navbar-=
nav-link-padding-x); padding-left: var(--bs-navbar-nav-link-padding-x); }
  .navbar-expand-xl .navbar-nav-scroll { overflow: visible; }
  .navbar-expand-xl .navbar-collapse { display: flex !important; flex-basis=
: auto; }
  .navbar-expand-xl .navbar-toggler { display: none; }
  .navbar-expand-xl .offcanvas { position: static; z-index: auto; flex-grow=
: 1; box-shadow: none; width: auto !important; height: auto !important; vis=
ibility: visible !important; background-color: rgba(0, 0, 0, 0) !important;=
 border: 0px !important; transform: none !important; }
  .navbar-expand-xl .offcanvas .offcanvas-header { display: none; }
  .navbar-expand-xl .offcanvas .offcanvas-body { display: flex; flex-grow: =
0; padding: 0px; overflow-y: visible; }
}

@media (min-width: 1400px) {
  .navbar-expand-xxl { flex-wrap: nowrap; justify-content: flex-start; }
  .navbar-expand-xxl .navbar-nav { flex-direction: row; }
  .navbar-expand-xxl .navbar-nav .dropdown-menu { position: absolute; }
  .navbar-expand-xxl .navbar-nav .nav-link { padding-right: var(--bs-navbar=
-nav-link-padding-x); padding-left: var(--bs-navbar-nav-link-padding-x); }
  .navbar-expand-xxl .navbar-nav-scroll { overflow: visible; }
  .navbar-expand-xxl .navbar-collapse { display: flex !important; flex-basi=
s: auto; }
  .navbar-expand-xxl .navbar-toggler { display: none; }
  .navbar-expand-xxl .offcanvas { position: static; z-index: auto; flex-gro=
w: 1; box-shadow: none; width: auto !important; height: auto !important; vi=
sibility: visible !important; background-color: rgba(0, 0, 0, 0) !important=
; border: 0px !important; transform: none !important; }
  .navbar-expand-xxl .offcanvas .offcanvas-header { display: none; }
  .navbar-expand-xxl .offcanvas .offcanvas-body { display: flex; flex-grow:=
 0; padding: 0px; overflow-y: visible; }
}

.navbar-expand { flex-wrap: nowrap; justify-content: flex-start; }

.navbar-expand .navbar-nav { flex-direction: row; }

.navbar-expand .navbar-nav .dropdown-menu { position: absolute; }

.navbar-expand .navbar-nav .nav-link { padding-right: var(--bs-navbar-nav-l=
ink-padding-x); padding-left: var(--bs-navbar-nav-link-padding-x); }

.navbar-expand .navbar-nav-scroll { overflow: visible; }

.navbar-expand .navbar-collapse { display: flex !important; flex-basis: aut=
o; }

.navbar-expand .navbar-toggler { display: none; }

.navbar-expand .offcanvas { position: static; z-index: auto; flex-grow: 1; =
box-shadow: none; width: auto !important; height: auto !important; visibili=
ty: visible !important; background-color: rgba(0, 0, 0, 0) !important; bord=
er: 0px !important; transform: none !important; }

.navbar-expand .offcanvas .offcanvas-header { display: none; }

.navbar-expand .offcanvas .offcanvas-body { display: flex; flex-grow: 0; pa=
dding: 0px; overflow-y: visible; }

.navbar-dark { --bs-navbar-color: rgba(255, 255, 255, 0.55); --bs-navbar-ho=
ver-color: rgba(255, 255, 255, 0.75); --bs-navbar-disabled-color: rgba(255,=
 255, 255, 0.25); --bs-navbar-active-color: #fff; --bs-navbar-brand-color: =
#fff; --bs-navbar-brand-hover-color: #fff; --bs-navbar-toggler-border-color=
: rgba(255, 255, 255, 0.1); --bs-navbar-toggler-icon-bg: url("data:image/sv=
g+xml,%3csvg xmlns=3D'http://www.w3.org/2000/svg' viewBox=3D'0 0 30 30'%3e%=
3cpath stroke=3D'rgba%28255, 255, 255, 0.55%29' stroke-linecap=3D'round' st=
roke-miterlimit=3D'10' stroke-width=3D'2' d=3D'M4 7h22M4 15h22M4 23h22'/%3e=
%3c/svg%3e"); }

.card { --bs-card-spacer-y: 1rem; --bs-card-spacer-x: 1rem; --bs-card-title=
-spacer-y: 0.5rem; --bs-card-border-width: 1px; --bs-card-border-color: #aa=
a; --bs-card-border-radius: 0.25rem; --bs-card-box-shadow: ; --bs-card-inne=
r-border-radius: calc(0.25rem - 1px); --bs-card-cap-padding-y: 0.5rem; --bs=
-card-cap-padding-x: 1rem; --bs-card-cap-bg: #fff; --bs-card-cap-color: ; -=
-bs-card-height: ; --bs-card-color: ; --bs-card-bg: #eee; --bs-card-img-ove=
rlay-padding: 1rem; --bs-card-group-margin: 0.75rem; position: relative; di=
splay: flex; flex-direction: column; min-width: 0px; height: var(--bs-card-=
height); overflow-wrap: break-word; background-color: var(--bs-card-bg); ba=
ckground-clip: border-box; border: var(--bs-card-border-width) solid var(--=
bs-card-border-color); border-radius: var(--bs-card-border-radius); box-sha=
dow: var(--bs-card-box-shadow); }

.card > hr { margin-right: 0px; margin-left: 0px; }

.card > .list-group { border-top: inherit; border-bottom: inherit; }

.card > .list-group:first-child { border-top-width: 0px; border-top-left-ra=
dius: var(--bs-card-inner-border-radius); border-top-right-radius: var(--bs=
-card-inner-border-radius); }

.card > .list-group:last-child { border-bottom-width: 0px; border-bottom-ri=
ght-radius: var(--bs-card-inner-border-radius); border-bottom-left-radius: =
var(--bs-card-inner-border-radius); }

.card > .card-header + .list-group, .card > .list-group + .card-footer { bo=
rder-top: 0px; }

.card-body { flex: 1 1 auto; padding: var(--bs-card-spacer-y) var(--bs-card=
-spacer-x); color: var(--bs-card-color); }

.card-title { margin-bottom: var(--bs-card-title-spacer-y); }

.card-subtitle { margin-top: calc(-0.5*var(--bs-card-title-spacer-y)); marg=
in-bottom: 0px; }

.card-text:last-child { margin-bottom: 0px; }

.card-link:hover { text-decoration: none; }

.card-link + .card-link { margin-left: var(--bs-card-spacer-x); }

.card-header { padding: var(--bs-card-cap-padding-y) var(--bs-card-cap-padd=
ing-x); margin-bottom: 0px; color: var(--bs-card-cap-color); background-col=
or: var(--bs-card-cap-bg); border-bottom: var(--bs-card-border-width) solid=
 var(--bs-card-border-color); }

.card-header:first-child { border-radius: var(--bs-card-inner-border-radius=
) var(--bs-card-inner-border-radius) 0 0; }

.card-footer { padding: var(--bs-card-cap-padding-y) var(--bs-card-cap-padd=
ing-x); color: var(--bs-card-cap-color); background-color: var(--bs-card-ca=
p-bg); border-top: var(--bs-card-border-width) solid var(--bs-card-border-c=
olor); }

.card-footer:last-child { border-radius: 0 0 var(--bs-card-inner-border-rad=
ius) var(--bs-card-inner-border-radius); }

.card-header-tabs { margin-right: calc(-0.5*var(--bs-card-cap-padding-x)); =
margin-bottom: calc(-1*var(--bs-card-cap-padding-y)); margin-left: calc(-0.=
5*var(--bs-card-cap-padding-x)); border-bottom: 0px; }

.card-header-tabs .nav-link.active { background-color: var(--bs-card-bg); b=
order-bottom-color: var(--bs-card-bg); }

.card-header-pills { margin-right: calc(-0.5*var(--bs-card-cap-padding-x));=
 margin-left: calc(-0.5*var(--bs-card-cap-padding-x)); }

.card-img-overlay { position: absolute; inset: 0px; padding: var(--bs-card-=
img-overlay-padding); border-radius: var(--bs-card-inner-border-radius); }

.card-img, .card-img-top, .card-img-bottom { width: 100%; }

.card-img, .card-img-top { border-top-left-radius: var(--bs-card-inner-bord=
er-radius); border-top-right-radius: var(--bs-card-inner-border-radius); }

.card-img, .card-img-bottom { border-bottom-right-radius: var(--bs-card-inn=
er-border-radius); border-bottom-left-radius: var(--bs-card-inner-border-ra=
dius); }

.card-group > .card { margin-bottom: var(--bs-card-group-margin); }

@media (min-width: 576px) {
  .card-group { display: flex; flex-flow: wrap; }
  .card-group > .card { flex: 1 0 0%; margin-bottom: 0px; }
  .card-group > .card + .card { margin-left: 0px; border-left: 0px; }
  .card-group > .card:not(:last-child) { border-top-right-radius: 0px; bord=
er-bottom-right-radius: 0px; }
  .card-group > .card:not(:last-child) .card-img-top, .card-group > .card:n=
ot(:last-child) .card-header { border-top-right-radius: 0px; }
  .card-group > .card:not(:last-child) .card-img-bottom, .card-group > .car=
d:not(:last-child) .card-footer { border-bottom-right-radius: 0px; }
  .card-group > .card:not(:first-child) { border-top-left-radius: 0px; bord=
er-bottom-left-radius: 0px; }
  .card-group > .card:not(:first-child) .card-img-top, .card-group > .card:=
not(:first-child) .card-header { border-top-left-radius: 0px; }
  .card-group > .card:not(:first-child) .card-img-bottom, .card-group > .ca=
rd:not(:first-child) .card-footer { border-bottom-left-radius: 0px; }
}

.accordion { --bs-accordion-color: #444; --bs-accordion-bg: #fff; --bs-acco=
rdion-transition: color 0.15s ease-in-out, background-color 0.15s ease-in-o=
ut, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, border-ra=
dius 0.15s ease; --bs-accordion-border-color: var(--bs-border-color); --bs-=
accordion-border-width: 1px; --bs-accordion-border-radius: 0.25rem; --bs-ac=
cordion-inner-border-radius: calc(0.25rem - 1px); --bs-accordion-btn-paddin=
g-x: 0.75rem; --bs-accordion-btn-padding-y: 0.375rem; --bs-accordion-btn-co=
lor: #444; --bs-accordion-btn-bg: var(--bs-accordion-bg); --bs-accordion-bt=
n-icon: url("data:image/svg+xml,%3csvg xmlns=3D'http://www.w3.org/2000/svg'=
 viewBox=3D'0 0 16 16' fill=3D'%23444'%3e%3cpath fill-rule=3D'evenodd' d=3D=
'M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6=
 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e"); --bs-accordi=
on-btn-icon-width: 1.25rem; --bs-accordion-btn-icon-transform: rotate(-180d=
eg); --bs-accordion-btn-icon-transition: transform 0.2s ease-in-out; --bs-a=
ccordion-btn-active-icon: url("data:image/svg+xml,%3csvg xmlns=3D'http://ww=
w.w3.org/2000/svg' viewBox=3D'0 0 16 16' fill=3D'%23235a81'%3e%3cpath fill-=
rule=3D'evenodd' d=3D'M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.=
5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/s=
vg%3e"); --bs-accordion-btn-focus-border-color: #eeeeee; --bs-accordion-btn=
-focus-box-shadow: 0 0 0 0.25rem rgba(221, 221, 221, 0.25); --bs-accordion-=
body-padding-x: 1.25rem; --bs-accordion-body-padding-y: 1rem; --bs-accordio=
n-active-color: #235a81; --bs-accordion-active-bg: #f3f3f3; }

.accordion-button { position: relative; display: flex; align-items: center;=
 width: 100%; padding: var(--bs-accordion-btn-padding-y) var(--bs-accordion=
-btn-padding-x); font-size: 0.82rem; color: var(--bs-accordion-btn-color); =
text-align: left; background-color: var(--bs-accordion-btn-bg); border: 0px=
; border-radius: 0px; overflow-anchor: none; }

.accordion-button:not(.collapsed) { color: var(--bs-accordion-active-color)=
; background-color: var(--bs-accordion-active-bg); box-shadow: inset 0 calc=
(-1*var(--bs-accordion-border-width)) 0 var(--bs-accordion-border-color); }

.accordion-button:not(.collapsed)::after { background-image: var(--bs-accor=
dion-btn-active-icon); transform: var(--bs-accordion-btn-icon-transform); }

.accordion-button::after { flex-shrink: 0; width: var(--bs-accordion-btn-ic=
on-width); height: var(--bs-accordion-btn-icon-width); margin-left: auto; c=
ontent: ""; background-image: var(--bs-accordion-btn-icon); background-repe=
at: no-repeat; background-size: var(--bs-accordion-btn-icon-width); }

.accordion-button:hover { z-index: 2; }

.accordion-button:focus { z-index: 3; border-color: var(--bs-accordion-btn-=
focus-border-color); outline: 0px; box-shadow: var(--bs-accordion-btn-focus=
-box-shadow); }

.accordion-header { margin-bottom: 0px; }

.accordion-item { color: var(--bs-accordion-color); background-color: var(-=
-bs-accordion-bg); border: var(--bs-accordion-border-width) solid var(--bs-=
accordion-border-color); }

.accordion-item:first-of-type { border-top-left-radius: var(--bs-accordion-=
border-radius); border-top-right-radius: var(--bs-accordion-border-radius);=
 }

.accordion-item:first-of-type .accordion-button { border-top-left-radius: v=
ar(--bs-accordion-inner-border-radius); border-top-right-radius: var(--bs-a=
ccordion-inner-border-radius); }

.accordion-item:not(:first-of-type) { border-top: 0px; }

.accordion-item:last-of-type { border-bottom-right-radius: var(--bs-accordi=
on-border-radius); border-bottom-left-radius: var(--bs-accordion-border-rad=
ius); }

.accordion-item:last-of-type .accordion-button.collapsed { border-bottom-ri=
ght-radius: var(--bs-accordion-inner-border-radius); border-bottom-left-rad=
ius: var(--bs-accordion-inner-border-radius); }

.accordion-item:last-of-type .accordion-collapse { border-bottom-right-radi=
us: var(--bs-accordion-border-radius); border-bottom-left-radius: var(--bs-=
accordion-border-radius); }

.accordion-body { padding: var(--bs-accordion-body-padding-y) var(--bs-acco=
rdion-body-padding-x); }

.accordion-flush .accordion-collapse { border-width: 0px; }

.accordion-flush .accordion-item { border-right: 0px; border-left: 0px; bor=
der-radius: 0px; }

.accordion-flush .accordion-item:first-child { border-top: 0px; }

.accordion-flush .accordion-item:last-child { border-bottom: 0px; }

.accordion-flush .accordion-item .accordion-button, .accordion-flush .accor=
dion-item .accordion-button.collapsed { border-radius: 0px; }

.breadcrumb { --bs-breadcrumb-padding-x: 0; --bs-breadcrumb-padding-y: 0; -=
-bs-breadcrumb-margin-bottom: 1rem; --bs-breadcrumb-bg: ; --bs-breadcrumb-b=
order-radius: ; --bs-breadcrumb-divider-color: #fff; --bs-breadcrumb-item-p=
adding-x: 0.5rem; --bs-breadcrumb-item-active-color: #6c757d; display: flex=
; flex-wrap: wrap; padding: var(--bs-breadcrumb-padding-y) var(--bs-breadcr=
umb-padding-x); margin-bottom: var(--bs-breadcrumb-margin-bottom); font-siz=
e: var(--bs-breadcrumb-font-size); list-style: none; background-color: var(=
--bs-breadcrumb-bg); border-radius: var(--bs-breadcrumb-border-radius); }

.breadcrumb-item + .breadcrumb-item { padding-left: var(--bs-breadcrumb-ite=
m-padding-x); }

.breadcrumb-item + .breadcrumb-item::before { float: left; padding-right: v=
ar(--bs-breadcrumb-item-padding-x); color: var(--bs-breadcrumb-divider-colo=
r); content: var(--bs-breadcrumb-divider, "=C2=BB"); }

.breadcrumb-item.active { color: var(--bs-breadcrumb-item-active-color); }

.pagination { --bs-pagination-padding-x: 0.75rem; --bs-pagination-padding-y=
: 0.375rem; --bs-pagination-font-size: 0.82rem; --bs-pagination-color: var(=
--bs-link-color); --bs-pagination-bg: #fff; --bs-pagination-border-width: 1=
px; --bs-pagination-border-color: #aaa; --bs-pagination-border-radius: 0.25=
rem; --bs-pagination-hover-color: var(--bs-link-hover-color); --bs-paginati=
on-hover-bg: #e9ecef; --bs-pagination-hover-border-color: #aaa; --bs-pagina=
tion-focus-color: var(--bs-link-hover-color); --bs-pagination-focus-bg: #e9=
ecef; --bs-pagination-focus-box-shadow: 0 0 0 0.25rem rgba(221, 221, 221, 0=
.25); --bs-pagination-active-color: #235a81; --bs-pagination-active-bg: #dd=
d; --bs-pagination-active-border-color: #aaa; --bs-pagination-disabled-colo=
r: #6c757d; --bs-pagination-disabled-bg: #fff; --bs-pagination-disabled-bor=
der-color: #aaa; display: flex; padding-left: 0px; list-style: none; }

.page-link { position: relative; display: block; padding: var(--bs-paginati=
on-padding-y) var(--bs-pagination-padding-x); font-size: var(--bs-paginatio=
n-font-size); color: var(--bs-pagination-color); background-color: var(--bs=
-pagination-bg); border: var(--bs-pagination-border-width) solid var(--bs-p=
agination-border-color); }

.page-link:hover { z-index: 2; color: var(--bs-pagination-hover-color); tex=
t-decoration: none; background-color: var(--bs-pagination-hover-bg); border=
-color: var(--bs-pagination-hover-border-color); }

.page-link:focus { z-index: 3; color: var(--bs-pagination-focus-color); bac=
kground-color: var(--bs-pagination-focus-bg); outline: 0px; box-shadow: var=
(--bs-pagination-focus-box-shadow); }

.page-link.active, .active > .page-link { z-index: 3; color: var(--bs-pagin=
ation-active-color); background-color: var(--bs-pagination-active-bg); back=
ground-image: var(--bs-gradient); border-color: var(--bs-pagination-active-=
border-color); }

.page-link.disabled, .disabled > .page-link { color: var(--bs-pagination-di=
sabled-color); pointer-events: none; background-color: var(--bs-pagination-=
disabled-bg); border-color: var(--bs-pagination-disabled-border-color); }

.page-item:not(:first-child) .page-link { margin-left: -1px; }

.page-item:first-child .page-link { border-top-left-radius: var(--bs-pagina=
tion-border-radius); border-bottom-left-radius: var(--bs-pagination-border-=
radius); }

.page-item:last-child .page-link { border-top-right-radius: var(--bs-pagina=
tion-border-radius); border-bottom-right-radius: var(--bs-pagination-border=
-radius); }

.pagination-lg { --bs-pagination-padding-x: 1.5rem; --bs-pagination-padding=
-y: 0.75rem; --bs-pagination-font-size: 1.025rem; --bs-pagination-border-ra=
dius: 0.5rem; }

.pagination-sm { --bs-pagination-padding-x: 0.5rem; --bs-pagination-padding=
-y: 0.25rem; --bs-pagination-font-size: 0.7175rem; --bs-pagination-border-r=
adius: 0.25rem; }

.badge { --bs-badge-padding-x: 0.65em; --bs-badge-padding-y: 0.35em; --bs-b=
adge-font-size: 0.75em; --bs-badge-font-weight: 700; --bs-badge-color: #fff=
; --bs-badge-border-radius: 0.25rem; display: inline-block; padding: var(--=
bs-badge-padding-y) var(--bs-badge-padding-x); font-size: var(--bs-badge-fo=
nt-size); font-weight: var(--bs-badge-font-weight); line-height: 1; color: =
var(--bs-badge-color); text-align: center; white-space: nowrap; vertical-al=
ign: baseline; border-radius: var(--bs-badge-border-radius); background-ima=
ge: var(--bs-gradient); }

.badge:empty { display: none; }

.btn .badge { position: relative; top: -1px; }

.alert { --bs-alert-bg: transparent; --bs-alert-padding-x: 1rem; --bs-alert=
-padding-y: 1rem; --bs-alert-margin-bottom: 0.5em; --bs-alert-color: inheri=
t; --bs-alert-border-color: transparent; --bs-alert-border: 1px solid var(-=
-bs-alert-border-color); --bs-alert-border-radius: 5px; position: relative;=
 padding: var(--bs-alert-padding-y) var(--bs-alert-padding-x); margin-botto=
m: var(--bs-alert-margin-bottom); color: var(--bs-alert-color); background-=
color: var(--bs-alert-bg); border: var(--bs-alert-border); border-radius: v=
ar(--bs-alert-border-radius); }

.alert-heading { color: inherit; }

.alert-link { font-weight: 700; }

.alert-dismissible { padding-right: 3rem; }

.alert-dismissible .btn-close { position: absolute; top: 0px; right: 0px; z=
-index: 2; padding: 1.25rem 1rem; }

.alert-primary { --bs-alert-color: #585858; --bs-alert-bg: #f8f8f8; --bs-al=
ert-border-color: whitesmoke; background-image: var(--bs-gradient); }

.alert-primary .alert-link { color: rgb(70, 70, 70); }

.alert-secondary { --bs-alert-color: #585858; --bs-alert-bg: #f8f8f8; --bs-=
alert-border-color: whitesmoke; background-image: var(--bs-gradient); }

.alert-secondary .alert-link { color: rgb(70, 70, 70); }

.alert-success { --bs-alert-color: #0f5132; --bs-alert-bg: #d1e7dd; --bs-al=
ert-border-color: #badbcc; background-image: var(--bs-gradient); }

.alert-success .alert-link { color: rgb(12, 65, 40); }

.alert-info { --bs-alert-color: #055160; --bs-alert-bg: #cff4fc; --bs-alert=
-border-color: #b6effb; background-image: var(--bs-gradient); }

.alert-info .alert-link { color: rgb(4, 65, 77); }

.alert-warning { --bs-alert-color: #664d03; --bs-alert-bg: #fff3cd; --bs-al=
ert-border-color: #ffecb5; background-image: var(--bs-gradient); }

.alert-warning .alert-link { color: rgb(82, 62, 2); }

.alert-danger { --bs-alert-color: #842029; --bs-alert-bg: #f8d7da; --bs-ale=
rt-border-color: #f5c2c7; background-image: var(--bs-gradient); }

.alert-danger .alert-link { color: rgb(106, 26, 33); }

.alert-light { --bs-alert-color: #636464; --bs-alert-bg: #fefefe; --bs-aler=
t-border-color: #fdfdfe; background-image: var(--bs-gradient); }

.alert-light .alert-link { color: rgb(79, 80, 80); }

.alert-dark { --bs-alert-color: #141619; --bs-alert-bg: #d3d3d4; --bs-alert=
-border-color: #bcbebf; background-image: var(--bs-gradient); }

.alert-dark .alert-link { color: rgb(16, 18, 20); }

.list-group { --bs-list-group-color: #212529; --bs-list-group-bg: inherit; =
--bs-list-group-border-color: rgba(0, 0, 0, 0.125); --bs-list-group-border-=
width: 1px; --bs-list-group-border-radius: 0.25rem; --bs-list-group-item-pa=
dding-x: 0.75rem; --bs-list-group-item-padding-y: 0.375rem; --bs-list-group=
-action-color: #495057; --bs-list-group-action-hover-color: #495057; --bs-l=
ist-group-action-hover-bg: #f8f9fa; --bs-list-group-action-active-color: #4=
44; --bs-list-group-action-active-bg: #e9ecef; --bs-list-group-disabled-col=
or: #6c757d; --bs-list-group-disabled-bg: inherit; --bs-list-group-active-c=
olor: #fff; --bs-list-group-active-bg: #ddd; --bs-list-group-active-border-=
color: #ddd; display: flex; flex-direction: column; padding-left: 0px; marg=
in-bottom: 0px; border-radius: var(--bs-list-group-border-radius); }

.list-group-numbered { list-style-type: none; counter-reset: section 0; }

.list-group-numbered > .list-group-item::before { content: counters(section=
, ".") ". "; counter-increment: section 1; }

.list-group-item-action { width: 100%; color: var(--bs-list-group-action-co=
lor); text-align: inherit; }

.list-group-item-action:hover, .list-group-item-action:focus { z-index: 1; =
color: var(--bs-list-group-action-hover-color); text-decoration: none; back=
ground-color: var(--bs-list-group-action-hover-bg); }

.list-group-item-action:active { color: var(--bs-list-group-action-active-c=
olor); background-color: var(--bs-list-group-action-active-bg); }

.list-group-item { position: relative; display: block; padding: var(--bs-li=
st-group-item-padding-y) var(--bs-list-group-item-padding-x); color: var(--=
bs-list-group-color); background-color: var(--bs-list-group-bg); border: va=
r(--bs-list-group-border-width) solid var(--bs-list-group-border-color); }

.list-group-item:first-child { border-top-left-radius: inherit; border-top-=
right-radius: inherit; }

.list-group-item:last-child { border-bottom-right-radius: inherit; border-b=
ottom-left-radius: inherit; }

.list-group-item.disabled, .list-group-item:disabled { color: var(--bs-list=
-group-disabled-color); pointer-events: none; background-color: var(--bs-li=
st-group-disabled-bg); }

.list-group-item.active { z-index: 2; color: var(--bs-list-group-active-col=
or); background-color: var(--bs-list-group-active-bg); border-color: var(--=
bs-list-group-active-border-color); }

.list-group-item + .list-group-item { border-top-width: 0px; }

.list-group-item + .list-group-item.active { margin-top: calc(-1*var(--bs-l=
ist-group-border-width)); border-top-width: var(--bs-list-group-border-widt=
h); }

.list-group-horizontal { flex-direction: row; }

.list-group-horizontal > .list-group-item:first-child:not(:last-child) { bo=
rder-bottom-left-radius: var(--bs-list-group-border-radius); border-top-rig=
ht-radius: 0px; }

.list-group-horizontal > .list-group-item:last-child:not(:first-child) { bo=
rder-top-right-radius: var(--bs-list-group-border-radius); border-bottom-le=
ft-radius: 0px; }

.list-group-horizontal > .list-group-item.active { margin-top: 0px; }

.list-group-horizontal > .list-group-item + .list-group-item { border-top-w=
idth: var(--bs-list-group-border-width); border-left-width: 0px; }

.list-group-horizontal > .list-group-item + .list-group-item.active { margi=
n-left: calc(-1*var(--bs-list-group-border-width)); border-left-width: var(=
--bs-list-group-border-width); }

@media (min-width: 576px) {
  .list-group-horizontal-sm { flex-direction: row; }
  .list-group-horizontal-sm > .list-group-item:first-child:not(:last-child)=
 { border-bottom-left-radius: var(--bs-list-group-border-radius); border-to=
p-right-radius: 0px; }
  .list-group-horizontal-sm > .list-group-item:last-child:not(:first-child)=
 { border-top-right-radius: var(--bs-list-group-border-radius); border-bott=
om-left-radius: 0px; }
  .list-group-horizontal-sm > .list-group-item.active { margin-top: 0px; }
  .list-group-horizontal-sm > .list-group-item + .list-group-item { border-=
top-width: var(--bs-list-group-border-width); border-left-width: 0px; }
  .list-group-horizontal-sm > .list-group-item + .list-group-item.active { =
margin-left: calc(-1*var(--bs-list-group-border-width)); border-left-width:=
 var(--bs-list-group-border-width); }
}

@media (min-width: 768px) {
  .list-group-horizontal-md { flex-direction: row; }
  .list-group-horizontal-md > .list-group-item:first-child:not(:last-child)=
 { border-bottom-left-radius: var(--bs-list-group-border-radius); border-to=
p-right-radius: 0px; }
  .list-group-horizontal-md > .list-group-item:last-child:not(:first-child)=
 { border-top-right-radius: var(--bs-list-group-border-radius); border-bott=
om-left-radius: 0px; }
  .list-group-horizontal-md > .list-group-item.active { margin-top: 0px; }
  .list-group-horizontal-md > .list-group-item + .list-group-item { border-=
top-width: var(--bs-list-group-border-width); border-left-width: 0px; }
  .list-group-horizontal-md > .list-group-item + .list-group-item.active { =
margin-left: calc(-1*var(--bs-list-group-border-width)); border-left-width:=
 var(--bs-list-group-border-width); }
}

@media (min-width: 992px) {
  .list-group-horizontal-lg { flex-direction: row; }
  .list-group-horizontal-lg > .list-group-item:first-child:not(:last-child)=
 { border-bottom-left-radius: var(--bs-list-group-border-radius); border-to=
p-right-radius: 0px; }
  .list-group-horizontal-lg > .list-group-item:last-child:not(:first-child)=
 { border-top-right-radius: var(--bs-list-group-border-radius); border-bott=
om-left-radius: 0px; }
  .list-group-horizontal-lg > .list-group-item.active { margin-top: 0px; }
  .list-group-horizontal-lg > .list-group-item + .list-group-item { border-=
top-width: var(--bs-list-group-border-width); border-left-width: 0px; }
  .list-group-horizontal-lg > .list-group-item + .list-group-item.active { =
margin-left: calc(-1*var(--bs-list-group-border-width)); border-left-width:=
 var(--bs-list-group-border-width); }
}

@media (min-width: 1200px) {
  .list-group-horizontal-xl { flex-direction: row; }
  .list-group-horizontal-xl > .list-group-item:first-child:not(:last-child)=
 { border-bottom-left-radius: var(--bs-list-group-border-radius); border-to=
p-right-radius: 0px; }
  .list-group-horizontal-xl > .list-group-item:last-child:not(:first-child)=
 { border-top-right-radius: var(--bs-list-group-border-radius); border-bott=
om-left-radius: 0px; }
  .list-group-horizontal-xl > .list-group-item.active { margin-top: 0px; }
  .list-group-horizontal-xl > .list-group-item + .list-group-item { border-=
top-width: var(--bs-list-group-border-width); border-left-width: 0px; }
  .list-group-horizontal-xl > .list-group-item + .list-group-item.active { =
margin-left: calc(-1*var(--bs-list-group-border-width)); border-left-width:=
 var(--bs-list-group-border-width); }
}

@media (min-width: 1400px) {
  .list-group-horizontal-xxl { flex-direction: row; }
  .list-group-horizontal-xxl > .list-group-item:first-child:not(:last-child=
) { border-bottom-left-radius: var(--bs-list-group-border-radius); border-t=
op-right-radius: 0px; }
  .list-group-horizontal-xxl > .list-group-item:last-child:not(:first-child=
) { border-top-right-radius: var(--bs-list-group-border-radius); border-bot=
tom-left-radius: 0px; }
  .list-group-horizontal-xxl > .list-group-item.active { margin-top: 0px; }
  .list-group-horizontal-xxl > .list-group-item + .list-group-item { border=
-top-width: var(--bs-list-group-border-width); border-left-width: 0px; }
  .list-group-horizontal-xxl > .list-group-item + .list-group-item.active {=
 margin-left: calc(-1*var(--bs-list-group-border-width)); border-left-width=
: var(--bs-list-group-border-width); }
}

.list-group-flush { border-radius: 0px; }

.list-group-flush > .list-group-item { border-width: 0 0 var(--bs-list-grou=
p-border-width); }

.list-group-flush > .list-group-item:last-child { border-bottom-width: 0px;=
 }

.list-group-item-primary { color: rgb(88, 88, 88); background-color: rgb(24=
8, 248, 248); }

.list-group-item-primary.list-group-item-action:hover, .list-group-item-pri=
mary.list-group-item-action:focus { color: rgb(88, 88, 88); background-colo=
r: rgb(223, 223, 223); }

.list-group-item-primary.list-group-item-action.active { color: rgb(255, 25=
5, 255); background-color: rgb(88, 88, 88); border-color: rgb(88, 88, 88); =
}

.list-group-item-secondary { color: rgb(88, 88, 88); background-color: rgb(=
248, 248, 248); }

.list-group-item-secondary.list-group-item-action:hover, .list-group-item-s=
econdary.list-group-item-action:focus { color: rgb(88, 88, 88); background-=
color: rgb(223, 223, 223); }

.list-group-item-secondary.list-group-item-action.active { color: rgb(255, =
255, 255); background-color: rgb(88, 88, 88); border-color: rgb(88, 88, 88)=
; }

.list-group-item-success { color: rgb(15, 81, 50); background-color: rgb(20=
9, 231, 221); }

.list-group-item-success.list-group-item-action:hover, .list-group-item-suc=
cess.list-group-item-action:focus { color: rgb(15, 81, 50); background-colo=
r: rgb(188, 208, 199); }

.list-group-item-success.list-group-item-action.active { color: rgb(255, 25=
5, 255); background-color: rgb(15, 81, 50); border-color: rgb(15, 81, 50); =
}

.list-group-item-info { color: rgb(5, 81, 96); background-color: rgb(207, 2=
44, 252); }

.list-group-item-info.list-group-item-action:hover, .list-group-item-info.l=
ist-group-item-action:focus { color: rgb(5, 81, 96); background-color: rgb(=
186, 220, 227); }

.list-group-item-info.list-group-item-action.active { color: rgb(255, 255, =
255); background-color: rgb(5, 81, 96); border-color: rgb(5, 81, 96); }

.list-group-item-warning { color: rgb(102, 77, 3); background-color: rgb(25=
5, 243, 205); }

.list-group-item-warning.list-group-item-action:hover, .list-group-item-war=
ning.list-group-item-action:focus { color: rgb(102, 77, 3); background-colo=
r: rgb(230, 219, 185); }

.list-group-item-warning.list-group-item-action.active { color: rgb(255, 25=
5, 255); background-color: rgb(102, 77, 3); border-color: rgb(102, 77, 3); =
}

.list-group-item-danger { color: rgb(132, 32, 41); background-color: rgb(24=
8, 215, 218); }

.list-group-item-danger.list-group-item-action:hover, .list-group-item-dang=
er.list-group-item-action:focus { color: rgb(132, 32, 41); background-color=
: rgb(223, 194, 196); }

.list-group-item-danger.list-group-item-action.active { color: rgb(255, 255=
, 255); background-color: rgb(132, 32, 41); border-color: rgb(132, 32, 41);=
 }

.list-group-item-light { color: rgb(99, 100, 100); background-color: rgb(25=
4, 254, 254); }

.list-group-item-light.list-group-item-action:hover, .list-group-item-light=
.list-group-item-action:focus { color: rgb(99, 100, 100); background-color:=
 rgb(229, 229, 229); }

.list-group-item-light.list-group-item-action.active { color: rgb(255, 255,=
 255); background-color: rgb(99, 100, 100); border-color: rgb(99, 100, 100)=
; }

.list-group-item-dark { color: rgb(20, 22, 25); background-color: rgb(211, =
211, 212); }

.list-group-item-dark.list-group-item-action:hover, .list-group-item-dark.l=
ist-group-item-action:focus { color: rgb(20, 22, 25); background-color: rgb=
(190, 190, 191); }

.list-group-item-dark.list-group-item-action.active { color: rgb(255, 255, =
255); background-color: rgb(20, 22, 25); border-color: rgb(20, 22, 25); }

.btn-close { box-sizing: content-box; width: 1em; height: 1em; padding: 0.2=
5em; color: rgb(0, 0, 0); background: url("data:image/svg+xml,%3csvg xmlns=
=3D'http://www.w3.org/2000/svg' viewBox=3D'0 0 16 16' fill=3D'%23000'%3e%3c=
path d=3D'M.293.293a1 1 0 0 1 1.414 0L8 6.586 14.293.293a1 1 0 1 1 1.414 1.=
414L9.414 8l6.293 6.293a1 1 0 0 1-1.414 1.414L8 9.414l-6.293 6.293a1 1 0 0 =
1-1.414-1.414L6.586 8 .293 1.707a1 1 0 0 1 0-1.414z'/%3e%3c/svg%3e") center=
 center / 1em no-repeat rgba(0, 0, 0, 0); border: 0px; border-radius: 0.25r=
em; opacity: 0.5; }

.btn-close:hover { color: rgb(0, 0, 0); text-decoration: none; opacity: 0.7=
5; }

.btn-close:focus { outline: 0px; box-shadow: rgba(221, 221, 221, 0.25) 0px =
0px 0px 0.25rem; opacity: 1; }

.btn-close:disabled, .btn-close.disabled { pointer-events: none; user-selec=
t: none; opacity: 0.25; }

.btn-close-white { filter: invert(1) grayscale(100%) brightness(200%); }

.modal { --bs-modal-zindex: 1055; --bs-modal-width: 500px; --bs-modal-paddi=
ng: 0.75rem; --bs-modal-margin: 0.5rem; --bs-modal-color: ; --bs-modal-bg: =
#fff; --bs-modal-border-color: var(--bs-border-color-translucent); --bs-mod=
al-border-width: 1px; --bs-modal-border-radius: 0.5rem; --bs-modal-box-shad=
ow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075); --bs-modal-inner-border-radius=
: calc(0.5rem - 1px); --bs-modal-header-padding-x: 0.75rem; --bs-modal-head=
er-padding-y: 0.4rem; --bs-modal-header-padding: 0.4rem 0.75rem; --bs-modal=
-header-border-color: var(--bs-border-color); --bs-modal-header-border-widt=
h: 1px; --bs-modal-title-line-height: 1.5; --bs-modal-footer-gap: 0.1rem; -=
-bs-modal-footer-bg: ; --bs-modal-footer-border-color: var(--bs-border-colo=
r); --bs-modal-footer-border-width: 1px; position: fixed; top: 0px; left: 0=
px; z-index: var(--bs-modal-zindex); display: none; width: 100%; height: 10=
0%; overflow: hidden auto; outline: 0px; }

.modal-dialog { position: relative; width: auto; margin: var(--bs-modal-mar=
gin); pointer-events: none; }

.modal.fade .modal-dialog { transform: translate(0px, -50px); }

.modal.show .modal-dialog { transform: none; }

.modal.modal-static .modal-dialog { transform: scale(1.02); }

.modal-dialog-scrollable { height: calc(100% - var(--bs-modal-margin)*2); }

.modal-dialog-scrollable .modal-content { max-height: 100%; overflow: hidde=
n; }

.modal-dialog-scrollable .modal-body { overflow-y: auto; }

.modal-dialog-centered { display: flex; align-items: center; min-height: ca=
lc(100% - var(--bs-modal-margin)*2); }

.modal-content { position: relative; display: flex; flex-direction: column;=
 width: 100%; color: var(--bs-modal-color); pointer-events: auto; backgroun=
d-color: var(--bs-modal-bg); background-clip: padding-box; border: var(--bs=
-modal-border-width) solid var(--bs-modal-border-color); border-radius: var=
(--bs-modal-border-radius); box-shadow: var(--bs-modal-box-shadow); outline=
: 0px; }

.modal-backdrop { --bs-backdrop-zindex: 1050; --bs-backdrop-bg: #000; --bs-=
backdrop-opacity: 0.5; position: fixed; top: 0px; left: 0px; z-index: var(-=
-bs-backdrop-zindex); width: 100vw; height: 100vh; background-color: var(--=
bs-backdrop-bg); }

.modal-backdrop.fade { opacity: 0; }

.modal-backdrop.show { opacity: var(--bs-backdrop-opacity); }

.modal-header { display: flex; flex-shrink: 0; align-items: center; justify=
-content: space-between; padding: var(--bs-modal-header-padding); border-bo=
ttom: var(--bs-modal-header-border-width) solid var(--bs-modal-header-borde=
r-color); border-top-left-radius: var(--bs-modal-inner-border-radius); bord=
er-top-right-radius: var(--bs-modal-inner-border-radius); }

.modal-header .btn-close { padding: calc(var(--bs-modal-header-padding-y)*.=
5) calc(var(--bs-modal-header-padding-x)*.5); margin: calc(-0.5*var(--bs-mo=
dal-header-padding-y)) calc(-0.5*var(--bs-modal-header-padding-x)) calc(-0.=
5*var(--bs-modal-header-padding-y)) auto; }

.modal-title { margin-bottom: 0px; line-height: var(--bs-modal-title-line-h=
eight); }

.modal-body { position: relative; flex: 1 1 auto; padding: var(--bs-modal-p=
adding); }

.modal-footer { display: flex; flex-shrink: 0; flex-wrap: wrap; align-items=
: center; justify-content: flex-end; padding: calc(var(--bs-modal-padding) =
- var(--bs-modal-footer-gap)*.5); background-color: var(--bs-modal-footer-b=
g); border-top: var(--bs-modal-footer-border-width) solid var(--bs-modal-fo=
oter-border-color); border-bottom-right-radius: var(--bs-modal-inner-border=
-radius); border-bottom-left-radius: var(--bs-modal-inner-border-radius); }

.modal-footer > * { margin: calc(var(--bs-modal-footer-gap)*.5); }

@media (min-width: 576px) {
  .modal { --bs-modal-margin: 1.75rem; --bs-modal-box-shadow: 0 0.5rem 1rem=
 rgba(0, 0, 0, 0.15); }
  .modal-dialog { max-width: var(--bs-modal-width); margin-right: auto; mar=
gin-left: auto; }
  .modal-sm { --bs-modal-width: 300px; }
}

@media (min-width: 992px) {
  .modal-lg, .modal-xl { --bs-modal-width: 800px; }
}

@media (min-width: 1200px) {
  .modal-xl { --bs-modal-width: 1140px; }
}

.modal-fullscreen { width: 100vw; max-width: none; height: 100%; margin: 0p=
x; }

.modal-fullscreen .modal-content { height: 100%; border: 0px; border-radius=
: 0px; }

.modal-fullscreen .modal-header, .modal-fullscreen .modal-footer { border-r=
adius: 0px; }

.modal-fullscreen .modal-body { overflow-y: auto; }

@media (max-width: 575.98px) {
  .modal-fullscreen-sm-down { width: 100vw; max-width: none; height: 100%; =
margin: 0px; }
  .modal-fullscreen-sm-down .modal-content { height: 100%; border: 0px; bor=
der-radius: 0px; }
  .modal-fullscreen-sm-down .modal-header, .modal-fullscreen-sm-down .modal=
-footer { border-radius: 0px; }
  .modal-fullscreen-sm-down .modal-body { overflow-y: auto; }
}

@media (max-width: 767.98px) {
  .modal-fullscreen-md-down { width: 100vw; max-width: none; height: 100%; =
margin: 0px; }
  .modal-fullscreen-md-down .modal-content { height: 100%; border: 0px; bor=
der-radius: 0px; }
  .modal-fullscreen-md-down .modal-header, .modal-fullscreen-md-down .modal=
-footer { border-radius: 0px; }
  .modal-fullscreen-md-down .modal-body { overflow-y: auto; }
}

@media (max-width: 991.98px) {
  .modal-fullscreen-lg-down { width: 100vw; max-width: none; height: 100%; =
margin: 0px; }
  .modal-fullscreen-lg-down .modal-content { height: 100%; border: 0px; bor=
der-radius: 0px; }
  .modal-fullscreen-lg-down .modal-header, .modal-fullscreen-lg-down .modal=
-footer { border-radius: 0px; }
  .modal-fullscreen-lg-down .modal-body { overflow-y: auto; }
}

@media (max-width: 1199.98px) {
  .modal-fullscreen-xl-down { width: 100vw; max-width: none; height: 100%; =
margin: 0px; }
  .modal-fullscreen-xl-down .modal-content { height: 100%; border: 0px; bor=
der-radius: 0px; }
  .modal-fullscreen-xl-down .modal-header, .modal-fullscreen-xl-down .modal=
-footer { border-radius: 0px; }
  .modal-fullscreen-xl-down .modal-body { overflow-y: auto; }
}

@media (max-width: 1399.98px) {
  .modal-fullscreen-xxl-down { width: 100vw; max-width: none; height: 100%;=
 margin: 0px; }
  .modal-fullscreen-xxl-down .modal-content { height: 100%; border: 0px; bo=
rder-radius: 0px; }
  .modal-fullscreen-xxl-down .modal-header, .modal-fullscreen-xxl-down .mod=
al-footer { border-radius: 0px; }
  .modal-fullscreen-xxl-down .modal-body { overflow-y: auto; }
}

.spinner-grow, .spinner-border { display: inline-block; width: var(--bs-spi=
nner-width); height: var(--bs-spinner-height); vertical-align: var(--bs-spi=
nner-vertical-align); border-radius: 50%; animation: var(--bs-spinner-anima=
tion-speed) linear infinite var(--bs-spinner-animation-name); }

@keyframes spinner-border {=20
  100% { transform: rotate(360deg); }
}

.spinner-border { --bs-spinner-width: 2rem; --bs-spinner-height: 2rem; --bs=
-spinner-vertical-align: -0.125em; --bs-spinner-border-width: 0.25em; --bs-=
spinner-animation-speed: 0.75s; --bs-spinner-animation-name: spinner-border=
; border-top-color: ; border-top-style: ; border-top-width: ; border-right-=
style: ; border-right-width: ; border-bottom-color: ; border-bottom-style: =
; border-bottom-width: ; border-left-color: ; border-left-style: ; border-l=
eft-width: ; border-image-source: ; border-image-slice: ; border-image-widt=
h: ; border-image-outset: ; border-image-repeat: ; border-right-color: rgba=
(0, 0, 0, 0); }

.spinner-border-sm { --bs-spinner-width: 1rem; --bs-spinner-height: 1rem; -=
-bs-spinner-border-width: 0.2em; }

@keyframes spinner-grow {=20
  0% { transform: scale(0); }
  50% { opacity: 1; transform: none; }
}

.spinner-grow { --bs-spinner-width: 2rem; --bs-spinner-height: 2rem; --bs-s=
pinner-vertical-align: -0.125em; --bs-spinner-animation-speed: 0.75s; --bs-=
spinner-animation-name: spinner-grow; background-color: currentcolor; opaci=
ty: 0; }

.spinner-grow-sm { --bs-spinner-width: 1rem; --bs-spinner-height: 1rem; }

@media (prefers-reduced-motion: reduce) {
  .spinner-border, .spinner-grow { --bs-spinner-animation-speed: 1.5s; }
}

.clearfix::after { display: block; clear: both; content: ""; }

.text-bg-primary { color: rgb(0, 0, 0) !important; background-color: RGBA(2=
21, 221, 221, var(--bs-bg-opacity, 1)) !important; }

.text-bg-secondary { color: rgb(0, 0, 0) !important; background-color: RGBA=
(221, 221, 221, var(--bs-bg-opacity, 1)) !important; }

.text-bg-success { color: rgb(255, 255, 255) !important; background-color: =
RGBA(25, 135, 84, var(--bs-bg-opacity, 1)) !important; }

.text-bg-info { color: rgb(0, 0, 0) !important; background-color: RGBA(13, =
202, 240, var(--bs-bg-opacity, 1)) !important; }

.text-bg-warning { color: rgb(0, 0, 0) !important; background-color: RGBA(2=
55, 193, 7, var(--bs-bg-opacity, 1)) !important; }

.text-bg-danger { color: rgb(255, 255, 255) !important; background-color: R=
GBA(220, 53, 69, var(--bs-bg-opacity, 1)) !important; }

.text-bg-light { color: rgb(0, 0, 0) !important; background-color: RGBA(248=
, 249, 250, var(--bs-bg-opacity, 1)) !important; }

.text-bg-dark { color: rgb(255, 255, 255) !important; background-color: RGB=
A(33, 37, 41, var(--bs-bg-opacity, 1)) !important; }

.link-primary { color: rgb(221, 221, 221) !important; }

.link-primary:hover, .link-primary:focus { color: rgb(228, 228, 228) !impor=
tant; }

.link-secondary { color: rgb(221, 221, 221) !important; }

.link-secondary:hover, .link-secondary:focus { color: rgb(228, 228, 228) !i=
mportant; }

.link-success { color: rgb(25, 135, 84) !important; }

.link-success:hover, .link-success:focus { color: rgb(20, 108, 67) !importa=
nt; }

.link-info { color: rgb(13, 202, 240) !important; }

.link-info:hover, .link-info:focus { color: rgb(61, 213, 243) !important; }

.link-warning { color: rgb(255, 193, 7) !important; }

.link-warning:hover, .link-warning:focus { color: rgb(255, 205, 57) !import=
ant; }

.link-danger { color: rgb(220, 53, 69) !important; }

.link-danger:hover, .link-danger:focus { color: rgb(176, 42, 55) !important=
; }

.link-light { color: rgb(248, 249, 250) !important; }

.link-light:hover, .link-light:focus { color: rgb(249, 250, 251) !important=
; }

.link-dark { color: rgb(33, 37, 41) !important; }

.link-dark:hover, .link-dark:focus { color: rgb(26, 30, 33) !important; }

.ratio { position: relative; width: 100%; }

.ratio::before { display: block; padding-top: var(--bs-aspect-ratio); conte=
nt: ""; }

.ratio > * { position: absolute; top: 0px; left: 0px; width: 100%; height: =
100%; }

.ratio-1x1 { --bs-aspect-ratio: 100%; }

.ratio-4x3 { --bs-aspect-ratio: 75%; }

.ratio-16x9 { --bs-aspect-ratio: 56.25%; }

.ratio-21x9 { --bs-aspect-ratio: 42.8571428571%; }

.fixed-top { position: fixed; top: 0px; right: 0px; left: 0px; z-index: 103=
0; }

.fixed-bottom { position: fixed; right: 0px; bottom: 0px; left: 0px; z-inde=
x: 1030; }

.sticky-top { position: sticky; top: 0px; z-index: 1020; }

.sticky-bottom { position: sticky; bottom: 0px; z-index: 1020; }

@media (min-width: 576px) {
  .sticky-sm-top { position: sticky; top: 0px; z-index: 1020; }
  .sticky-sm-bottom { position: sticky; bottom: 0px; z-index: 1020; }
}

@media (min-width: 768px) {
  .sticky-md-top { position: sticky; top: 0px; z-index: 1020; }
  .sticky-md-bottom { position: sticky; bottom: 0px; z-index: 1020; }
}

@media (min-width: 992px) {
  .sticky-lg-top { position: sticky; top: 0px; z-index: 1020; }
  .sticky-lg-bottom { position: sticky; bottom: 0px; z-index: 1020; }
}

@media (min-width: 1200px) {
  .sticky-xl-top { position: sticky; top: 0px; z-index: 1020; }
  .sticky-xl-bottom { position: sticky; bottom: 0px; z-index: 1020; }
}

@media (min-width: 1400px) {
  .sticky-xxl-top { position: sticky; top: 0px; z-index: 1020; }
  .sticky-xxl-bottom { position: sticky; bottom: 0px; z-index: 1020; }
}

.hstack { display: flex; flex-direction: row; align-items: center; align-se=
lf: stretch; }

.vstack { display: flex; flex: 1 1 auto; flex-direction: column; align-self=
: stretch; }

.visually-hidden, .visually-hidden-focusable:not(:focus):not(:focus-within)=
 { position: absolute !important; width: 1px !important; height: 1px !impor=
tant; padding: 0px !important; margin: -1px !important; overflow: hidden !i=
mportant; clip: rect(0px, 0px, 0px, 0px) !important; white-space: nowrap !i=
mportant; border: 0px !important; }

.stretched-link::after { position: absolute; inset: 0px; z-index: 1; conten=
t: ""; }

.text-truncate { overflow: hidden; text-overflow: ellipsis; white-space: no=
wrap; }

.vr { display: inline-block; align-self: stretch; width: 1px; min-height: 1=
em; background-color: currentcolor; opacity: 0.25; }

.align-baseline { vertical-align: baseline !important; }

.align-top { vertical-align: top !important; }

.align-middle { vertical-align: middle !important; }

.align-bottom { vertical-align: bottom !important; }

.align-text-bottom { vertical-align: text-bottom !important; }

.align-text-top { vertical-align: text-top !important; }

.float-start { float: left !important; }

.float-end { float: right !important; }

.float-none { float: none !important; }

.opacity-0 { opacity: 0 !important; }

.opacity-25 { opacity: 0.25 !important; }

.opacity-50 { opacity: 0.5 !important; }

.opacity-75 { opacity: 0.75 !important; }

.opacity-100 { opacity: 1 !important; }

.overflow-auto { overflow: auto !important; }

.overflow-hidden { overflow: hidden !important; }

.overflow-visible { overflow: visible !important; }

.overflow-scroll { overflow: scroll !important; }

.d-inline { display: inline !important; }

.d-inline-block { display: inline-block !important; }

.d-block { display: block !important; }

.d-grid { display: grid !important; }

.d-table { display: table !important; }

.d-table-row { display: table-row !important; }

.d-table-cell { display: table-cell !important; }

.d-flex { display: flex !important; }

.d-inline-flex { display: inline-flex !important; }

.d-none { display: none !important; }

.shadow { box-shadow: rgba(0, 0, 0, 0.15) 0px 0.5rem 1rem !important; }

.shadow-sm { box-shadow: rgba(0, 0, 0, 0.075) 0px 0.125rem 0.25rem !importa=
nt; }

.shadow-lg { box-shadow: rgba(0, 0, 0, 0.176) 0px 1rem 3rem !important; }

.shadow-none { box-shadow: none !important; }

.position-static { position: static !important; }

.position-relative { position: relative !important; }

.position-absolute { position: absolute !important; }

.position-fixed { position: fixed !important; }

.position-sticky { position: sticky !important; }

.top-0 { top: 0px !important; }

.top-50 { top: 50% !important; }

.top-100 { top: 100% !important; }

.bottom-0 { bottom: 0px !important; }

.bottom-50 { bottom: 50% !important; }

.bottom-100 { bottom: 100% !important; }

.start-0 { left: 0px !important; }

.start-50 { left: 50% !important; }

.start-100 { left: 100% !important; }

.end-0 { right: 0px !important; }

.end-50 { right: 50% !important; }

.end-100 { right: 100% !important; }

.translate-middle { transform: translate(-50%, -50%) !important; }

.translate-middle-x { transform: translateX(-50%) !important; }

.translate-middle-y { transform: translateY(-50%) !important; }

.border { border: var(--bs-border-width) var(--bs-border-style) var(--bs-bo=
rder-color) !important; }

.border-0 { border: 0px !important; }

.border-top { border-top: var(--bs-border-width) var(--bs-border-style) var=
(--bs-border-color) !important; }

.border-top-0 { border-top: 0px !important; }

.border-end { border-right: var(--bs-border-width) var(--bs-border-style) v=
ar(--bs-border-color) !important; }

.border-end-0 { border-right: 0px !important; }

.border-bottom { border-bottom: var(--bs-border-width) var(--bs-border-styl=
e) var(--bs-border-color) !important; }

.border-bottom-0 { border-bottom: 0px !important; }

.border-start { border-left: var(--bs-border-width) var(--bs-border-style) =
var(--bs-border-color) !important; }

.border-start-0 { border-left: 0px !important; }

.border-primary { --bs-border-opacity: 1; border-color: rgba(var(--bs-prima=
ry-rgb), var(--bs-border-opacity)) !important; }

.border-secondary { --bs-border-opacity: 1; border-color: rgba(var(--bs-sec=
ondary-rgb), var(--bs-border-opacity)) !important; }

.border-success { --bs-border-opacity: 1; border-color: rgba(var(--bs-succe=
ss-rgb), var(--bs-border-opacity)) !important; }

.border-info { --bs-border-opacity: 1; border-color: rgba(var(--bs-info-rgb=
), var(--bs-border-opacity)) !important; }

.border-warning { --bs-border-opacity: 1; border-color: rgba(var(--bs-warni=
ng-rgb), var(--bs-border-opacity)) !important; }

.border-danger { --bs-border-opacity: 1; border-color: rgba(var(--bs-danger=
-rgb), var(--bs-border-opacity)) !important; }

.border-light { --bs-border-opacity: 1; border-color: rgba(var(--bs-light-r=
gb), var(--bs-border-opacity)) !important; }

.border-dark { --bs-border-opacity: 1; border-color: rgba(var(--bs-dark-rgb=
), var(--bs-border-opacity)) !important; }

.border-white { --bs-border-opacity: 1; border-color: rgba(var(--bs-white-r=
gb), var(--bs-border-opacity)) !important; }

.border-1 { --bs-border-width: 1px; }

.border-2 { --bs-border-width: 2px; }

.border-3 { --bs-border-width: 3px; }

.border-4 { --bs-border-width: 4px; }

.border-5 { --bs-border-width: 5px; }

.border-opacity-10 { --bs-border-opacity: 0.1; }

.border-opacity-25 { --bs-border-opacity: 0.25; }

.border-opacity-50 { --bs-border-opacity: 0.5; }

.border-opacity-75 { --bs-border-opacity: 0.75; }

.border-opacity-100 { --bs-border-opacity: 1; }

.w-25 { width: 25% !important; }

.w-50 { width: 50% !important; }

.w-75 { width: 75% !important; }

.w-100 { width: 100% !important; }

.w-auto { width: auto !important; }

.mw-100 { max-width: 100% !important; }

.vw-100 { width: 100vw !important; }

.min-vw-100 { min-width: 100vw !important; }

.h-25 { height: 25% !important; }

.h-50 { height: 50% !important; }

.h-75 { height: 75% !important; }

.h-100 { height: 100% !important; }

.h-auto { height: auto !important; }

.mh-100 { max-height: 100% !important; }

.vh-100 { height: 100vh !important; }

.min-vh-100 { min-height: 100vh !important; }

.flex-fill { flex: 1 1 auto !important; }

.flex-row { flex-direction: row !important; }

.flex-column { flex-direction: column !important; }

.flex-row-reverse { flex-direction: row-reverse !important; }

.flex-column-reverse { flex-direction: column-reverse !important; }

.flex-grow-0 { flex-grow: 0 !important; }

.flex-grow-1 { flex-grow: 1 !important; }

.flex-shrink-0 { flex-shrink: 0 !important; }

.flex-shrink-1 { flex-shrink: 1 !important; }

.flex-wrap { flex-wrap: wrap !important; }

.flex-nowrap { flex-wrap: nowrap !important; }

.flex-wrap-reverse { flex-wrap: wrap-reverse !important; }

.justify-content-start { justify-content: flex-start !important; }

.justify-content-end { justify-content: flex-end !important; }

.justify-content-center { justify-content: center !important; }

.justify-content-between { justify-content: space-between !important; }

.justify-content-around { justify-content: space-around !important; }

.justify-content-evenly { justify-content: space-evenly !important; }

.align-items-start { align-items: flex-start !important; }

.align-items-end { align-items: flex-end !important; }

.align-items-center { align-items: center !important; }

.align-items-baseline { align-items: baseline !important; }

.align-items-stretch { align-items: stretch !important; }

.align-content-start { align-content: flex-start !important; }

.align-content-end { align-content: flex-end !important; }

.align-content-center { align-content: center !important; }

.align-content-between { align-content: space-between !important; }

.align-content-around { align-content: space-around !important; }

.align-content-stretch { align-content: stretch !important; }

.align-self-auto { align-self: auto !important; }

.align-self-start { align-self: flex-start !important; }

.align-self-end { align-self: flex-end !important; }

.align-self-center { align-self: center !important; }

.align-self-baseline { align-self: baseline !important; }

.align-self-stretch { align-self: stretch !important; }

.order-first { order: -1 !important; }

.order-0 { order: 0 !important; }

.order-1 { order: 1 !important; }

.order-2 { order: 2 !important; }

.order-3 { order: 3 !important; }

.order-4 { order: 4 !important; }

.order-5 { order: 5 !important; }

.order-last { order: 6 !important; }

.m-0 { margin: 0px !important; }

.m-1 { margin: 0.25rem !important; }

.m-2 { margin: 0.5rem !important; }

.m-3 { margin: 1rem !important; }

.m-4 { margin: 1.5rem !important; }

.m-5 { margin: 3rem !important; }

.m-auto { margin: auto !important; }

.mx-0 { margin-right: 0px !important; margin-left: 0px !important; }

.mx-1 { margin-right: 0.25rem !important; margin-left: 0.25rem !important; =
}

.mx-2 { margin-right: 0.5rem !important; margin-left: 0.5rem !important; }

.mx-3 { margin-right: 1rem !important; margin-left: 1rem !important; }

.mx-4 { margin-right: 1.5rem !important; margin-left: 1.5rem !important; }

.mx-5 { margin-right: 3rem !important; margin-left: 3rem !important; }

.mx-auto { margin-right: auto !important; margin-left: auto !important; }

.my-0 { margin-top: 0px !important; margin-bottom: 0px !important; }

.my-1 { margin-top: 0.25rem !important; margin-bottom: 0.25rem !important; =
}

.my-2 { margin-top: 0.5rem !important; margin-bottom: 0.5rem !important; }

.my-3 { margin-top: 1rem !important; margin-bottom: 1rem !important; }

.my-4 { margin-top: 1.5rem !important; margin-bottom: 1.5rem !important; }

.my-5 { margin-top: 3rem !important; margin-bottom: 3rem !important; }

.my-auto { margin-top: auto !important; margin-bottom: auto !important; }

.mt-0 { margin-top: 0px !important; }

.mt-1 { margin-top: 0.25rem !important; }

.mt-2 { margin-top: 0.5rem !important; }

.mt-3 { margin-top: 1rem !important; }

.mt-4 { margin-top: 1.5rem !important; }

.mt-5 { margin-top: 3rem !important; }

.mt-auto { margin-top: auto !important; }

.me-0 { margin-right: 0px !important; }

.me-1 { margin-right: 0.25rem !important; }

.me-2 { margin-right: 0.5rem !important; }

.me-3 { margin-right: 1rem !important; }

.me-4 { margin-right: 1.5rem !important; }

.me-5 { margin-right: 3rem !important; }

.me-auto { margin-right: auto !important; }

.mb-0 { margin-bottom: 0px !important; }

.mb-1 { margin-bottom: 0.25rem !important; }

.mb-2 { margin-bottom: 0.5rem !important; }

.mb-3 { margin-bottom: 1rem !important; }

.mb-4 { margin-bottom: 1.5rem !important; }

.mb-5 { margin-bottom: 3rem !important; }

.mb-auto { margin-bottom: auto !important; }

.ms-0 { margin-left: 0px !important; }

.ms-1 { margin-left: 0.25rem !important; }

.ms-2 { margin-left: 0.5rem !important; }

.ms-3 { margin-left: 1rem !important; }

.ms-4 { margin-left: 1.5rem !important; }

.ms-5 { margin-left: 3rem !important; }

.ms-auto { margin-left: auto !important; }

.p-0 { padding: 0px !important; }

.p-1 { padding: 0.25rem !important; }

.p-2 { padding: 0.5rem !important; }

.p-3 { padding: 1rem !important; }

.p-4 { padding: 1.5rem !important; }

.p-5 { padding: 3rem !important; }

.px-0 { padding-right: 0px !important; padding-left: 0px !important; }

.px-1 { padding-right: 0.25rem !important; padding-left: 0.25rem !important=
; }

.px-2 { padding-right: 0.5rem !important; padding-left: 0.5rem !important; =
}

.px-3 { padding-right: 1rem !important; padding-left: 1rem !important; }

.px-4 { padding-right: 1.5rem !important; padding-left: 1.5rem !important; =
}

.px-5 { padding-right: 3rem !important; padding-left: 3rem !important; }

.py-0 { padding-top: 0px !important; padding-bottom: 0px !important; }

.py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important=
; }

.py-2 { padding-top: 0.5rem !important; padding-bottom: 0.5rem !important; =
}

.py-3 { padding-top: 1rem !important; padding-bottom: 1rem !important; }

.py-4 { padding-top: 1.5rem !important; padding-bottom: 1.5rem !important; =
}

.py-5 { padding-top: 3rem !important; padding-bottom: 3rem !important; }

.pt-0 { padding-top: 0px !important; }

.pt-1 { padding-top: 0.25rem !important; }

.pt-2 { padding-top: 0.5rem !important; }

.pt-3 { padding-top: 1rem !important; }

.pt-4 { padding-top: 1.5rem !important; }

.pt-5 { padding-top: 3rem !important; }

.pe-0 { padding-right: 0px !important; }

.pe-1 { padding-right: 0.25rem !important; }

.pe-2 { padding-right: 0.5rem !important; }

.pe-3 { padding-right: 1rem !important; }

.pe-4 { padding-right: 1.5rem !important; }

.pe-5 { padding-right: 3rem !important; }

.pb-0 { padding-bottom: 0px !important; }

.pb-1 { padding-bottom: 0.25rem !important; }

.pb-2 { padding-bottom: 0.5rem !important; }

.pb-3 { padding-bottom: 1rem !important; }

.pb-4 { padding-bottom: 1.5rem !important; }

.pb-5 { padding-bottom: 3rem !important; }

.ps-0 { padding-left: 0px !important; }

.ps-1 { padding-left: 0.25rem !important; }

.ps-2 { padding-left: 0.5rem !important; }

.ps-3 { padding-left: 1rem !important; }

.ps-4 { padding-left: 1.5rem !important; }

.ps-5 { padding-left: 3rem !important; }

.gap-0 { gap: 0px !important; }

.gap-1 { gap: 0.25rem !important; }

.gap-2 { gap: 0.5rem !important; }

.gap-3 { gap: 1rem !important; }

.gap-4 { gap: 1.5rem !important; }

.gap-5 { gap: 3rem !important; }

.font-monospace { font-family: var(--bs-font-monospace) !important; }

.fs-1 { font-size: 140% !important; }

.fs-2 { font-size: 2em !important; }

.fs-3 { font-size: 1rem !important; }

.fs-4 { font-size: 1.23rem !important; }

.fs-5 { font-size: 1.025rem !important; }

.fs-6 { font-size: 0.82rem !important; }

.fst-italic { font-style: italic !important; }

.fst-normal { font-style: normal !important; }

.fw-light { font-weight: 300 !important; }

.fw-lighter { font-weight: lighter !important; }

.fw-normal { font-weight: 400 !important; }

.fw-bold { font-weight: 700 !important; }

.fw-semibold { font-weight: 600 !important; }

.fw-bolder { font-weight: bolder !important; }

.lh-1 { line-height: 1 !important; }

.lh-sm { line-height: 1.25 !important; }

.lh-base { line-height: 1.5 !important; }

.lh-lg { line-height: 2 !important; }

.text-start { text-align: left !important; }

.text-end { text-align: right !important; }

.text-center { text-align: center !important; }

.text-decoration-none { text-decoration: none !important; }

.text-decoration-underline { text-decoration: underline !important; }

.text-decoration-line-through { text-decoration: line-through !important; }

.text-lowercase { text-transform: lowercase !important; }

.text-uppercase { text-transform: uppercase !important; }

.text-capitalize { text-transform: capitalize !important; }

.text-wrap { white-space: normal !important; }

.text-nowrap { white-space: nowrap !important; }

.text-break { overflow-wrap: break-word !important; word-break: break-word =
!important; }

.text-primary { --bs-text-opacity: 1; color: rgba(var(--bs-primary-rgb), va=
r(--bs-text-opacity)) !important; }

.text-secondary { --bs-text-opacity: 1; color: rgba(var(--bs-secondary-rgb)=
, var(--bs-text-opacity)) !important; }

.text-success { --bs-text-opacity: 1; color: rgba(var(--bs-success-rgb), va=
r(--bs-text-opacity)) !important; }

.text-info { --bs-text-opacity: 1; color: rgba(var(--bs-info-rgb), var(--bs=
-text-opacity)) !important; }

.text-warning { --bs-text-opacity: 1; color: rgba(var(--bs-warning-rgb), va=
r(--bs-text-opacity)) !important; }

.text-danger { --bs-text-opacity: 1; color: rgba(var(--bs-danger-rgb), var(=
--bs-text-opacity)) !important; }

.text-light { --bs-text-opacity: 1; color: rgba(var(--bs-light-rgb), var(--=
bs-text-opacity)) !important; }

.text-dark { --bs-text-opacity: 1; color: rgba(var(--bs-dark-rgb), var(--bs=
-text-opacity)) !important; }

.text-black { --bs-text-opacity: 1; color: rgba(var(--bs-black-rgb), var(--=
bs-text-opacity)) !important; }

.text-white { --bs-text-opacity: 1; color: rgba(var(--bs-white-rgb), var(--=
bs-text-opacity)) !important; }

.text-body { --bs-text-opacity: 1; color: rgba(var(--bs-body-color-rgb), va=
r(--bs-text-opacity)) !important; }

.text-muted { --bs-text-opacity: 1; color: rgb(108, 117, 125) !important; }

.text-black-50 { --bs-text-opacity: 1; color: rgba(0, 0, 0, 0.5) !important=
; }

.text-white-50 { --bs-text-opacity: 1; color: rgba(255, 255, 255, 0.5) !imp=
ortant; }

.text-reset { --bs-text-opacity: 1; color: inherit !important; }

.text-opacity-25 { --bs-text-opacity: 0.25; }

.text-opacity-50 { --bs-text-opacity: 0.5; }

.text-opacity-75 { --bs-text-opacity: 0.75; }

.text-opacity-100 { --bs-text-opacity: 1; }

.bg-primary { --bs-bg-opacity: 1; background-color: rgba(var(--bs-primary-r=
gb), var(--bs-bg-opacity)) !important; }

.bg-secondary { --bs-bg-opacity: 1; background-color: rgba(var(--bs-seconda=
ry-rgb), var(--bs-bg-opacity)) !important; }

.bg-success { --bs-bg-opacity: 1; background-color: rgba(var(--bs-success-r=
gb), var(--bs-bg-opacity)) !important; }

.bg-info { --bs-bg-opacity: 1; background-color: rgba(var(--bs-info-rgb), v=
ar(--bs-bg-opacity)) !important; }

.bg-warning { --bs-bg-opacity: 1; background-color: rgba(var(--bs-warning-r=
gb), var(--bs-bg-opacity)) !important; }

.bg-danger { --bs-bg-opacity: 1; background-color: rgba(var(--bs-danger-rgb=
), var(--bs-bg-opacity)) !important; }

.bg-light { --bs-bg-opacity: 1; background-color: rgba(var(--bs-light-rgb),=
 var(--bs-bg-opacity)) !important; }

.bg-dark { --bs-bg-opacity: 1; background-color: rgba(var(--bs-dark-rgb), v=
ar(--bs-bg-opacity)) !important; }

.bg-black { --bs-bg-opacity: 1; background-color: rgba(var(--bs-black-rgb),=
 var(--bs-bg-opacity)) !important; }

.bg-white { --bs-bg-opacity: 1; background-color: rgba(var(--bs-white-rgb),=
 var(--bs-bg-opacity)) !important; }

.bg-body { --bs-bg-opacity: 1; background-color: rgba(var(--bs-body-bg-rgb)=
, var(--bs-bg-opacity)) !important; }

.bg-transparent { --bs-bg-opacity: 1; background-color: rgba(0, 0, 0, 0) !i=
mportant; }

.bg-opacity-10 { --bs-bg-opacity: 0.1; }

.bg-opacity-25 { --bs-bg-opacity: 0.25; }

.bg-opacity-50 { --bs-bg-opacity: 0.5; }

.bg-opacity-75 { --bs-bg-opacity: 0.75; }

.bg-opacity-100 { --bs-bg-opacity: 1; }

.bg-gradient { background-image: var(--bs-gradient) !important; }

.user-select-all { user-select: all !important; }

.user-select-auto { user-select: auto !important; }

.user-select-none { user-select: none !important; }

.pe-none { pointer-events: none !important; }

.pe-auto { pointer-events: auto !important; }

.rounded { border-radius: var(--bs-border-radius) !important; }

.rounded-0 { border-radius: 0px !important; }

.rounded-1 { border-radius: var(--bs-border-radius-sm) !important; }

.rounded-2 { border-radius: var(--bs-border-radius) !important; }

.rounded-3 { border-radius: var(--bs-border-radius-lg) !important; }

.rounded-4 { border-radius: var(--bs-border-radius-xl) !important; }

.rounded-5 { border-radius: var(--bs-border-radius-2xl) !important; }

.rounded-circle { border-radius: 50% !important; }

.rounded-pill { border-radius: var(--bs-border-radius-pill) !important; }

.rounded-top { border-top-left-radius: var(--bs-border-radius) !important; =
border-top-right-radius: var(--bs-border-radius) !important; }

.rounded-end { border-top-right-radius: var(--bs-border-radius) !important;=
 border-bottom-right-radius: var(--bs-border-radius) !important; }

.rounded-bottom { border-bottom-right-radius: var(--bs-border-radius) !impo=
rtant; border-bottom-left-radius: var(--bs-border-radius) !important; }

.rounded-start { border-bottom-left-radius: var(--bs-border-radius) !import=
ant; border-top-left-radius: var(--bs-border-radius) !important; }

.visible { visibility: visible !important; }

.invisible { visibility: hidden !important; }

@media (min-width: 576px) {
  .float-sm-start { float: left !important; }
  .float-sm-end { float: right !important; }
  .float-sm-none { float: none !important; }
  .d-sm-inline { display: inline !important; }
  .d-sm-inline-block { display: inline-block !important; }
  .d-sm-block { display: block !important; }
  .d-sm-grid { display: grid !important; }
  .d-sm-table { display: table !important; }
  .d-sm-table-row { display: table-row !important; }
  .d-sm-table-cell { display: table-cell !important; }
  .d-sm-flex { display: flex !important; }
  .d-sm-inline-flex { display: inline-flex !important; }
  .d-sm-none { display: none !important; }
  .flex-sm-fill { flex: 1 1 auto !important; }
  .flex-sm-row { flex-direction: row !important; }
  .flex-sm-column { flex-direction: column !important; }
  .flex-sm-row-reverse { flex-direction: row-reverse !important; }
  .flex-sm-column-reverse { flex-direction: column-reverse !important; }
  .flex-sm-grow-0 { flex-grow: 0 !important; }
  .flex-sm-grow-1 { flex-grow: 1 !important; }
  .flex-sm-shrink-0 { flex-shrink: 0 !important; }
  .flex-sm-shrink-1 { flex-shrink: 1 !important; }
  .flex-sm-wrap { flex-wrap: wrap !important; }
  .flex-sm-nowrap { flex-wrap: nowrap !important; }
  .flex-sm-wrap-reverse { flex-wrap: wrap-reverse !important; }
  .justify-content-sm-start { justify-content: flex-start !important; }
  .justify-content-sm-end { justify-content: flex-end !important; }
  .justify-content-sm-center { justify-content: center !important; }
  .justify-content-sm-between { justify-content: space-between !important; =
}
  .justify-content-sm-around { justify-content: space-around !important; }
  .justify-content-sm-evenly { justify-content: space-evenly !important; }
  .align-items-sm-start { align-items: flex-start !important; }
  .align-items-sm-end { align-items: flex-end !important; }
  .align-items-sm-center { align-items: center !important; }
  .align-items-sm-baseline { align-items: baseline !important; }
  .align-items-sm-stretch { align-items: stretch !important; }
  .align-content-sm-start { align-content: flex-start !important; }
  .align-content-sm-end { align-content: flex-end !important; }
  .align-content-sm-center { align-content: center !important; }
  .align-content-sm-between { align-content: space-between !important; }
  .align-content-sm-around { align-content: space-around !important; }
  .align-content-sm-stretch { align-content: stretch !important; }
  .align-self-sm-auto { align-self: auto !important; }
  .align-self-sm-start { align-self: flex-start !important; }
  .align-self-sm-end { align-self: flex-end !important; }
  .align-self-sm-center { align-self: center !important; }
  .align-self-sm-baseline { align-self: baseline !important; }
  .align-self-sm-stretch { align-self: stretch !important; }
  .order-sm-first { order: -1 !important; }
  .order-sm-0 { order: 0 !important; }
  .order-sm-1 { order: 1 !important; }
  .order-sm-2 { order: 2 !important; }
  .order-sm-3 { order: 3 !important; }
  .order-sm-4 { order: 4 !important; }
  .order-sm-5 { order: 5 !important; }
  .order-sm-last { order: 6 !important; }
  .m-sm-0 { margin: 0px !important; }
  .m-sm-1 { margin: 0.25rem !important; }
  .m-sm-2 { margin: 0.5rem !important; }
  .m-sm-3 { margin: 1rem !important; }
  .m-sm-4 { margin: 1.5rem !important; }
  .m-sm-5 { margin: 3rem !important; }
  .m-sm-auto { margin: auto !important; }
  .mx-sm-0 { margin-right: 0px !important; margin-left: 0px !important; }
  .mx-sm-1 { margin-right: 0.25rem !important; margin-left: 0.25rem !import=
ant; }
  .mx-sm-2 { margin-right: 0.5rem !important; margin-left: 0.5rem !importan=
t; }
  .mx-sm-3 { margin-right: 1rem !important; margin-left: 1rem !important; }
  .mx-sm-4 { margin-right: 1.5rem !important; margin-left: 1.5rem !importan=
t; }
  .mx-sm-5 { margin-right: 3rem !important; margin-left: 3rem !important; }
  .mx-sm-auto { margin-right: auto !important; margin-left: auto !important=
; }
  .my-sm-0 { margin-top: 0px !important; margin-bottom: 0px !important; }
  .my-sm-1 { margin-top: 0.25rem !important; margin-bottom: 0.25rem !import=
ant; }
  .my-sm-2 { margin-top: 0.5rem !important; margin-bottom: 0.5rem !importan=
t; }
  .my-sm-3 { margin-top: 1rem !important; margin-bottom: 1rem !important; }
  .my-sm-4 { margin-top: 1.5rem !important; margin-bottom: 1.5rem !importan=
t; }
  .my-sm-5 { margin-top: 3rem !important; margin-bottom: 3rem !important; }
  .my-sm-auto { margin-top: auto !important; margin-bottom: auto !important=
; }
  .mt-sm-0 { margin-top: 0px !important; }
  .mt-sm-1 { margin-top: 0.25rem !important; }
  .mt-sm-2 { margin-top: 0.5rem !important; }
  .mt-sm-3 { margin-top: 1rem !important; }
  .mt-sm-4 { margin-top: 1.5rem !important; }
  .mt-sm-5 { margin-top: 3rem !important; }
  .mt-sm-auto { margin-top: auto !important; }
  .me-sm-0 { margin-right: 0px !important; }
  .me-sm-1 { margin-right: 0.25rem !important; }
  .me-sm-2 { margin-right: 0.5rem !important; }
  .me-sm-3 { margin-right: 1rem !important; }
  .me-sm-4 { margin-right: 1.5rem !important; }
  .me-sm-5 { margin-right: 3rem !important; }
  .me-sm-auto { margin-right: auto !important; }
  .mb-sm-0 { margin-bottom: 0px !important; }
  .mb-sm-1 { margin-bottom: 0.25rem !important; }
  .mb-sm-2 { margin-bottom: 0.5rem !important; }
  .mb-sm-3 { margin-bottom: 1rem !important; }
  .mb-sm-4 { margin-bottom: 1.5rem !important; }
  .mb-sm-5 { margin-bottom: 3rem !important; }
  .mb-sm-auto { margin-bottom: auto !important; }
  .ms-sm-0 { margin-left: 0px !important; }
  .ms-sm-1 { margin-left: 0.25rem !important; }
  .ms-sm-2 { margin-left: 0.5rem !important; }
  .ms-sm-3 { margin-left: 1rem !important; }
  .ms-sm-4 { margin-left: 1.5rem !important; }
  .ms-sm-5 { margin-left: 3rem !important; }
  .ms-sm-auto { margin-left: auto !important; }
  .p-sm-0 { padding: 0px !important; }
  .p-sm-1 { padding: 0.25rem !important; }
  .p-sm-2 { padding: 0.5rem !important; }
  .p-sm-3 { padding: 1rem !important; }
  .p-sm-4 { padding: 1.5rem !important; }
  .p-sm-5 { padding: 3rem !important; }
  .px-sm-0 { padding-right: 0px !important; padding-left: 0px !important; }
  .px-sm-1 { padding-right: 0.25rem !important; padding-left: 0.25rem !impo=
rtant; }
  .px-sm-2 { padding-right: 0.5rem !important; padding-left: 0.5rem !import=
ant; }
  .px-sm-3 { padding-right: 1rem !important; padding-left: 1rem !important;=
 }
  .px-sm-4 { padding-right: 1.5rem !important; padding-left: 1.5rem !import=
ant; }
  .px-sm-5 { padding-right: 3rem !important; padding-left: 3rem !important;=
 }
  .py-sm-0 { padding-top: 0px !important; padding-bottom: 0px !important; }
  .py-sm-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !impo=
rtant; }
  .py-sm-2 { padding-top: 0.5rem !important; padding-bottom: 0.5rem !import=
ant; }
  .py-sm-3 { padding-top: 1rem !important; padding-bottom: 1rem !important;=
 }
  .py-sm-4 { padding-top: 1.5rem !important; padding-bottom: 1.5rem !import=
ant; }
  .py-sm-5 { padding-top: 3rem !important; padding-bottom: 3rem !important;=
 }
  .pt-sm-0 { padding-top: 0px !important; }
  .pt-sm-1 { padding-top: 0.25rem !important; }
  .pt-sm-2 { padding-top: 0.5rem !important; }
  .pt-sm-3 { padding-top: 1rem !important; }
  .pt-sm-4 { padding-top: 1.5rem !important; }
  .pt-sm-5 { padding-top: 3rem !important; }
  .pe-sm-0 { padding-right: 0px !important; }
  .pe-sm-1 { padding-right: 0.25rem !important; }
  .pe-sm-2 { padding-right: 0.5rem !important; }
  .pe-sm-3 { padding-right: 1rem !important; }
  .pe-sm-4 { padding-right: 1.5rem !important; }
  .pe-sm-5 { padding-right: 3rem !important; }
  .pb-sm-0 { padding-bottom: 0px !important; }
  .pb-sm-1 { padding-bottom: 0.25rem !important; }
  .pb-sm-2 { padding-bottom: 0.5rem !important; }
  .pb-sm-3 { padding-bottom: 1rem !important; }
  .pb-sm-4 { padding-bottom: 1.5rem !important; }
  .pb-sm-5 { padding-bottom: 3rem !important; }
  .ps-sm-0 { padding-left: 0px !important; }
  .ps-sm-1 { padding-left: 0.25rem !important; }
  .ps-sm-2 { padding-left: 0.5rem !important; }
  .ps-sm-3 { padding-left: 1rem !important; }
  .ps-sm-4 { padding-left: 1.5rem !important; }
  .ps-sm-5 { padding-left: 3rem !important; }
  .gap-sm-0 { gap: 0px !important; }
  .gap-sm-1 { gap: 0.25rem !important; }
  .gap-sm-2 { gap: 0.5rem !important; }
  .gap-sm-3 { gap: 1rem !important; }
  .gap-sm-4 { gap: 1.5rem !important; }
  .gap-sm-5 { gap: 3rem !important; }
  .text-sm-start { text-align: left !important; }
  .text-sm-end { text-align: right !important; }
  .text-sm-center { text-align: center !important; }
}

@media (min-width: 768px) {
  .float-md-start { float: left !important; }
  .float-md-end { float: right !important; }
  .float-md-none { float: none !important; }
  .d-md-inline { display: inline !important; }
  .d-md-inline-block { display: inline-block !important; }
  .d-md-block { display: block !important; }
  .d-md-grid { display: grid !important; }
  .d-md-table { display: table !important; }
  .d-md-table-row { display: table-row !important; }
  .d-md-table-cell { display: table-cell !important; }
  .d-md-flex { display: flex !important; }
  .d-md-inline-flex { display: inline-flex !important; }
  .d-md-none { display: none !important; }
  .flex-md-fill { flex: 1 1 auto !important; }
  .flex-md-row { flex-direction: row !important; }
  .flex-md-column { flex-direction: column !important; }
  .flex-md-row-reverse { flex-direction: row-reverse !important; }
  .flex-md-column-reverse { flex-direction: column-reverse !important; }
  .flex-md-grow-0 { flex-grow: 0 !important; }
  .flex-md-grow-1 { flex-grow: 1 !important; }
  .flex-md-shrink-0 { flex-shrink: 0 !important; }
  .flex-md-shrink-1 { flex-shrink: 1 !important; }
  .flex-md-wrap { flex-wrap: wrap !important; }
  .flex-md-nowrap { flex-wrap: nowrap !important; }
  .flex-md-wrap-reverse { flex-wrap: wrap-reverse !important; }
  .justify-content-md-start { justify-content: flex-start !important; }
  .justify-content-md-end { justify-content: flex-end !important; }
  .justify-content-md-center { justify-content: center !important; }
  .justify-content-md-between { justify-content: space-between !important; =
}
  .justify-content-md-around { justify-content: space-around !important; }
  .justify-content-md-evenly { justify-content: space-evenly !important; }
  .align-items-md-start { align-items: flex-start !important; }
  .align-items-md-end { align-items: flex-end !important; }
  .align-items-md-center { align-items: center !important; }
  .align-items-md-baseline { align-items: baseline !important; }
  .align-items-md-stretch { align-items: stretch !important; }
  .align-content-md-start { align-content: flex-start !important; }
  .align-content-md-end { align-content: flex-end !important; }
  .align-content-md-center { align-content: center !important; }
  .align-content-md-between { align-content: space-between !important; }
  .align-content-md-around { align-content: space-around !important; }
  .align-content-md-stretch { align-content: stretch !important; }
  .align-self-md-auto { align-self: auto !important; }
  .align-self-md-start { align-self: flex-start !important; }
  .align-self-md-end { align-self: flex-end !important; }
  .align-self-md-center { align-self: center !important; }
  .align-self-md-baseline { align-self: baseline !important; }
  .align-self-md-stretch { align-self: stretch !important; }
  .order-md-first { order: -1 !important; }
  .order-md-0 { order: 0 !important; }
  .order-md-1 { order: 1 !important; }
  .order-md-2 { order: 2 !important; }
  .order-md-3 { order: 3 !important; }
  .order-md-4 { order: 4 !important; }
  .order-md-5 { order: 5 !important; }
  .order-md-last { order: 6 !important; }
  .m-md-0 { margin: 0px !important; }
  .m-md-1 { margin: 0.25rem !important; }
  .m-md-2 { margin: 0.5rem !important; }
  .m-md-3 { margin: 1rem !important; }
  .m-md-4 { margin: 1.5rem !important; }
  .m-md-5 { margin: 3rem !important; }
  .m-md-auto { margin: auto !important; }
  .mx-md-0 { margin-right: 0px !important; margin-left: 0px !important; }
  .mx-md-1 { margin-right: 0.25rem !important; margin-left: 0.25rem !import=
ant; }
  .mx-md-2 { margin-right: 0.5rem !important; margin-left: 0.5rem !importan=
t; }
  .mx-md-3 { margin-right: 1rem !important; margin-left: 1rem !important; }
  .mx-md-4 { margin-right: 1.5rem !important; margin-left: 1.5rem !importan=
t; }
  .mx-md-5 { margin-right: 3rem !important; margin-left: 3rem !important; }
  .mx-md-auto { margin-right: auto !important; margin-left: auto !important=
; }
  .my-md-0 { margin-top: 0px !important; margin-bottom: 0px !important; }
  .my-md-1 { margin-top: 0.25rem !important; margin-bottom: 0.25rem !import=
ant; }
  .my-md-2 { margin-top: 0.5rem !important; margin-bottom: 0.5rem !importan=
t; }
  .my-md-3 { margin-top: 1rem !important; margin-bottom: 1rem !important; }
  .my-md-4 { margin-top: 1.5rem !important; margin-bottom: 1.5rem !importan=
t; }
  .my-md-5 { margin-top: 3rem !important; margin-bottom: 3rem !important; }
  .my-md-auto { margin-top: auto !important; margin-bottom: auto !important=
; }
  .mt-md-0 { margin-top: 0px !important; }
  .mt-md-1 { margin-top: 0.25rem !important; }
  .mt-md-2 { margin-top: 0.5rem !important; }
  .mt-md-3 { margin-top: 1rem !important; }
  .mt-md-4 { margin-top: 1.5rem !important; }
  .mt-md-5 { margin-top: 3rem !important; }
  .mt-md-auto { margin-top: auto !important; }
  .me-md-0 { margin-right: 0px !important; }
  .me-md-1 { margin-right: 0.25rem !important; }
  .me-md-2 { margin-right: 0.5rem !important; }
  .me-md-3 { margin-right: 1rem !important; }
  .me-md-4 { margin-right: 1.5rem !important; }
  .me-md-5 { margin-right: 3rem !important; }
  .me-md-auto { margin-right: auto !important; }
  .mb-md-0 { margin-bottom: 0px !important; }
  .mb-md-1 { margin-bottom: 0.25rem !important; }
  .mb-md-2 { margin-bottom: 0.5rem !important; }
  .mb-md-3 { margin-bottom: 1rem !important; }
  .mb-md-4 { margin-bottom: 1.5rem !important; }
  .mb-md-5 { margin-bottom: 3rem !important; }
  .mb-md-auto { margin-bottom: auto !important; }
  .ms-md-0 { margin-left: 0px !important; }
  .ms-md-1 { margin-left: 0.25rem !important; }
  .ms-md-2 { margin-left: 0.5rem !important; }
  .ms-md-3 { margin-left: 1rem !important; }
  .ms-md-4 { margin-left: 1.5rem !important; }
  .ms-md-5 { margin-left: 3rem !important; }
  .ms-md-auto { margin-left: auto !important; }
  .p-md-0 { padding: 0px !important; }
  .p-md-1 { padding: 0.25rem !important; }
  .p-md-2 { padding: 0.5rem !important; }
  .p-md-3 { padding: 1rem !important; }
  .p-md-4 { padding: 1.5rem !important; }
  .p-md-5 { padding: 3rem !important; }
  .px-md-0 { padding-right: 0px !important; padding-left: 0px !important; }
  .px-md-1 { padding-right: 0.25rem !important; padding-left: 0.25rem !impo=
rtant; }
  .px-md-2 { padding-right: 0.5rem !important; padding-left: 0.5rem !import=
ant; }
  .px-md-3 { padding-right: 1rem !important; padding-left: 1rem !important;=
 }
  .px-md-4 { padding-right: 1.5rem !important; padding-left: 1.5rem !import=
ant; }
  .px-md-5 { padding-right: 3rem !important; padding-left: 3rem !important;=
 }
  .py-md-0 { padding-top: 0px !important; padding-bottom: 0px !important; }
  .py-md-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !impo=
rtant; }
  .py-md-2 { padding-top: 0.5rem !important; padding-bottom: 0.5rem !import=
ant; }
  .py-md-3 { padding-top: 1rem !important; padding-bottom: 1rem !important;=
 }
  .py-md-4 { padding-top: 1.5rem !important; padding-bottom: 1.5rem !import=
ant; }
  .py-md-5 { padding-top: 3rem !important; padding-bottom: 3rem !important;=
 }
  .pt-md-0 { padding-top: 0px !important; }
  .pt-md-1 { padding-top: 0.25rem !important; }
  .pt-md-2 { padding-top: 0.5rem !important; }
  .pt-md-3 { padding-top: 1rem !important; }
  .pt-md-4 { padding-top: 1.5rem !important; }
  .pt-md-5 { padding-top: 3rem !important; }
  .pe-md-0 { padding-right: 0px !important; }
  .pe-md-1 { padding-right: 0.25rem !important; }
  .pe-md-2 { padding-right: 0.5rem !important; }
  .pe-md-3 { padding-right: 1rem !important; }
  .pe-md-4 { padding-right: 1.5rem !important; }
  .pe-md-5 { padding-right: 3rem !important; }
  .pb-md-0 { padding-bottom: 0px !important; }
  .pb-md-1 { padding-bottom: 0.25rem !important; }
  .pb-md-2 { padding-bottom: 0.5rem !important; }
  .pb-md-3 { padding-bottom: 1rem !important; }
  .pb-md-4 { padding-bottom: 1.5rem !important; }
  .pb-md-5 { padding-bottom: 3rem !important; }
  .ps-md-0 { padding-left: 0px !important; }
  .ps-md-1 { padding-left: 0.25rem !important; }
  .ps-md-2 { padding-left: 0.5rem !important; }
  .ps-md-3 { padding-left: 1rem !important; }
  .ps-md-4 { padding-left: 1.5rem !important; }
  .ps-md-5 { padding-left: 3rem !important; }
  .gap-md-0 { gap: 0px !important; }
  .gap-md-1 { gap: 0.25rem !important; }
  .gap-md-2 { gap: 0.5rem !important; }
  .gap-md-3 { gap: 1rem !important; }
  .gap-md-4 { gap: 1.5rem !important; }
  .gap-md-5 { gap: 3rem !important; }
  .text-md-start { text-align: left !important; }
  .text-md-end { text-align: right !important; }
  .text-md-center { text-align: center !important; }
}

@media (min-width: 992px) {
  .float-lg-start { float: left !important; }
  .float-lg-end { float: right !important; }
  .float-lg-none { float: none !important; }
  .d-lg-inline { display: inline !important; }
  .d-lg-inline-block { display: inline-block !important; }
  .d-lg-block { display: block !important; }
  .d-lg-grid { display: grid !important; }
  .d-lg-table { display: table !important; }
  .d-lg-table-row { display: table-row !important; }
  .d-lg-table-cell { display: table-cell !important; }
  .d-lg-flex { display: flex !important; }
  .d-lg-inline-flex { display: inline-flex !important; }
  .d-lg-none { display: none !important; }
  .flex-lg-fill { flex: 1 1 auto !important; }
  .flex-lg-row { flex-direction: row !important; }
  .flex-lg-column { flex-direction: column !important; }
  .flex-lg-row-reverse { flex-direction: row-reverse !important; }
  .flex-lg-column-reverse { flex-direction: column-reverse !important; }
  .flex-lg-grow-0 { flex-grow: 0 !important; }
  .flex-lg-grow-1 { flex-grow: 1 !important; }
  .flex-lg-shrink-0 { flex-shrink: 0 !important; }
  .flex-lg-shrink-1 { flex-shrink: 1 !important; }
  .flex-lg-wrap { flex-wrap: wrap !important; }
  .flex-lg-nowrap { flex-wrap: nowrap !important; }
  .flex-lg-wrap-reverse { flex-wrap: wrap-reverse !important; }
  .justify-content-lg-start { justify-content: flex-start !important; }
  .justify-content-lg-end { justify-content: flex-end !important; }
  .justify-content-lg-center { justify-content: center !important; }
  .justify-content-lg-between { justify-content: space-between !important; =
}
  .justify-content-lg-around { justify-content: space-around !important; }
  .justify-content-lg-evenly { justify-content: space-evenly !important; }
  .align-items-lg-start { align-items: flex-start !important; }
  .align-items-lg-end { align-items: flex-end !important; }
  .align-items-lg-center { align-items: center !important; }
  .align-items-lg-baseline { align-items: baseline !important; }
  .align-items-lg-stretch { align-items: stretch !important; }
  .align-content-lg-start { align-content: flex-start !important; }
  .align-content-lg-end { align-content: flex-end !important; }
  .align-content-lg-center { align-content: center !important; }
  .align-content-lg-between { align-content: space-between !important; }
  .align-content-lg-around { align-content: space-around !important; }
  .align-content-lg-stretch { align-content: stretch !important; }
  .align-self-lg-auto { align-self: auto !important; }
  .align-self-lg-start { align-self: flex-start !important; }
  .align-self-lg-end { align-self: flex-end !important; }
  .align-self-lg-center { align-self: center !important; }
  .align-self-lg-baseline { align-self: baseline !important; }
  .align-self-lg-stretch { align-self: stretch !important; }
  .order-lg-first { order: -1 !important; }
  .order-lg-0 { order: 0 !important; }
  .order-lg-1 { order: 1 !important; }
  .order-lg-2 { order: 2 !important; }
  .order-lg-3 { order: 3 !important; }
  .order-lg-4 { order: 4 !important; }
  .order-lg-5 { order: 5 !important; }
  .order-lg-last { order: 6 !important; }
  .m-lg-0 { margin: 0px !important; }
  .m-lg-1 { margin: 0.25rem !important; }
  .m-lg-2 { margin: 0.5rem !important; }
  .m-lg-3 { margin: 1rem !important; }
  .m-lg-4 { margin: 1.5rem !important; }
  .m-lg-5 { margin: 3rem !important; }
  .m-lg-auto { margin: auto !important; }
  .mx-lg-0 { margin-right: 0px !important; margin-left: 0px !important; }
  .mx-lg-1 { margin-right: 0.25rem !important; margin-left: 0.25rem !import=
ant; }
  .mx-lg-2 { margin-right: 0.5rem !important; margin-left: 0.5rem !importan=
t; }
  .mx-lg-3 { margin-right: 1rem !important; margin-left: 1rem !important; }
  .mx-lg-4 { margin-right: 1.5rem !important; margin-left: 1.5rem !importan=
t; }
  .mx-lg-5 { margin-right: 3rem !important; margin-left: 3rem !important; }
  .mx-lg-auto { margin-right: auto !important; margin-left: auto !important=
; }
  .my-lg-0 { margin-top: 0px !important; margin-bottom: 0px !important; }
  .my-lg-1 { margin-top: 0.25rem !important; margin-bottom: 0.25rem !import=
ant; }
  .my-lg-2 { margin-top: 0.5rem !important; margin-bottom: 0.5rem !importan=
t; }
  .my-lg-3 { margin-top: 1rem !important; margin-bottom: 1rem !important; }
  .my-lg-4 { margin-top: 1.5rem !important; margin-bottom: 1.5rem !importan=
t; }
  .my-lg-5 { margin-top: 3rem !important; margin-bottom: 3rem !important; }
  .my-lg-auto { margin-top: auto !important; margin-bottom: auto !important=
; }
  .mt-lg-0 { margin-top: 0px !important; }
  .mt-lg-1 { margin-top: 0.25rem !important; }
  .mt-lg-2 { margin-top: 0.5rem !important; }
  .mt-lg-3 { margin-top: 1rem !important; }
  .mt-lg-4 { margin-top: 1.5rem !important; }
  .mt-lg-5 { margin-top: 3rem !important; }
  .mt-lg-auto { margin-top: auto !important; }
  .me-lg-0 { margin-right: 0px !important; }
  .me-lg-1 { margin-right: 0.25rem !important; }
  .me-lg-2 { margin-right: 0.5rem !important; }
  .me-lg-3 { margin-right: 1rem !important; }
  .me-lg-4 { margin-right: 1.5rem !important; }
  .me-lg-5 { margin-right: 3rem !important; }
  .me-lg-auto { margin-right: auto !important; }
  .mb-lg-0 { margin-bottom: 0px !important; }
  .mb-lg-1 { margin-bottom: 0.25rem !important; }
  .mb-lg-2 { margin-bottom: 0.5rem !important; }
  .mb-lg-3 { margin-bottom: 1rem !important; }
  .mb-lg-4 { margin-bottom: 1.5rem !important; }
  .mb-lg-5 { margin-bottom: 3rem !important; }
  .mb-lg-auto { margin-bottom: auto !important; }
  .ms-lg-0 { margin-left: 0px !important; }
  .ms-lg-1 { margin-left: 0.25rem !important; }
  .ms-lg-2 { margin-left: 0.5rem !important; }
  .ms-lg-3 { margin-left: 1rem !important; }
  .ms-lg-4 { margin-left: 1.5rem !important; }
  .ms-lg-5 { margin-left: 3rem !important; }
  .ms-lg-auto { margin-left: auto !important; }
  .p-lg-0 { padding: 0px !important; }
  .p-lg-1 { padding: 0.25rem !important; }
  .p-lg-2 { padding: 0.5rem !important; }
  .p-lg-3 { padding: 1rem !important; }
  .p-lg-4 { padding: 1.5rem !important; }
  .p-lg-5 { padding: 3rem !important; }
  .px-lg-0 { padding-right: 0px !important; padding-left: 0px !important; }
  .px-lg-1 { padding-right: 0.25rem !important; padding-left: 0.25rem !impo=
rtant; }
  .px-lg-2 { padding-right: 0.5rem !important; padding-left: 0.5rem !import=
ant; }
  .px-lg-3 { padding-right: 1rem !important; padding-left: 1rem !important;=
 }
  .px-lg-4 { padding-right: 1.5rem !important; padding-left: 1.5rem !import=
ant; }
  .px-lg-5 { padding-right: 3rem !important; padding-left: 3rem !important;=
 }
  .py-lg-0 { padding-top: 0px !important; padding-bottom: 0px !important; }
  .py-lg-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !impo=
rtant; }
  .py-lg-2 { padding-top: 0.5rem !important; padding-bottom: 0.5rem !import=
ant; }
  .py-lg-3 { padding-top: 1rem !important; padding-bottom: 1rem !important;=
 }
  .py-lg-4 { padding-top: 1.5rem !important; padding-bottom: 1.5rem !import=
ant; }
  .py-lg-5 { padding-top: 3rem !important; padding-bottom: 3rem !important;=
 }
  .pt-lg-0 { padding-top: 0px !important; }
  .pt-lg-1 { padding-top: 0.25rem !important; }
  .pt-lg-2 { padding-top: 0.5rem !important; }
  .pt-lg-3 { padding-top: 1rem !important; }
  .pt-lg-4 { padding-top: 1.5rem !important; }
  .pt-lg-5 { padding-top: 3rem !important; }
  .pe-lg-0 { padding-right: 0px !important; }
  .pe-lg-1 { padding-right: 0.25rem !important; }
  .pe-lg-2 { padding-right: 0.5rem !important; }
  .pe-lg-3 { padding-right: 1rem !important; }
  .pe-lg-4 { padding-right: 1.5rem !important; }
  .pe-lg-5 { padding-right: 3rem !important; }
  .pb-lg-0 { padding-bottom: 0px !important; }
  .pb-lg-1 { padding-bottom: 0.25rem !important; }
  .pb-lg-2 { padding-bottom: 0.5rem !important; }
  .pb-lg-3 { padding-bottom: 1rem !important; }
  .pb-lg-4 { padding-bottom: 1.5rem !important; }
  .pb-lg-5 { padding-bottom: 3rem !important; }
  .ps-lg-0 { padding-left: 0px !important; }
  .ps-lg-1 { padding-left: 0.25rem !important; }
  .ps-lg-2 { padding-left: 0.5rem !important; }
  .ps-lg-3 { padding-left: 1rem !important; }
  .ps-lg-4 { padding-left: 1.5rem !important; }
  .ps-lg-5 { padding-left: 3rem !important; }
  .gap-lg-0 { gap: 0px !important; }
  .gap-lg-1 { gap: 0.25rem !important; }
  .gap-lg-2 { gap: 0.5rem !important; }
  .gap-lg-3 { gap: 1rem !important; }
  .gap-lg-4 { gap: 1.5rem !important; }
  .gap-lg-5 { gap: 3rem !important; }
  .text-lg-start { text-align: left !important; }
  .text-lg-end { text-align: right !important; }
  .text-lg-center { text-align: center !important; }
}

@media (min-width: 1200px) {
  .float-xl-start { float: left !important; }
  .float-xl-end { float: right !important; }
  .float-xl-none { float: none !important; }
  .d-xl-inline { display: inline !important; }
  .d-xl-inline-block { display: inline-block !important; }
  .d-xl-block { display: block !important; }
  .d-xl-grid { display: grid !important; }
  .d-xl-table { display: table !important; }
  .d-xl-table-row { display: table-row !important; }
  .d-xl-table-cell { display: table-cell !important; }
  .d-xl-flex { display: flex !important; }
  .d-xl-inline-flex { display: inline-flex !important; }
  .d-xl-none { display: none !important; }
  .flex-xl-fill { flex: 1 1 auto !important; }
  .flex-xl-row { flex-direction: row !important; }
  .flex-xl-column { flex-direction: column !important; }
  .flex-xl-row-reverse { flex-direction: row-reverse !important; }
  .flex-xl-column-reverse { flex-direction: column-reverse !important; }
  .flex-xl-grow-0 { flex-grow: 0 !important; }
  .flex-xl-grow-1 { flex-grow: 1 !important; }
  .flex-xl-shrink-0 { flex-shrink: 0 !important; }
  .flex-xl-shrink-1 { flex-shrink: 1 !important; }
  .flex-xl-wrap { flex-wrap: wrap !important; }
  .flex-xl-nowrap { flex-wrap: nowrap !important; }
  .flex-xl-wrap-reverse { flex-wrap: wrap-reverse !important; }
  .justify-content-xl-start { justify-content: flex-start !important; }
  .justify-content-xl-end { justify-content: flex-end !important; }
  .justify-content-xl-center { justify-content: center !important; }
  .justify-content-xl-between { justify-content: space-between !important; =
}
  .justify-content-xl-around { justify-content: space-around !important; }
  .justify-content-xl-evenly { justify-content: space-evenly !important; }
  .align-items-xl-start { align-items: flex-start !important; }
  .align-items-xl-end { align-items: flex-end !important; }
  .align-items-xl-center { align-items: center !important; }
  .align-items-xl-baseline { align-items: baseline !important; }
  .align-items-xl-stretch { align-items: stretch !important; }
  .align-content-xl-start { align-content: flex-start !important; }
  .align-content-xl-end { align-content: flex-end !important; }
  .align-content-xl-center { align-content: center !important; }
  .align-content-xl-between { align-content: space-between !important; }
  .align-content-xl-around { align-content: space-around !important; }
  .align-content-xl-stretch { align-content: stretch !important; }
  .align-self-xl-auto { align-self: auto !important; }
  .align-self-xl-start { align-self: flex-start !important; }
  .align-self-xl-end { align-self: flex-end !important; }
  .align-self-xl-center { align-self: center !important; }
  .align-self-xl-baseline { align-self: baseline !important; }
  .align-self-xl-stretch { align-self: stretch !important; }
  .order-xl-first { order: -1 !important; }
  .order-xl-0 { order: 0 !important; }
  .order-xl-1 { order: 1 !important; }
  .order-xl-2 { order: 2 !important; }
  .order-xl-3 { order: 3 !important; }
  .order-xl-4 { order: 4 !important; }
  .order-xl-5 { order: 5 !important; }
  .order-xl-last { order: 6 !important; }
  .m-xl-0 { margin: 0px !important; }
  .m-xl-1 { margin: 0.25rem !important; }
  .m-xl-2 { margin: 0.5rem !important; }
  .m-xl-3 { margin: 1rem !important; }
  .m-xl-4 { margin: 1.5rem !important; }
  .m-xl-5 { margin: 3rem !important; }
  .m-xl-auto { margin: auto !important; }
  .mx-xl-0 { margin-right: 0px !important; margin-left: 0px !important; }
  .mx-xl-1 { margin-right: 0.25rem !important; margin-left: 0.25rem !import=
ant; }
  .mx-xl-2 { margin-right: 0.5rem !important; margin-left: 0.5rem !importan=
t; }
  .mx-xl-3 { margin-right: 1rem !important; margin-left: 1rem !important; }
  .mx-xl-4 { margin-right: 1.5rem !important; margin-left: 1.5rem !importan=
t; }
  .mx-xl-5 { margin-right: 3rem !important; margin-left: 3rem !important; }
  .mx-xl-auto { margin-right: auto !important; margin-left: auto !important=
; }
  .my-xl-0 { margin-top: 0px !important; margin-bottom: 0px !important; }
  .my-xl-1 { margin-top: 0.25rem !important; margin-bottom: 0.25rem !import=
ant; }
  .my-xl-2 { margin-top: 0.5rem !important; margin-bottom: 0.5rem !importan=
t; }
  .my-xl-3 { margin-top: 1rem !important; margin-bottom: 1rem !important; }
  .my-xl-4 { margin-top: 1.5rem !important; margin-bottom: 1.5rem !importan=
t; }
  .my-xl-5 { margin-top: 3rem !important; margin-bottom: 3rem !important; }
  .my-xl-auto { margin-top: auto !important; margin-bottom: auto !important=
; }
  .mt-xl-0 { margin-top: 0px !important; }
  .mt-xl-1 { margin-top: 0.25rem !important; }
  .mt-xl-2 { margin-top: 0.5rem !important; }
  .mt-xl-3 { margin-top: 1rem !important; }
  .mt-xl-4 { margin-top: 1.5rem !important; }
  .mt-xl-5 { margin-top: 3rem !important; }
  .mt-xl-auto { margin-top: auto !important; }
  .me-xl-0 { margin-right: 0px !important; }
  .me-xl-1 { margin-right: 0.25rem !important; }
  .me-xl-2 { margin-right: 0.5rem !important; }
  .me-xl-3 { margin-right: 1rem !important; }
  .me-xl-4 { margin-right: 1.5rem !important; }
  .me-xl-5 { margin-right: 3rem !important; }
  .me-xl-auto { margin-right: auto !important; }
  .mb-xl-0 { margin-bottom: 0px !important; }
  .mb-xl-1 { margin-bottom: 0.25rem !important; }
  .mb-xl-2 { margin-bottom: 0.5rem !important; }
  .mb-xl-3 { margin-bottom: 1rem !important; }
  .mb-xl-4 { margin-bottom: 1.5rem !important; }
  .mb-xl-5 { margin-bottom: 3rem !important; }
  .mb-xl-auto { margin-bottom: auto !important; }
  .ms-xl-0 { margin-left: 0px !important; }
  .ms-xl-1 { margin-left: 0.25rem !important; }
  .ms-xl-2 { margin-left: 0.5rem !important; }
  .ms-xl-3 { margin-left: 1rem !important; }
  .ms-xl-4 { margin-left: 1.5rem !important; }
  .ms-xl-5 { margin-left: 3rem !important; }
  .ms-xl-auto { margin-left: auto !important; }
  .p-xl-0 { padding: 0px !important; }
  .p-xl-1 { padding: 0.25rem !important; }
  .p-xl-2 { padding: 0.5rem !important; }
  .p-xl-3 { padding: 1rem !important; }
  .p-xl-4 { padding: 1.5rem !important; }
  .p-xl-5 { padding: 3rem !important; }
  .px-xl-0 { padding-right: 0px !important; padding-left: 0px !important; }
  .px-xl-1 { padding-right: 0.25rem !important; padding-left: 0.25rem !impo=
rtant; }
  .px-xl-2 { padding-right: 0.5rem !important; padding-left: 0.5rem !import=
ant; }
  .px-xl-3 { padding-right: 1rem !important; padding-left: 1rem !important;=
 }
  .px-xl-4 { padding-right: 1.5rem !important; padding-left: 1.5rem !import=
ant; }
  .px-xl-5 { padding-right: 3rem !important; padding-left: 3rem !important;=
 }
  .py-xl-0 { padding-top: 0px !important; padding-bottom: 0px !important; }
  .py-xl-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !impo=
rtant; }
  .py-xl-2 { padding-top: 0.5rem !important; padding-bottom: 0.5rem !import=
ant; }
  .py-xl-3 { padding-top: 1rem !important; padding-bottom: 1rem !important;=
 }
  .py-xl-4 { padding-top: 1.5rem !important; padding-bottom: 1.5rem !import=
ant; }
  .py-xl-5 { padding-top: 3rem !important; padding-bottom: 3rem !important;=
 }
  .pt-xl-0 { padding-top: 0px !important; }
  .pt-xl-1 { padding-top: 0.25rem !important; }
  .pt-xl-2 { padding-top: 0.5rem !important; }
  .pt-xl-3 { padding-top: 1rem !important; }
  .pt-xl-4 { padding-top: 1.5rem !important; }
  .pt-xl-5 { padding-top: 3rem !important; }
  .pe-xl-0 { padding-right: 0px !important; }
  .pe-xl-1 { padding-right: 0.25rem !important; }
  .pe-xl-2 { padding-right: 0.5rem !important; }
  .pe-xl-3 { padding-right: 1rem !important; }
  .pe-xl-4 { padding-right: 1.5rem !important; }
  .pe-xl-5 { padding-right: 3rem !important; }
  .pb-xl-0 { padding-bottom: 0px !important; }
  .pb-xl-1 { padding-bottom: 0.25rem !important; }
  .pb-xl-2 { padding-bottom: 0.5rem !important; }
  .pb-xl-3 { padding-bottom: 1rem !important; }
  .pb-xl-4 { padding-bottom: 1.5rem !important; }
  .pb-xl-5 { padding-bottom: 3rem !important; }
  .ps-xl-0 { padding-left: 0px !important; }
  .ps-xl-1 { padding-left: 0.25rem !important; }
  .ps-xl-2 { padding-left: 0.5rem !important; }
  .ps-xl-3 { padding-left: 1rem !important; }
  .ps-xl-4 { padding-left: 1.5rem !important; }
  .ps-xl-5 { padding-left: 3rem !important; }
  .gap-xl-0 { gap: 0px !important; }
  .gap-xl-1 { gap: 0.25rem !important; }
  .gap-xl-2 { gap: 0.5rem !important; }
  .gap-xl-3 { gap: 1rem !important; }
  .gap-xl-4 { gap: 1.5rem !important; }
  .gap-xl-5 { gap: 3rem !important; }
  .text-xl-start { text-align: left !important; }
  .text-xl-end { text-align: right !important; }
  .text-xl-center { text-align: center !important; }
}

@media (min-width: 1400px) {
  .float-xxl-start { float: left !important; }
  .float-xxl-end { float: right !important; }
  .float-xxl-none { float: none !important; }
  .d-xxl-inline { display: inline !important; }
  .d-xxl-inline-block { display: inline-block !important; }
  .d-xxl-block { display: block !important; }
  .d-xxl-grid { display: grid !important; }
  .d-xxl-table { display: table !important; }
  .d-xxl-table-row { display: table-row !important; }
  .d-xxl-table-cell { display: table-cell !important; }
  .d-xxl-flex { display: flex !important; }
  .d-xxl-inline-flex { display: inline-flex !important; }
  .d-xxl-none { display: none !important; }
  .flex-xxl-fill { flex: 1 1 auto !important; }
  .flex-xxl-row { flex-direction: row !important; }
  .flex-xxl-column { flex-direction: column !important; }
  .flex-xxl-row-reverse { flex-direction: row-reverse !important; }
  .flex-xxl-column-reverse { flex-direction: column-reverse !important; }
  .flex-xxl-grow-0 { flex-grow: 0 !important; }
  .flex-xxl-grow-1 { flex-grow: 1 !important; }
  .flex-xxl-shrink-0 { flex-shrink: 0 !important; }
  .flex-xxl-shrink-1 { flex-shrink: 1 !important; }
  .flex-xxl-wrap { flex-wrap: wrap !important; }
  .flex-xxl-nowrap { flex-wrap: nowrap !important; }
  .flex-xxl-wrap-reverse { flex-wrap: wrap-reverse !important; }
  .justify-content-xxl-start { justify-content: flex-start !important; }
  .justify-content-xxl-end { justify-content: flex-end !important; }
  .justify-content-xxl-center { justify-content: center !important; }
  .justify-content-xxl-between { justify-content: space-between !important;=
 }
  .justify-content-xxl-around { justify-content: space-around !important; }
  .justify-content-xxl-evenly { justify-content: space-evenly !important; }
  .align-items-xxl-start { align-items: flex-start !important; }
  .align-items-xxl-end { align-items: flex-end !important; }
  .align-items-xxl-center { align-items: center !important; }
  .align-items-xxl-baseline { align-items: baseline !important; }
  .align-items-xxl-stretch { align-items: stretch !important; }
  .align-content-xxl-start { align-content: flex-start !important; }
  .align-content-xxl-end { align-content: flex-end !important; }
  .align-content-xxl-center { align-content: center !important; }
  .align-content-xxl-between { align-content: space-between !important; }
  .align-content-xxl-around { align-content: space-around !important; }
  .align-content-xxl-stretch { align-content: stretch !important; }
  .align-self-xxl-auto { align-self: auto !important; }
  .align-self-xxl-start { align-self: flex-start !important; }
  .align-self-xxl-end { align-self: flex-end !important; }
  .align-self-xxl-center { align-self: center !important; }
  .align-self-xxl-baseline { align-self: baseline !important; }
  .align-self-xxl-stretch { align-self: stretch !important; }
  .order-xxl-first { order: -1 !important; }
  .order-xxl-0 { order: 0 !important; }
  .order-xxl-1 { order: 1 !important; }
  .order-xxl-2 { order: 2 !important; }
  .order-xxl-3 { order: 3 !important; }
  .order-xxl-4 { order: 4 !important; }
  .order-xxl-5 { order: 5 !important; }
  .order-xxl-last { order: 6 !important; }
  .m-xxl-0 { margin: 0px !important; }
  .m-xxl-1 { margin: 0.25rem !important; }
  .m-xxl-2 { margin: 0.5rem !important; }
  .m-xxl-3 { margin: 1rem !important; }
  .m-xxl-4 { margin: 1.5rem !important; }
  .m-xxl-5 { margin: 3rem !important; }
  .m-xxl-auto { margin: auto !important; }
  .mx-xxl-0 { margin-right: 0px !important; margin-left: 0px !important; }
  .mx-xxl-1 { margin-right: 0.25rem !important; margin-left: 0.25rem !impor=
tant; }
  .mx-xxl-2 { margin-right: 0.5rem !important; margin-left: 0.5rem !importa=
nt; }
  .mx-xxl-3 { margin-right: 1rem !important; margin-left: 1rem !important; =
}
  .mx-xxl-4 { margin-right: 1.5rem !important; margin-left: 1.5rem !importa=
nt; }
  .mx-xxl-5 { margin-right: 3rem !important; margin-left: 3rem !important; =
}
  .mx-xxl-auto { margin-right: auto !important; margin-left: auto !importan=
t; }
  .my-xxl-0 { margin-top: 0px !important; margin-bottom: 0px !important; }
  .my-xxl-1 { margin-top: 0.25rem !important; margin-bottom: 0.25rem !impor=
tant; }
  .my-xxl-2 { margin-top: 0.5rem !important; margin-bottom: 0.5rem !importa=
nt; }
  .my-xxl-3 { margin-top: 1rem !important; margin-bottom: 1rem !important; =
}
  .my-xxl-4 { margin-top: 1.5rem !important; margin-bottom: 1.5rem !importa=
nt; }
  .my-xxl-5 { margin-top: 3rem !important; margin-bottom: 3rem !important; =
}
  .my-xxl-auto { margin-top: auto !important; margin-bottom: auto !importan=
t; }
  .mt-xxl-0 { margin-top: 0px !important; }
  .mt-xxl-1 { margin-top: 0.25rem !important; }
  .mt-xxl-2 { margin-top: 0.5rem !important; }
  .mt-xxl-3 { margin-top: 1rem !important; }
  .mt-xxl-4 { margin-top: 1.5rem !important; }
  .mt-xxl-5 { margin-top: 3rem !important; }
  .mt-xxl-auto { margin-top: auto !important; }
  .me-xxl-0 { margin-right: 0px !important; }
  .me-xxl-1 { margin-right: 0.25rem !important; }
  .me-xxl-2 { margin-right: 0.5rem !important; }
  .me-xxl-3 { margin-right: 1rem !important; }
  .me-xxl-4 { margin-right: 1.5rem !important; }
  .me-xxl-5 { margin-right: 3rem !important; }
  .me-xxl-auto { margin-right: auto !important; }
  .mb-xxl-0 { margin-bottom: 0px !important; }
  .mb-xxl-1 { margin-bottom: 0.25rem !important; }
  .mb-xxl-2 { margin-bottom: 0.5rem !important; }
  .mb-xxl-3 { margin-bottom: 1rem !important; }
  .mb-xxl-4 { margin-bottom: 1.5rem !important; }
  .mb-xxl-5 { margin-bottom: 3rem !important; }
  .mb-xxl-auto { margin-bottom: auto !important; }
  .ms-xxl-0 { margin-left: 0px !important; }
  .ms-xxl-1 { margin-left: 0.25rem !important; }
  .ms-xxl-2 { margin-left: 0.5rem !important; }
  .ms-xxl-3 { margin-left: 1rem !important; }
  .ms-xxl-4 { margin-left: 1.5rem !important; }
  .ms-xxl-5 { margin-left: 3rem !important; }
  .ms-xxl-auto { margin-left: auto !important; }
  .p-xxl-0 { padding: 0px !important; }
  .p-xxl-1 { padding: 0.25rem !important; }
  .p-xxl-2 { padding: 0.5rem !important; }
  .p-xxl-3 { padding: 1rem !important; }
  .p-xxl-4 { padding: 1.5rem !important; }
  .p-xxl-5 { padding: 3rem !important; }
  .px-xxl-0 { padding-right: 0px !important; padding-left: 0px !important; =
}
  .px-xxl-1 { padding-right: 0.25rem !important; padding-left: 0.25rem !imp=
ortant; }
  .px-xxl-2 { padding-right: 0.5rem !important; padding-left: 0.5rem !impor=
tant; }
  .px-xxl-3 { padding-right: 1rem !important; padding-left: 1rem !important=
; }
  .px-xxl-4 { padding-right: 1.5rem !important; padding-left: 1.5rem !impor=
tant; }
  .px-xxl-5 { padding-right: 3rem !important; padding-left: 3rem !important=
; }
  .py-xxl-0 { padding-top: 0px !important; padding-bottom: 0px !important; =
}
  .py-xxl-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !imp=
ortant; }
  .py-xxl-2 { padding-top: 0.5rem !important; padding-bottom: 0.5rem !impor=
tant; }
  .py-xxl-3 { padding-top: 1rem !important; padding-bottom: 1rem !important=
; }
  .py-xxl-4 { padding-top: 1.5rem !important; padding-bottom: 1.5rem !impor=
tant; }
  .py-xxl-5 { padding-top: 3rem !important; padding-bottom: 3rem !important=
; }
  .pt-xxl-0 { padding-top: 0px !important; }
  .pt-xxl-1 { padding-top: 0.25rem !important; }
  .pt-xxl-2 { padding-top: 0.5rem !important; }
  .pt-xxl-3 { padding-top: 1rem !important; }
  .pt-xxl-4 { padding-top: 1.5rem !important; }
  .pt-xxl-5 { padding-top: 3rem !important; }
  .pe-xxl-0 { padding-right: 0px !important; }
  .pe-xxl-1 { padding-right: 0.25rem !important; }
  .pe-xxl-2 { padding-right: 0.5rem !important; }
  .pe-xxl-3 { padding-right: 1rem !important; }
  .pe-xxl-4 { padding-right: 1.5rem !important; }
  .pe-xxl-5 { padding-right: 3rem !important; }
  .pb-xxl-0 { padding-bottom: 0px !important; }
  .pb-xxl-1 { padding-bottom: 0.25rem !important; }
  .pb-xxl-2 { padding-bottom: 0.5rem !important; }
  .pb-xxl-3 { padding-bottom: 1rem !important; }
  .pb-xxl-4 { padding-bottom: 1.5rem !important; }
  .pb-xxl-5 { padding-bottom: 3rem !important; }
  .ps-xxl-0 { padding-left: 0px !important; }
  .ps-xxl-1 { padding-left: 0.25rem !important; }
  .ps-xxl-2 { padding-left: 0.5rem !important; }
  .ps-xxl-3 { padding-left: 1rem !important; }
  .ps-xxl-4 { padding-left: 1.5rem !important; }
  .ps-xxl-5 { padding-left: 3rem !important; }
  .gap-xxl-0 { gap: 0px !important; }
  .gap-xxl-1 { gap: 0.25rem !important; }
  .gap-xxl-2 { gap: 0.5rem !important; }
  .gap-xxl-3 { gap: 1rem !important; }
  .gap-xxl-4 { gap: 1.5rem !important; }
  .gap-xxl-5 { gap: 3rem !important; }
  .text-xxl-start { text-align: left !important; }
  .text-xxl-end { text-align: right !important; }
  .text-xxl-center { text-align: center !important; }
}

@media print {
  .d-print-inline { display: inline !important; }
  .d-print-inline-block { display: inline-block !important; }
  .d-print-block { display: block !important; }
  .d-print-grid { display: grid !important; }
  .d-print-table { display: table !important; }
  .d-print-table-row { display: table-row !important; }
  .d-print-table-cell { display: table-cell !important; }
  .d-print-flex { display: flex !important; }
  .d-print-inline-flex { display: inline-flex !important; }
  .d-print-none { display: none !important; }
}

#page_content { margin: 0px 0.5em; }

h2 img, .h2 img { display: none; }

h2 a img, .h2 a img { display: inline; }

.data { margin: 0px 0px 12px; }

button.mult_submit, .checkall_box + label { text-decoration: none; color: r=
gb(35, 90, 129); cursor: pointer; outline: none; }

button.mult_submit:hover, button.mult_submit:focus { text-decoration: under=
line; color: rgb(35, 90, 129); }

.checkall_box + label:hover { text-decoration: underline; color: rgb(35, 90=
, 129); }

dfn { font-style: normal; }

dfn:hover { font-style: normal; cursor: help; }

a img { border: 0px; }

hr { color: rgb(68, 68, 68); background-color: rgb(68, 68, 68); border: 0px=
; height: 1px; }

form { padding: 0px; margin: 0px; display: inline; }

input, select { outline: none; }

input[type=3D"text"], input[type=3D"password"], input[type=3D"number"], inp=
ut[type=3D"date"] { border-radius: 2px; background: rgb(255, 255, 255); bor=
der: 1px solid rgb(170, 170, 170); color: rgb(85, 85, 85); padding: 4px; }

input:not(.form-control)[type=3D"text"], input:not(.form-control)[type=3D"p=
assword"], input:not(.form-control)[type=3D"number"], input[type=3D"date"],=
 input:not(.form-check-input)[type=3D"checkbox"] { margin: 6px; }

select:not(.form-select) { margin: 6px; }

input[type=3D"text"], input[type=3D"password"], input[type=3D"number"], inp=
ut[type=3D"date"] { transition: 0.2s; }

select { transition: 0.2s; }

input[type=3D"text"][disabled], input[type=3D"password"][disabled], input[t=
ype=3D"number"][disabled], input[type=3D"date"][disabled] { background: rgb=
(232, 232, 232); box-shadow: none; }

input[type=3D"text"][disabled]:hover, input[type=3D"password"][disabled]:ho=
ver, input[type=3D"number"][disabled]:hover, input[type=3D"date"][disabled]=
:hover { background: rgb(232, 232, 232); box-shadow: none; }

select[disabled] { background: rgb(232, 232, 232); box-shadow: none; }

select[disabled]:hover { background: rgb(232, 232, 232); box-shadow: none; =
}

input[type=3D"text"]:hover, input[type=3D"text"]:focus { border: 1px solid =
rgb(124, 124, 124); background: rgb(255, 255, 255); }

input[type=3D"password"]:hover, input[type=3D"password"]:focus { border: 1p=
x solid rgb(124, 124, 124); background: rgb(255, 255, 255); }

input[type=3D"number"]:hover, input[type=3D"number"]:focus { border: 1px so=
lid rgb(124, 124, 124); background: rgb(255, 255, 255); }

input[type=3D"date"]:hover, input[type=3D"date"]:focus { border: 1px solid =
rgb(124, 124, 124); background: rgb(255, 255, 255); }

select:focus { border: 1px solid rgb(124, 124, 124); background: rgb(255, 2=
55, 255); }

input[type=3D"text"]:hover, input[type=3D"password"]:hover, input[type=3D"n=
umber"]:hover, input[type=3D"date"]:hover { box-shadow: rgb(170, 170, 170) =
0px 1px 3px; }

textarea { overflow: visible; margin: 6px; }

textarea.char { margin: 6px; }

textarea.charField { width: 95%; }

.pma-fieldset { margin-top: 1em; border-radius: 4px 4px 0px 0px; border: 1p=
x solid rgb(170, 170, 170); padding: 0.5em; background: rgb(238, 238, 238);=
 box-shadow: rgb(255, 255, 255) 1px 1px 2px inset; }

.pma-fieldset .pma-fieldset { margin: 0.8em; border: 1px solid rgb(170, 170=
, 170); background: rgb(232, 232, 232); }

.pma-fieldset legend { float: none; font-weight: bold; color: rgb(68, 68, 6=
8); padding: 5px 10px; border-radius: 2px; border: 1px solid rgb(170, 170, =
170); background-color: rgb(255, 255, 255); max-width: 100%; box-shadow: rg=
b(187, 187, 187) 3px 3px 15px; width: initial; font-size: 1em; }

button { display: inline; }

.datatable { table-layout: fixed; }

img, button { vertical-align: middle; }

input:not(.form-check-input)[type=3D"checkbox"], input[type=3D"radio"] { ve=
rtical-align: -11%; }

select { border-radius: 2px; border: 1px solid rgb(187, 187, 187); color: r=
gb(51, 51, 51); padding: 3px; background: rgb(255, 255, 255); }

select:not(.form-select) { margin: 6px; }

select[multiple] { background: linear-gradient(rgb(255, 255, 255), rgb(242,=
 242, 242)); }

.clearfloat { clear: both; }

.paddingtop { padding-top: 1em; }

.separator { color: rgb(255, 255, 255); text-shadow: rgb(0, 0, 0) 0px 1px 0=
px; }

div.tools { padding: 0.2em; margin-top: 0px; margin-bottom: 0.5em; border-t=
op: 0px; text-align: right; float: none; clear: both; border-radius: 0px 0p=
x 4px 4px; }

div.tools a { color: rgb(58, 126, 173) !important; }

.pma-fieldset.tblFooters { margin-top: 0px; margin-bottom: 0.5em; border-to=
p: 0px; text-align: right; float: none; clear: both; border-radius: 0px 0px=
 4px 4px; }

div.null_div { height: 20px; text-align: center; font-style: normal; min-wi=
dth: 50px; }

.pma-fieldset .formelement { float: left; margin-right: 0.5em; white-space:=
 nowrap; }

.pma-fieldset div[class=3D"formelement"] { white-space: normal; }

button.mult_submit { border: none; background-color: rgba(0, 0, 0, 0); }

.condition { border-color: rgb(0, 0, 0) !important; }

th.condition { border-width: 1px 1px 0px; border-style: solid; }

td.condition { border-width: 0px 1px; border-style: solid; }

tr:last-child td.condition { border-width: 0px 1px 1px; }

.before-condition { border-right: 1px solid rgb(0, 0, 0); }

td.null { font-style: italic; color: rgb(125, 125, 125) !important; }

table .valueHeader, table .value { text-align: right; white-space: normal; =
}

.value { font-family: monospace; }

img.lightbulb { cursor: pointer; }

.pdflayout { overflow: hidden; clip: inherit; background-color: rgb(255, 25=
5, 255); display: none; border: 1px solid rgb(0, 0, 0); position: relative;=
 }

.pdflayout_table { background: rgb(211, 220, 227); color: rgb(0, 0, 0); ove=
rflow: hidden; clip: inherit; z-index: 2; display: inline; visibility: inhe=
rit; cursor: move; position: absolute; font-size: 80%; border: 1px dashed r=
gb(0, 0, 0); }

.cm-sql-doc { text-decoration: none; border-bottom: 1px dotted rgb(0, 0, 0)=
; color: inherit !important; }

.selectallarrow { margin-right: 0.3em; margin-left: 0.6em; }

.with-selected { margin-left: 2em; }

#pma_errors, #pma_demo, #pma_footer { position: relative; padding: 0px 0.5e=
m; }

.confirmation { color: rgb(0, 0, 0); background-color: pink; }

.error { padding: 0.27em; color: rgb(0, 0, 0); background: pink; border: 1p=
x solid maroon !important; }

.new_central_col { width: 100%; }

.tblcomment { font-size: 70%; font-weight: normal; color: rgb(0, 0, 153); }

.tblHeaders { font-weight: bold; color: rgb(0, 0, 0); background: rgb(211, =
220, 227); }

div.tools, .tblFooters { font-weight: normal; color: rgb(0, 0, 0); backgrou=
nd: rgb(211, 220, 227); }

.tblHeaders a:link, .tblHeaders a:active, .tblHeaders a:visited { color: bl=
ue; }

div.tools a:link, div.tools a:visited, div.tools a:active { color: blue; }

.tblFooters a:link, .tblFooters a:active, .tblFooters a:visited { color: bl=
ue; }

.tblHeaders a:hover, div.tools a:hover, .tblFooters a:hover { color: red; }

.disabled { color: rgb(102, 102, 102); }

.disabled a:link, .disabled a:active, .disabled a:visited { color: rgb(102,=
 102, 102); }

.disabled a:hover { color: rgb(102, 102, 102); text-decoration: none; }

.pre_wrap { white-space: pre-wrap; }

.pre_wrap br { display: none; }

body#loginform { margin: 1em 0px 0px; text-align: center; }

body#loginform h1, body#loginform .h1, body#loginform a.logo { display: blo=
ck; text-align: center; }

body#loginform div.container { text-align: left; width: 30em; margin: 0px a=
uto; }

#login_form .card-footer { text-align: right; }

div.container.modal_form { margin: 0px auto; width: 30em; text-align: cente=
r; background: rgb(255, 255, 255); z-index: 999; }

div#modalOverlay { position: fixed; top: 0px; left: 0px; height: 100%; widt=
h: 100%; background: rgb(255, 255, 255); z-index: 900; }

label.col-3.d-flex.align-items-center { font-weight: bolder; }

.commented_column { border-bottom: 1px dashed rgb(0, 0, 0); }

.column_attribute { font-size: 70%; }

.column_name { font-size: 80%; margin: 5px 2px; }

.central_columns_navigation { padding: 1.5% 0px !important; }

.message_errors_found { margin-top: 20px; }

.repl_gui_skip_err_cnt { width: 30px; }

.color_gray { color: gray; }

.max_height_400 { max-height: 400px; }

li.last.database { margin-bottom: 15px !important; }

div#dataDisplay input, div#dataDisplay select { margin: 0px 0.5em 0px 0px; =
}

div#dataDisplay th { line-height: 2em; }

img.calendar { border: none; }

form.clock { text-align: center; }

div#tablestatistics table { float: left; margin-bottom: 0.5em; margin-right=
: 1.5em; margin-top: 0.5em; min-width: 16em; }

#topmenucontainer { padding-right: 1em; width: 100%; }

#page_nav_icons { position: fixed; top: 0px; right: 0px; z-index: 99; paddi=
ng: 0.1rem 0px; }

#page_settings_icon { cursor: pointer; display: none; }

#page_settings_modal, #pma_navigation_settings { display: none; }

#textSQLDUMP { width: 95%; height: 95%; font-family: Consolas, "Courier New=
", Courier, monospace; font-size: 110%; }

#TooltipContainer { position: absolute; z-index: 99; width: 20em; height: a=
uto; overflow: visible; visibility: hidden; background-color: rgb(255, 255,=
 204); color: rgb(0, 102, 0); border: 0.1em solid rgb(0, 0, 0); padding: 0.=
5em; }

#fieldset_add_user_login div.item { display: flex; align-items: center; bor=
der-bottom: 1px solid silver; padding-bottom: 0.3em; margin-bottom: 0.3em; =
}

#fieldset_add_user_login label { float: left; display: block; width: 10em; =
max-width: 100%; text-align: right; padding-right: 0.5em; margin-bottom: 0p=
x; }

#fieldset_add_user_login input { width: 12em; clear: right; max-width: 100%=
; }

#fieldset_add_user_login span.options { float: left; display: block; width:=
 12em; max-width: 100%; padding-right: 0.5em; }

#fieldset_add_user_login span.options #select_pred_username, #fieldset_add_=
user_login span.options #select_pred_hostname, #fieldset_add_user_login spa=
n.options #select_pred_password { width: 100%; max-width: 100%; }

#fieldset_add_user_login span.options input { width: auto; }

#fieldset_user_priv div.item { float: left; width: 9em; max-width: 100%; }

#fieldset_user_priv div.item div.item { float: none; }

#fieldset_user_priv div.item label { white-space: nowrap; }

#fieldset_user_priv div.item select { width: 100%; }

#fieldset_user_global_rights .pma-fieldset, #fieldset_user_group_rights .pm=
a-fieldset { float: left; }

#fieldset_user_global_rights > legend input { margin-left: 2em; }

.linkElem:hover { text-decoration: underline; color: rgb(35, 90, 129); curs=
or: pointer; }

h3#serverstatusqueries span, #serverstatusqueries.h3 span { font-size: 60%;=
 display: inline; }

div#serverStatusTabs { margin-top: 1em; }

caption a.top { float: right; }

div#serverstatusquerieschart { float: left; width: 500px; height: 350px; ma=
rgin-right: 50px; }

div#serverstatus table tbody td.descr a, div#serverstatus table .tblFooters=
 a { white-space: nowrap; }

div.liveChart { clear: both; min-width: 500px; height: 400px; padding-botto=
m: 80px; }

div#chartVariableSettings { border: 1px solid rgb(221, 221, 221); backgroun=
d-color: rgb(230, 230, 230); margin-left: 10px; }

table#chartGrid td { padding: 3px; margin: 0px; }

table#chartGrid div.monitorChart { background: rgb(235, 235, 235); border: =
none; min-width: 1px; }

div.tabLinks { float: left; padding: 5px 0px; }

div.tabLinks a, div.tabLinks label { margin-right: 7px; }

div.tabLinks .icon { margin: -0.2em 0.3em 0px 0px; }

.popupContent { display: none; position: absolute; border: 1px solid rgb(20=
4, 204, 204); margin: 0px; padding: 3px; background-color: rgb(255, 255, 25=
5); z-index: 2; box-shadow: rgb(102, 102, 102) 2px 2px 3px; }

div#logTable { padding-top: 10px; clear: both; }

div#logTable table { width: 100%; }

div#queryAnalyzerDialog { min-width: 700px; }

div#queryAnalyzerDialog div.CodeMirror-scroll { height: auto; }

div#queryAnalyzerDialog div#queryProfiling { height: 300px; }

div#queryAnalyzerDialog td.explain { width: 250px; }

div#queryAnalyzerDialog table.queryNums { display: none; border: 0px; text-=
align: left; }

.smallIndent { padding-left: 7px; }

div#profilingchart { width: 850px; height: 370px; float: left; }

#profilingchart .jqplot-highlighter-tooltip { left: 11px; bottom: 24px; top=
: auto !important; }

#resizer { border: 1px solid silver; }

#inner-resizer { padding: 10px; }

#togglequerybox { margin: 0px 10px; }

#serverstatus h3, #serverstatus .h3 { margin: 15px 0px; font-weight: normal=
; color: rgb(153, 153, 153); font-size: 1.7em; }

textarea#sqlquery { width: 100%; border-radius: 4px; border: 1px solid rgb(=
170, 170, 170); padding: 5px; font-family: inherit; }

textarea#sql_query_edit { height: 7em; width: 95%; display: block; }

#mysqlmaininformation, #pmamaininformation { float: left; width: 49%; }

#maincontainer ul { list-style-type: disc; vertical-align: middle; }

#maincontainer li { margin-bottom: 0.3em; }

#full_name_layer { position: absolute; padding: 2px; margin-top: -3px; z-in=
dex: 801; border-radius: 3px; border: 1px solid rgb(136, 136, 136); backgro=
und: rgb(255, 255, 255); }

#body_browse_foreigners { background: rgb(243, 243, 243); margin: 0.5em 0.5=
em 0px; }

#bodythemes { width: 500px; margin: auto; text-align: center; }

#bodythemes img { border: 0.1em solid rgb(0, 0, 0); }

#bodythemes a:hover img { border: 0.1em solid red; }

#selflink { clear: both; display: block; margin-top: 1em; margin-bottom: 1e=
m; width: 98%; margin-left: 1%; text-align: right; border-top: 0.1em solid =
silver; }

#qbe_div_table_list, #qbe_div_sql_query { float: left; }

kbd { color: rgb(68, 68, 68); background-color: rgba(0, 0, 0, 0); box-shado=
w: none; }

code { font-size: 1em; color: rgb(68, 68, 68); }

code.php { display: block; padding-left: 1em; margin-top: 0px; margin-botto=
m: 0px; max-height: 10em; overflow: auto; direction: ltr; }

code.sql { display: block; padding: 1em; margin-top: 0px; margin-bottom: 0p=
x; max-height: 10em; overflow: auto; direction: ltr; }

div.sqlvalidate { display: block; padding: 1em; margin-top: 0px; margin-bot=
tom: 0px; max-height: 10em; overflow: auto; direction: ltr; }

.result_query div.sqlOuter { background: rgb(229, 229, 229); text-align: le=
ft; }

#PMA_slidingMessage code.sql, div.sqlvalidate { background: rgb(229, 229, 2=
29); }

textarea#partitiondefinition { height: 3em; }

.hide { display: none; }

#list_server { list-style-type: none; padding: 0px; }

div.upload_progress { width: 400px; margin: 3em auto; text-align: center; }

div.upload_progress_bar_outer { border: 1px solid rgb(0, 0, 0); width: 202p=
x; position: relative; margin: 0px auto 1em; color: rgb(68, 68, 68); }

div.upload_progress_bar_outer div.percentage { position: absolute; top: 0px=
; left: 0px; width: 202px; }

div.upload_progress_bar_inner { background-color: rgb(221, 221, 221); width=
: 0px; height: 12px; margin: 1px; overflow: hidden; color: rgb(0, 0, 0); po=
sition: relative; }

div.upload_progress_bar_inner div.percentage { top: -1px; left: -1px; }

div#statustext { margin-top: 0.5em; }

table#serverconnection_src_remote, table#serverconnection_trg_remote, table=
#serverconnection_src_local, table#serverconnection_trg_local { float: left=
; }

input[type=3D"text"].invalid_value, input[type=3D"password"].invalid_value,=
 input[type=3D"number"].invalid_value, input[type=3D"date"].invalid_value {=
 background: rgb(255, 204, 204); }

select.invalid_value, .invalid_value { background: rgb(255, 204, 204); }

.ajax_notification { top: 0px; position: fixed; margin: 200px auto 0px; pad=
ding: 5px; width: 350px; z-index: 1100; text-align: center; display: inline=
; left: 0px; right: 0px; background-image: url("../img/ajax_clock_small.gif=
"); background-repeat: no-repeat; background-position: 2% center; border: 1=
px solid rgb(226, 183, 9); background-color: rgb(255, 229, 126); border-rad=
ius: 5px; box-shadow: rgb(136, 136, 136) 0px 5px 90px; }

#loading_parent { position: relative; width: 100%; }

input#import_merge { margin: 0px; }

#popup_background { display: none; position: fixed; width: 100%; height: 10=
0%; top: 0px; left: 0px; background: rgb(0, 0, 0); z-index: 1000; overflow:=
 hidden; }

#structure-action-links a { margin-right: 1em; }

#addColumns input[type=3D"radio"] { margin: 3px 0px 0px 1em; }

#index_frm .index_info input[type=3D"text"], #index_frm .index_info select =
{ width: 100%; margin: 0px; box-sizing: border-box; }

#index_frm .index_info div { padding: 0.2em 0px; }

#index_frm .index_info .label { float: left; min-width: 12em; }

#index_frm .slider { width: 10em; margin: 0.6em; float: left; }

#index_frm .add_fields { float: left; }

#index_frm .add_fields input { margin-left: 1em; }

#index_frm input { margin: 0px; }

#index_frm td { vertical-align: middle; }

table#index_columns { width: 100%; }

table#index_columns select { width: 85%; float: left; }

#move_columns_dialog div { padding: 1em; }

#move_columns_dialog ul { list-style: none; margin: 0px; padding: 0px; }

#move_columns_dialog li { background: rgb(211, 220, 227); border: 1px solid=
 rgb(170, 170, 170); color: rgb(0, 0, 0); font-weight: bold; margin: 0.4em;=
 padding: 0.2em; border-radius: 2px; }

.config-form .card { margin-top: 0px; border-top-left-radius: 0px; border-t=
op-right-radius: 0px; }

.config-form fieldset { margin-top: 0px; padding: 0px; clear: both; border-=
radius: 0px; }

.config-form fieldset p { margin: 0px; padding: 0.5em; background: rgb(255,=
 255, 255); border-top: 0px; }

.config-form fieldset .errors { margin: 0px -2px 1em; padding: 0.5em 1.5em;=
 background: rgb(251, 234, 217); list-style: none; font-family: sans-serif;=
 font-size: small; }

.config-form fieldset .inline_errors { margin: 0.3em 0.3em 0.3em 0px; paddi=
ng: 0px; list-style: none; color: rgb(154, 0, 0); font-size: small; }

.config-form fieldset .doc { margin-left: 1em; }

.config-form fieldset .disabled-notice { margin-left: 1em; font-size: 80%; =
text-transform: uppercase; color: rgb(238, 0, 0); cursor: help; }

.config-form fieldset th { padding: 0.3em 0.3em 0.3em 0.5em; text-align: le=
ft; vertical-align: top; background: rgba(0, 0, 0, 0); filter: none; border=
-top: 1px solid rgb(213, 213, 213); border-right: none; }

.config-form fieldset th small, .config-form fieldset th .small { display: =
block; font-weight: normal; font-family: sans-serif; font-size: x-small; co=
lor: rgb(68, 68, 68); }

.config-form fieldset td { padding-top: 0.3em; padding-bottom: 0.3em; verti=
cal-align: top; border-top: 1px solid rgb(213, 213, 213); border-right: non=
e; }

.config-form legend { display: none; }

.config-form span.checkbox { padding: 2px; display: inline-block; }

.config-form span.checkbox.custom { padding: 1px; border: 1px solid rgb(237=
, 236, 144); background: rgb(255, 255, 204); }

.config-form .custom { background: rgb(255, 255, 204); }

.config-form .field-error { border-color: rgb(170, 17, 17) !important; }

.config-form input[type=3D"text"], .config-form input[type=3D"password"], .=
config-form input[type=3D"number"] { border: 1px solid rgb(167, 166, 170); =
height: auto; }

.config-form input[type=3D"text"]:focus, .config-form input[type=3D"passwor=
d"]:focus, .config-form input[type=3D"number"]:focus { border: 1px solid rg=
b(102, 118, 255); background: rgb(247, 251, 255); }

.config-form select, .config-form textarea { border: 1px solid rgb(167, 166=
, 170); height: auto; }

.config-form select:focus, .config-form textarea:focus { border: 1px solid =
rgb(102, 118, 255); background: rgb(247, 251, 255); }

.config-form .field-comment-mark { font-family: serif; color: rgb(0, 0, 119=
); cursor: help; padding: 0px 0.2em; font-weight: bold; font-style: italic;=
 }

.config-form .field-comment-warning { color: rgb(170, 0, 0); }

.config-form dd { margin-left: 0.5em; }

.config-form dd::before { content: "=E2=96=B8 "; }

fieldset .group-header th { background: rgb(213, 213, 213); }

fieldset .group-header + tr th { padding-top: 0.6em; }

fieldset .group-field-1 th, fieldset .group-header-2 th { padding-left: 1.5=
em; }

fieldset .group-field-2 th, fieldset .group-header-3 th { padding-left: 3em=
; }

fieldset .group-field-3 th { padding-left: 4.5em; }

fieldset .disabled-field th { color: rgb(102, 102, 102); background-color: =
rgb(221, 221, 221); }

fieldset .disabled-field th small, fieldset .disabled-field th .small { col=
or: rgb(102, 102, 102); background-color: rgb(221, 221, 221); }

fieldset .disabled-field td { color: rgb(102, 102, 102); background-color: =
rgb(221, 221, 221); }

.click-hide-message { cursor: pointer; }

.prefsmanage_opts { margin-left: 2em; }

#prefs_autoload { margin-bottom: 0.5em; margin-left: 0.5em; }

input#auto_increment_opt { width: min-content; }

#placeholder { position: relative; border: 1px solid rgb(170, 170, 170); fl=
oat: right; overflow: hidden; width: 450px; height: 300px; }

#placeholder .button { position: absolute; cursor: pointer; }

#placeholder div.button { font-size: smaller; color: rgb(153, 153, 153); ba=
ckground-color: rgb(238, 238, 238); padding: 2px; }

.wrapper { float: left; margin-bottom: 1.5em; }

.toggleButton { position: relative; cursor: pointer; font-size: 0.8em; text=
-align: center; line-height: 1.4em; height: 1.55em; overflow: hidden; borde=
r-right: 0.1em solid rgb(136, 136, 136); border-left: 0.1em solid rgb(136, =
136, 136); border-radius: 0.3em; }

.toggleButton table, .toggleButton td, .toggleButton img { padding: 0px; po=
sition: relative; }

.toggleButton .toggle-container { position: absolute; }

.toggleButton .toggle-container td, .toggleButton .toggle-container tr { ba=
ckground: none !important; }

.toggleButton .toggleOn { color: rgb(255, 255, 255); padding: 0px 1em; text=
-shadow: rgb(0, 0, 0) 0px 0px 0.2em; }

.toggleButton .toggleOff { padding: 0px 1em; }

.doubleFieldset .pma-fieldset { width: 48%; float: left; padding: 0px; }

.doubleFieldset legend { margin-left: 1.5em; }

.doubleFieldset div.wrap { padding: 1.5em; }

#table_name_col_no_outer { margin-top: 45px; }

#table_name_col_no { position: fixed; top: 55px; width: 100%; background: r=
gb(255, 255, 255); }

#table_columns { display: block; overflow: auto; }

#table_columns input[type=3D"text"], #table_columns input[type=3D"password"=
], #table_columns input[type=3D"number"] { width: 10em; box-sizing: border-=
box; }

#table_columns select { width: 10em; box-sizing: border-box; }

#openlayersmap { width: 450px; height: 300px; }

.placeholderDrag { cursor: move; }

#left_arrow { left: 8px; top: 26px; }

#right_arrow { left: 26px; top: 26px; }

#up_arrow { left: 17px; top: 8px; }

#down_arrow { left: 17px; top: 44px; }

#zoom_in { left: 17px; top: 67px; }

#zoom_world { left: 17px; top: 85px; }

#zoom_out { left: 17px; top: 103px; }

.colborder { cursor: col-resize; height: 100%; margin-left: -6px; position:=
 absolute; width: 5px; }

.colborder_active { border-right: 2px solid rgb(170, 68, 68); }

.pma_table th.draggable span { display: block; overflow: hidden; }

.pma_table td { position: static; }

.pma_table tbody td span { display: block; overflow: hidden; }

.pma_table tbody td span code span { display: inline; }

.pma_table th.draggable span { margin-right: 10px; }

.modal-copy input { display: block; width: 100%; margin-top: 1.5em; padding=
: 0.3em 0px; }

.cRsz { position: absolute; }

.cCpy { background: rgb(51, 51, 51); color: rgb(255, 255, 255); font-weight=
: bold; margin: 0.1em; padding: 0.3em; position: absolute; text-shadow: rgb=
(0, 0, 0) -1px -1px; box-shadow: rgb(0, 0, 0) 0px 0px 0.7em; border-radius:=
 0.3em; }

.cPointer { height: 20px; width: 10px; margin-top: -10px; margin-left: -5px=
; background: url("../img/col_pointer.png"); position: absolute; }

.tooltip { z-index: 9999; background: rgb(51, 51, 51) !important; opacity: =
0.8 !important; border: 1px solid rgb(0, 0, 0) !important; border-radius: 0=
.3em !important; text-shadow: rgb(0, 0, 0) -1px -1px !important; font-size:=
 0.8em !important; font-weight: bold !important; padding: 1px 3px !importan=
t; }

.tooltip * { background: none !important; color: rgb(255, 255, 255) !import=
ant; }

.cDrop { right: 0px; position: absolute; top: 0px; }

.coldrop { background: url("../img/col_drop.png"); cursor: pointer; height:=
 16px; margin-top: 0.3em; width: 16px; }

.coldrop:hover { background-color: rgb(153, 153, 153); }

.coldrop-hover { background-color: rgb(153, 153, 153); }

.cList { background: rgb(238, 238, 238); border: 1px solid rgb(153, 153, 15=
3); position: absolute; box-shadow: rgb(51, 51, 51) 0px 0.2em 0.5em; margin=
-left: 75%; right: 0px; max-width: 100%; overflow-wrap: break-word; }

.cList .lDiv div { padding: 0.2em 0.5em 0.2em 0.2em; white-space: nowrap; }

.cList .lDiv div:hover { background: rgb(221, 221, 221); cursor: pointer; }

.cList .lDiv div input { cursor: pointer; }

.showAllColBtn { border-bottom: 1px solid rgb(153, 153, 153); border-top: 1=
px solid rgb(153, 153, 153); cursor: pointer; font-size: 0.9em; font-weight=
: bold; padding: 0.35em 1em; text-align: center; }

.showAllColBtn:hover { background: rgb(221, 221, 221); }

.turnOffSelect { user-select: none; }

.navigation { margin: 0.8em 0px; border-radius: 5px; background: linear-gra=
dient(rgb(238, 238, 238), rgb(204, 204, 204)); }

.navigation td { margin: 0px; padding: 0px; vertical-align: middle; white-s=
pace: nowrap; }

.navigation input[type=3D"submit"] { background: none; border: 0px; filter:=
 none; margin: 0px; padding: 0.8em 0.5em; border-radius: 0px; }

.navigation input[type=3D"submit"]:hover { color: rgb(255, 255, 255); curso=
r: pointer; text-shadow: none; background: linear-gradient(rgb(51, 51, 51),=
 rgb(85, 85, 85)); }

.navigation input.edit_mode_active { color: rgb(255, 255, 255); cursor: poi=
nter; text-shadow: none; background: linear-gradient(rgb(51, 51, 51), rgb(8=
5, 85, 85)); }

.navigation .btn-link { color: rgb(68, 68, 68); }

.navigation .btn-link:hover { color: rgb(255, 255, 255); background-image: =
linear-gradient(rgb(51, 51, 51), rgb(85, 85, 85)); text-decoration: none; }

.navigation select { margin: 0px 0.8em; }

.navigation_separator { color: rgb(153, 153, 153); display: inline-block; f=
ont-size: 1.5em; text-align: center; height: 1.4em; width: 1.2em; text-shad=
ow: rgb(255, 255, 255) 1px 0px; }

.cEdit { margin: 0px; padding: 0px; position: absolute; }

.cEdit input[type=3D"text"] { background: rgb(255, 255, 255); height: 100%;=
 margin: 0px; padding: 0px; }

.cEdit .edit_area { background: rgb(255, 255, 255); border: 1px solid rgb(1=
53, 153, 153); min-width: 10em; padding: 0.3em 0.5em; }

.cEdit .edit_area select, .cEdit .edit_area textarea { width: 97%; }

.cEdit .cell_edit_hint { color: rgb(85, 85, 85); font-size: 0.8em; margin: =
0.3em 0.2em; }

.cEdit .edit_box { overflow: hidden scroll; padding: 3px; margin: 0px; }

.cEdit .edit_box_posting { background: url("../img/ajax_clock_small.gif") r=
ight center no-repeat rgb(255, 255, 255); padding-right: 1.5em; }

.cEdit .edit_area_loading { background: url("../img/ajax_clock_small.gif") =
center center no-repeat rgb(255, 255, 255); height: 10em; }

.cEdit .goto_link { background: rgb(238, 238, 238); color: rgb(85, 85, 85);=
 padding: 0.2em 0.3em; }

.saving_edited_data { background: url("../img/ajax_clock_small.gif") left c=
enter no-repeat; padding-left: 20px; }

.relationalTable td { vertical-align: top; }

.relationalTable select { width: 125px; margin-right: 5px; }

.ui-timepicker-div .ui-widget-header { margin-bottom: 8px; }

.ui-timepicker-div dl { text-align: left; }

.ui-timepicker-div dl dt { height: 25px; margin-bottom: -25px; }

.ui-timepicker-div dl dd { margin: 0px 10px 10px 85px; }

.ui-timepicker-div td { font-size: 90%; }

.ui-tpicker-grid-label { background: none; border: none; margin: 0px; paddi=
ng: 0px; }

.ui-timepicker-rtl { direction: rtl; }

.ui-timepicker-rtl dl { text-align: right; }

.ui-timepicker-rtl dl dd { margin: 0px 65px 10px 10px; }

body .ui-widget { font-size: 1em; }

body #ui-datepicker-div { z-index: 9999 !important; }

.ui-dialog .pma-fieldset legend a { color: rgb(35, 90, 129); }

.ui-draggable { z-index: 801; }

.jqplot-yaxis { min-width: 25px; width: auto; left: 0px !important; }

.jqplot-axis { overflow: hidden; }

div#page_content div#tableslistcontainer { margin-top: 1em; }

div#page_content div#tableslistcontainer table.data { border-top: 0.1px sol=
id rgb(238, 238, 238); }

div#page_content div.result_query { margin-top: 1em; }

table.show_create { margin-top: 1em; }

table.show_create td { border-right: 1px solid rgb(187, 187, 187); }

#alias_modal table { width: 100%; }

#alias_modal label { font-weight: bold; }

.ui-dialog { position: fixed; }

.small_font { font-size: smaller; }

#pma_console_container { width: 100%; position: fixed; bottom: 0px; left: 0=
px; z-index: 100; }

textarea { resize: both; }

#pma_console { position: relative; margin-left: 240px; }

#pma_console .templates { display: none; }

#pma_console .mid_text { vertical-align: middle; }

#pma_console .toolbar { position: relative; background: rgb(204, 204, 204);=
 border-top: 1px solid rgb(170, 170, 170); cursor: n-resize; }

#pma_console .toolbar span { vertical-align: middle; }

#pma_console .toolbar.collapsed { cursor: default; }

#pma_console .toolbar.collapsed:not(:hover) { display: inline-block; border=
-top-right-radius: 3px; border-right: 1px solid rgb(170, 170, 170); }

#pma_console .toolbar.collapsed > .button { display: none; }

#pma_console .message span.text, #pma_console .message span.action { paddin=
g: 0px 3px; display: inline-block; }

#pma_console .toolbar .button, #pma_console .toolbar .text { padding: 0px 3=
px; display: inline-block; }

#pma_console .switch_button { padding: 0px 3px; display: inline-block; }

#pma_console .message span.action, #pma_console .toolbar .button, #pma_cons=
ole .switch_button { cursor: pointer; }

#pma_console .message span.action:hover, #pma_console .toolbar .button:hove=
r, #pma_console .switch_button:hover { background: rgb(221, 221, 221); }

#pma_console .toolbar .button.active { background: rgb(221, 221, 221); }

#pma_console .toolbar .text { font-weight: bold; }

#pma_console .toolbar .button, #pma_console .toolbar .text { margin-right: =
0.4em; }

#pma_console .toolbar .button, #pma_console .toolbar .text { float: right; =
}

#pma_console .content { overflow: hidden auto; margin-bottom: -65px; border=
-top: 1px solid rgb(170, 170, 170); background: rgb(255, 255, 255); padding=
-top: 0.4em; }

#pma_console .content.console_dark_theme { background: rgb(0, 0, 0); color:=
 rgb(255, 255, 255); }

#pma_console .content.console_dark_theme .CodeMirror-wrap { background: rgb=
(0, 0, 0); color: rgb(255, 255, 255); }

#pma_console .content.console_dark_theme .action_content { color: rgb(0, 0,=
 0); }

#pma_console .content.console_dark_theme .message { border-color: rgb(55, 5=
9, 65); }

#pma_console .content.console_dark_theme .CodeMirror-cursor { border-color:=
 rgb(255, 255, 255); }

#pma_console .content.console_dark_theme .cm-keyword { color: rgb(222, 147,=
 95); }

#pma_console .message, #pma_console .query_input { position: relative; font=
-family: Monaco, Consolas, monospace; cursor: text; margin: 0px 10px 0.2em =
1.4em; }

#pma_console .message { border-bottom: 1px solid rgb(204, 204, 204); paddin=
g-bottom: 0.2em; }

#pma_console .message.expanded > .action_content { position: relative; }

#pma_console .message::before { left: -0.7em; position: absolute; content: =
">"; }

#pma_console .query_input::before { left: -0.7em; position: absolute; conte=
nt: ">"; top: -2px; }

#pma_console .query_input textarea { width: 100%; height: 4em; resize: vert=
ical; }

#pma_console .message:hover::before { color: rgb(119, 204, 255); font-weigh=
t: bold; }

#pma_console .message.expanded::before { content: "]"; }

#pma_console .message.welcome::before { display: none; }

#pma_console .message.failed::before, #pma_console .message.failed.expanded=
::before, #pma_console .message.failed:hover::before { content: "=3D"; colo=
r: rgb(153, 68, 68); }

#pma_console .message.pending::before { opacity: 0.3; }

#pma_console .message.collapsed > .query { white-space: nowrap; text-overfl=
ow: ellipsis; overflow: hidden; }

#pma_console .message.expanded > .query { display: block; white-space: pre;=
 overflow-wrap: break-word; }

#pma_console .message .text.targetdb, #pma_console .message.collapsed .acti=
on.collapse, #pma_console .message.expanded .action.expand { display: none;=
 }

#pma_console .message .action.requery, #pma_console .message .action.profil=
ing, #pma_console .message .action.explain, #pma_console .message .action.b=
ookmark { display: none; }

#pma_console .message.select .action.profiling, #pma_console .message.selec=
t .action.explain { display: inline-block; }

#pma_console .message.history .text.targetdb, #pma_console .message.success=
ed .text.targetdb { display: inline-block; }

#pma_console .message.history .action.requery, #pma_console .message.histor=
y .action.bookmark { display: inline-block; }

#pma_console .message.bookmark .action.requery, #pma_console .message.bookm=
ark .action.bookmark { display: inline-block; }

#pma_console .message.successed .action.requery, #pma_console .message.succ=
essed .action.bookmark { display: inline-block; }

#pma_console .message .action_content { position: absolute; bottom: 100%; b=
ackground: rgb(204, 204, 204); border: 1px solid rgb(170, 170, 170); border=
-top-left-radius: 3px; }

#pma_console .message.bookmark .text.targetdb, #pma_console .message .text.=
query_time { margin: 0px; display: inline-block; }

#pma_console .message.failed .text.query_time, #pma_console .message .text.=
failed { display: none; }

#pma_console .message.failed .text.failed { display: inline-block; }

#pma_console .message .text { background: rgb(255, 255, 255); }

#pma_console .message.collapsed > .action_content { display: none; }

#pma_console .message.collapsed:hover > .action_content { display: block; }

#pma_console .message .bookmark_label { padding: 0px 4px; top: 0px; backgro=
und: rgb(51, 102, 153); color: rgb(255, 255, 255); border-radius: 3px; }

#pma_console .message .bookmark_label.shared { background: rgb(51, 153, 102=
); }

#pma_console .message.expanded .bookmark_label { border-top-left-radius: 0p=
x; border-top-right-radius: 0px; }

#pma_console .query_input { position: relative; }

#pma_console .mid_layer { height: 100%; width: 100%; position: absolute; to=
p: 0px; background: rgb(102, 102, 102); display: none; cursor: pointer; z-i=
ndex: 200; }

#pma_console .card { position: absolute; width: 94%; height: 100%; min-heig=
ht: 48px; left: 100%; top: 0px; border-left: 1px solid rgb(153, 153, 153); =
z-index: 300; transition: left 0.2s; }

#pma_console .card.show { left: 6%; box-shadow: rgb(153, 153, 153) -2px 1px=
 4px -1px; }

#pma_console .button.hide, #pma_console .message span.text.hide { display: =
none; }

#pma_bookmarks .content.add_bookmark, #pma_console_options .content { paddi=
ng: 4px 6px; }

#pma_bookmarks .content.add_bookmark .options { margin-left: 1.4em; padding=
-bottom: 0.4em; margin-bottom: 0.4em; border-bottom: 1px solid rgb(204, 204=
, 204); }

#pma_bookmarks .content.add_bookmark .options button { margin: 0px 7px; ver=
tical-align: bottom; }

#pma_bookmarks .content.add_bookmark input[type=3D"text"] { margin: 0px; pa=
dding: 2px 4px; }

#debug_console.grouped .ungroup_queries { display: inline-block; }

#debug_console.ungrouped .group_queries { display: inline-block; }

#debug_console.ungrouped .ungroup_queries, #debug_console.ungrouped .sort_c=
ount { display: none; }

#debug_console.grouped .group_queries { display: none; }

#debug_console .count { margin-right: 8px; }

#debug_console .show_trace .trace, #debug_console .show_args .args { displa=
y: block; }

#debug_console .hide_trace .trace, #debug_console .hide_args .args, #debug_=
console .show_trace .action.dbg_show_trace, #debug_console .hide_trace .act=
ion.dbg_hide_trace { display: none; }

#debug_console .traceStep.hide_args .action.dbg_hide_args, #debug_console .=
traceStep.show_args .action.dbg_show_args { display: none; }

#debug_console .traceStep::after { content: ""; display: table; clear: both=
; }

#debug_console .trace.welcome::after, #debug_console .debug > .welcome::aft=
er { content: ""; display: table; clear: both; }

#debug_console .debug_summary { float: left; }

#debug_console .trace.welcome .time, #debug_console .traceStep .file, #debu=
g_console .script_name { float: right; }

#debug_console .traceStep .args pre { margin: 0px; }

.cm-s-pma .CodeMirror-code { font-family: Monaco, Consolas, monospace; }

.cm-s-pma .CodeMirror-code pre { font-family: Monaco, Consolas, monospace; =
}

.cm-s-pma .CodeMirror-measure > pre, .cm-s-pma .CodeMirror-code > pre, .cm-=
s-pma .CodeMirror-lines { padding: 0px; }

.cm-s-pma.CodeMirror { resize: none; height: auto; width: 100%; min-height:=
 initial; max-height: initial; }

.cm-s-pma .CodeMirror-scroll { cursor: text; }

.pma_drop_handler { display: none; position: fixed; top: 0px; left: 0px; wi=
dth: 100%; background: rgba(0, 0, 0, 0.6); height: 100%; z-index: 999; colo=
r: rgb(255, 255, 255); font-size: 30pt; text-align: center; padding-top: 20=
%; }

.pma_sql_import_status { display: none; position: fixed; bottom: 0px; right=
: 25px; width: 400px; border: 1px solid rgb(153, 153, 153); background: rgb=
(243, 243, 243); border-radius: 4px; box-shadow: rgb(204, 204, 204) 2px 2px=
 5px; }

.pma_sql_import_status h2, .pma_sql_import_status .h2 { background-color: r=
gb(187, 187, 187); padding: 0.1em 0.3em; margin-top: 0px; margin-bottom: 0p=
x; color: rgb(255, 255, 255); font-size: 1.6em; font-weight: normal; text-s=
hadow: rgb(119, 119, 119) 0px 1px 0px; box-shadow: rgb(153, 153, 153) 1px 1=
px 15px inset; }

.pma_drop_result h2, .pma_drop_result .h2 { background-color: rgb(187, 187,=
 187); padding: 0.1em 0.3em; margin-top: 0px; margin-bottom: 0px; color: rg=
b(255, 255, 255); font-size: 1.6em; font-weight: normal; text-shadow: rgb(1=
19, 119, 119) 0px 1px 0px; box-shadow: rgb(153, 153, 153) 1px 1px 15px inse=
t; }

.pma_sql_import_status div { height: 270px; overflow: hidden auto; list-sty=
le-type: none; }

.pma_sql_import_status div li { padding: 8px 10px; border-bottom: 1px solid=
 rgb(187, 187, 187); color: rgb(148, 14, 14); background: rgb(255, 255, 255=
); }

.pma_sql_import_status div li .filesize { float: right; }

.pma_sql_import_status h2 .minimize, .pma_sql_import_status .h2 .minimize {=
 float: right; margin-right: 5px; padding: 0px 10px; }

.pma_sql_import_status h2 .close, .pma_sql_import_status .h2 .close { float=
: right; margin-right: 5px; padding: 0px 10px; display: none; }

.pma_sql_import_status h2 .minimize:hover, .pma_sql_import_status .h2 .mini=
mize:hover, .pma_sql_import_status h2 .close:hover, .pma_sql_import_status =
.h2 .close:hover { background: rgba(155, 149, 149, 0.78); cursor: pointer; =
}

.pma_drop_result h2 .close:hover, .pma_drop_result .h2 .close:hover { backg=
round: rgba(155, 149, 149, 0.78); cursor: pointer; }

.pma_drop_file_status { color: rgb(35, 90, 129); }

.pma_drop_file_status span.underline:hover { cursor: pointer; text-decorati=
on: underline; }

.pma_drop_result { position: fixed; top: 10%; left: 20%; width: 60%; backgr=
ound: rgb(255, 255, 255); min-height: 300px; z-index: 800; box-shadow: rgb(=
153, 153, 153) 0px 0px 15px; border-radius: 10px; cursor: move; }

.pma_drop_result h2 .close, .pma_drop_result .h2 .close { float: right; mar=
gin-right: 5px; padding: 0px 10px; }

.dependencies_box { background-color: rgb(255, 255, 255); border: 3px ridge=
 rgb(0, 0, 0); }

#composite_index_list { list-style-type: none; list-style-position: inside;=
 }

span.drag_icon { display: inline-block; background-image: url("../img/s_sor=
table.png"); background-position: center center; background-repeat: no-repe=
at; width: 1em; height: 3em; cursor: move; }

.topmargin { margin-top: 1em; }

meter[value=3D"1"]::-webkit-meter-optimum-value { background: linear-gradie=
nt(white 3%, rgb(227, 41, 41) 5%, transparent 10%, rgb(227, 41, 41)); }

meter[value=3D"2"]::-webkit-meter-optimum-value { background: linear-gradie=
nt(white 3%, rgb(255, 102, 0) 5%, transparent 10%, rgb(255, 102, 0)); }

meter[value=3D"3"]::-webkit-meter-optimum-value { background: linear-gradie=
nt(white 3%, rgb(255, 215, 0) 5%, transparent 10%, rgb(255, 215, 0)); }

body .ui-dialog .ui-dialog-titlebar-close { right: 0.3em; left: initial; }

body .ui-dialog .ui-dialog-title { float: left; }

body .ui-dialog .ui-dialog-buttonpane .ui-dialog-buttonset { float: right; =
}

.multi_table_query_form .query-form__tr--hide { display: none; }

.multi_table_query_form .query-form__fieldset--inline, .multi_table_query_f=
orm .query-form__select--inline { display: inline; }

.multi_table_query_form .query-form__tr--bg-none { background: none; }

.multi_table_query_form .query-form__input--wide { width: 91%; }

.multi_table_query_form .query-form__multi-sql-query { float: left; }

#name-panel { overflow: hidden; }

@media only screen and (max-width: 768px) {
  .responsivetable { overflow-x: auto; }
  body#loginform div.container { width: 100%; }
  .largescreenonly { display: none; }
  .width96 { width: 96% !important; }
  #page_nav_icons { display: none; }
  #table_name_col_no { top: 62px; }
  .tdblock tr td { display: block; }
  #table_columns { margin-top: 60px; }
  #table_columns .tablesorter { min-width: 100%; }
  .doubleFieldset .pma-fieldset { width: 98%; }
  div#serverstatusquerieschart { width: 100%; height: 450px; }
  .ui-dialog { margin: 1%; width: 95% !important; }
}

#tooltip_editor { font-size: 12px; background-color: rgb(255, 255, 255); op=
acity: 0.95; padding: 5px; }

#tooltip_font { font-weight: bold; }

#selection_box { z-index: 1000; height: 205px; position: absolute; backgrou=
nd-color: skyblue; opacity: 0.4; pointer-events: none; }

#filterQueryText { vertical-align: baseline; }

.ui_tpicker_hour_slider, .ui_tpicker_minute_slider, .ui_tpicker_second_slid=
er, .ui_tpicker_millisec_slider, .ui_tpicker_microsec_slider { margin-left:=
 20px; margin-top: 4px; height: 0.75rem; }

.ui_tpicker_time_input { width: 100%; }

.pre-scrollable { max-height: 340px; overflow-y: scroll; }

@media (min-width: 1200px) {
  div.tools { text-align: left; }
  .pma-fieldset.tblFooters, .tblFooters { text-align: left; }
}

.resize-vertical { resize: vertical; }

#previewSqlModal { z-index: 1056; top: 100px; }

.table-responsive-md .data { z-index: 9; }

p.enum_notice { margin: 5px 2px; font-size: 80%; }

#enum_editor p { margin-top: 0px; font-style: italic; }

#enum_editor .values { width: 100%; }

#enum_editor .add { width: 100%; }

#enum_editor .add td { vertical-align: middle; width: 50%; padding: 0px 0px=
 0px 1em; }

#enum_editor .values td.drop { width: 1.8em; cursor: pointer; vertical-alig=
n: middle; }

#enum_editor .values input { margin: 0.1em 0px; padding-right: 2em; width: =
100%; }

#enum_editor .values img { vertical-align: middle; }

#enum_editor input.add_value { margin: 0px 0.4em 0px 0px; }

#enum_editor_output textarea { width: 100%; float: right; margin: 1em 0px 0=
px; }

.enum_hint { position: relative; }

.enum_hint a { position: absolute; left: 81%; bottom: 0.35em; }

a.close_gis_editor { float: right; }

#gis_editor { display: none; position: fixed; z-index: 1001; overflow: hidd=
en auto; }

#gis_data { min-height: 230px; }

#gis_data_textarea { height: 6em; }

#gis_data_editor { background: rgb(208, 220, 224); padding: 15px; min-heigh=
t: 500px; }

#gis_data_editor .choice { display: none; }

#gis_data_editor input[type=3D"text"] { width: 75px; }

#pma_navigation { width: 240px; position: fixed; top: 0px; left: 0px; heigh=
t: 100vh; background: linear-gradient(to right, rgb(243, 243, 243), rgb(218=
, 220, 222)); color: rgb(0, 0, 0); z-index: 800; }

#pma_navigation ul { margin: 0px; }

#pma_navigation form { margin: 0px; padding: 0px; display: inline; }

#pma_navigation select#select_server, #pma_navigation select#lightm_db { wi=
dth: 100%; }

#pma_navigation div.pageselector { text-align: center; margin: 0px 0px 0px =
0.75em; border-left: 1px solid rgb(102, 102, 102); }

#pma_navigation #pmalogo, #pma_navigation #serverChoice, #pma_navigation #n=
avipanellinks, #pma_navigation #recentTableList, #pma_navigation #favoriteT=
ableList, #pma_navigation #databaseList, #pma_navigation div.pageselector.d=
bselector { text-align: center; padding: 5px 10px 0px; border: 0px; }

#pma_navigation #navipanellinks .icon { margin: 0px; }

#pma_navigation #recentTable, #pma_navigation #favoriteTable { width: 200px=
; }

#pma_navigation #favoriteTableList select, #pma_navigation #serverChoice se=
lect { width: 80%; }

#pma_navigation_header { overflow: hidden; }

#pma_navigation_content { width: 100%; height: 100%; position: absolute; to=
p: 0px; left: 0px; z-index: 0; }

#pma_navigation_content > img.throbber { display: none; margin: 0.3em auto =
0px; }

#pma_navigation_select_database { text-align: left; padding: 0px; border: 0=
px; margin: 0px; }

#pma_navigation_db_select { margin-top: 0.5em; margin-left: 0.75em; }

#pma_navigation_db_select select { background: linear-gradient(rgb(255, 255=
, 255), rgb(241, 241, 241), rgb(255, 255, 255)); border-radius: 2px; border=
: 1px solid rgb(187, 187, 187); color: rgb(51, 51, 51); padding: 4px 6px; m=
argin: 0px; width: 92%; font-size: 1.11em; }

#pma_navigation_tree_content { width: 100%; overflow: hidden auto; position=
: absolute; height: 100%; }

#pma_navigation_tree_content a.hover_show_full { position: relative; z-inde=
x: 100; vertical-align: sub; }

#pma_navigation_tree { margin: 0px 0px 0px 5px; overflow: hidden; color: rg=
b(68, 68, 68); height: 74%; position: relative; }

#pma_navigation_tree a { color: rgb(0, 0, 0); padding-left: 0px; }

#pma_navigation_tree a:hover { text-decoration: underline; }

#pma_navigation_tree ul { clear: both; padding: 0px; list-style-type: none;=
 margin: 0px; }

#pma_navigation_tree ul ul { position: relative; }

#pma_navigation_tree li { margin-bottom: 0px; }

#pma_navigation_tree li.activePointer, #pma_navigation_tree li.selected { c=
olor: rgb(0, 0, 0); background-color: rgb(221, 221, 221); }

#pma_navigation_tree li .dbItemControls { padding-right: 4px; float: right;=
 }

#pma_navigation_tree li .navItemControls { display: none; padding-right: 4p=
x; float: right; }

#pma_navigation_tree li.activePointer .navItemControls { display: block; op=
acity: 0.5; }

#pma_navigation_tree li.activePointer .navItemControls:hover { opacity: 1; =
}

#pma_navigation_tree li { white-space: nowrap; clear: both; min-height: 16p=
x; }

#pma_navigation_tree li.fast_filter { white-space: nowrap; clear: both; min=
-height: 16px; }

#pma_navigation_tree img { margin: 0px; }

#pma_navigation_tree i { display: block; }

#pma_navigation_tree div.block { position: relative; width: 1.5em; height: =
1.5em; min-width: 16px; min-height: 16px; float: left; }

#pma_navigation_tree div.block.double { width: 2.5em; }

#pma_navigation_tree div.block i, #pma_navigation_tree div.block b { width:=
 1.5em; height: 1.7em; min-width: 16px; min-height: 8px; position: absolute=
; bottom: 0.7em; left: 0.75em; z-index: 0; }

#pma_navigation_tree div.block i { display: block; border-left: 1px solid r=
gb(102, 102, 102); border-bottom: 1px solid rgb(102, 102, 102); position: r=
elative; z-index: 0; }

#pma_navigation_tree div.block i.first { border-left: 0px; }

#pma_navigation_tree div.block b { display: block; height: 0.75em; bottom: =
-0.5rem; left: 0.75em; border-left: 1px solid rgb(102, 102, 102); }

#pma_navigation_tree div.block a, #pma_navigation_tree div.block u { positi=
on: absolute; left: 50%; top: 50%; z-index: 10; }

#pma_navigation_tree div.block a + a { left: 100%; }

#pma_navigation_tree div.block.double a, #pma_navigation_tree div.block.dou=
ble u { left: 33%; }

#pma_navigation_tree div.block.double a + a { left: 85%; }

#pma_navigation_tree div.block img { position: relative; top: -0.6em; left:=
 0px; margin-left: -7px; }

#pma_navigation_tree div.throbber img { top: 2px; left: 2px; }

#pma_navigation_tree li.last > ul { background: none; }

#pma_navigation_tree li > a, #pma_navigation_tree li > i { line-height: 1.5=
em; height: 1.5em; padding-left: 0.3em; }

#pma_navigation_tree .list_container { border-left: 1px solid rgb(102, 102,=
 102); margin-left: 0.75em; padding-left: 0.75em; }

#pma_navigation_tree .list_container li.last.database { margin-bottom: 0px =
!important; }

#pma_navigation_tree .last > .list_container { border-left: 0px solid rgb(1=
02, 102, 102); }

li.fast_filter { padding-left: 0.75em; margin-left: 0.75em; padding-right: =
35px; border-left: 1px solid rgb(102, 102, 102); list-style: none; }

li.fast_filter input { font-size: 0.7em; }

li.fast_filter .searchClauseClear { border: 0px; font-weight: bold; color: =
rgb(136, 0, 0); font-size: 0.7em; }

li.fast_filter .searchClauseClear:hover { background-color: rgba(0, 0, 0, 0=
); border-color: rgba(0, 0, 0, 0); }

li.fast_filter.db_fast_filter { border: 0px; margin-left: 0px; }

#navigation_controls_outer { min-height: 21px !important; }

#navigation_controls_outer.activePointer { background-color: rgba(0, 0, 0, =
0) !important; }

#navigation_controls { float: right; padding-right: 23px; }

#pma_navigation_resizer { width: 3px; height: 100%; background-color: rgb(1=
70, 170, 170); cursor: col-resize; position: fixed; top: 0px; left: 240px; =
z-index: 801; }

#pma_navigation_collapser { width: 20px; height: 22px; line-height: 22px; b=
ackground: rgb(238, 238, 238); color: rgb(85, 85, 85); font-weight: bold; p=
osition: fixed; top: 0px; left: 240px; text-align: center; cursor: pointer;=
 z-index: 800; text-shadow: rgb(255, 255, 255) 0px 1px 0px; border: 1px sol=
id rgb(136, 136, 136); }

.pma_quick_warp { margin-top: 5px; margin-left: 2px; position: relative; }

.pma_quick_warp .drop_list { float: left; margin-left: 3px; padding: 2px 0p=
x; }

.pma_quick_warp .drop_list:hover .drop_button { background: rgb(255, 255, 2=
55); }

.pma_quick_warp .drop_list:hover ul { display: block; }

.pma_quick_warp .drop_list ul { position: absolute; margin: 0px; padding: 0=
px; overflow: hidden auto; list-style: none; background: rgb(255, 255, 255)=
; border: 1px solid rgb(221, 221, 221); border-radius: 0.3em 0px 0px 0.3em;=
 box-shadow: rgb(204, 204, 204) 0px 0px 5px; top: 100%; left: 3px; right: 0=
px; display: none; z-index: 802; }

.pma_quick_warp .drop_list li { white-space: nowrap; padding: 0px; border-r=
adius: 0px; }

.pma_quick_warp .drop_list li img { vertical-align: sub; }

.pma_quick_warp .drop_list li:hover { background: rgb(242, 242, 242); }

.pma_quick_warp .drop_list a { display: block; padding: 0.2em 0.3em; }

.pma_quick_warp .drop_list a.favorite_table_anchor { clear: left; float: le=
ft; padding: 0.1em 0.3em 0px; }

.pma_quick_warp .drop_button { padding: 0.3em; border: 1px solid rgb(221, 2=
21, 221); border-radius: 0.3em; background: rgb(242, 242, 242); cursor: poi=
nter; }

.input_tab { background-color: rgb(166, 199, 225); color: rgb(0, 0, 0); }

.content_fullscreen { position: relative; overflow: auto; }

#canvas_outer { position: relative; width: 100%; display: block; }

#canvas { background-color: rgb(255, 255, 255); color: rgb(0, 0, 0); }

canvas.designer { display: inline-block; overflow: hidden; text-align: left=
; }

canvas.designer * { }

.designer_tab { background-color: rgb(255, 255, 255); color: rgb(0, 0, 0); =
border-collapse: collapse; border: 1px solid rgb(170, 170, 170); z-index: 1=
; user-select: none; }

.designer_tab .header { background: linear-gradient(rgb(184, 230, 250), rgb=
(184, 230, 250) 6%, rgb(205, 245, 253) 10%, rgb(219, 255, 255) 10%, rgb(155=
, 210, 246) 50%, rgb(155, 210, 246) 100%); }

.tab_zag { text-align: center; cursor: move; padding: 1px; font-weight: bol=
d; }

.tab_zag_2 { background: linear-gradient(rgb(255, 250, 150) 0%, rgb(255, 25=
0, 150) 39%, rgb(255, 231, 150) 40%, rgb(255, 231, 150) 100%) repeat-x; tex=
t-align: center; cursor: move; padding: 1px; font-weight: bold; }

.tab_field { background: rgb(255, 255, 255); color: rgb(0, 0, 0); cursor: d=
efault; }

.tab_field:hover { background-color: rgb(204, 255, 204); color: rgb(0, 0, 0=
); background-repeat: repeat-x; cursor: default; }

.tab_field_3 { color: rgb(0, 0, 0); cursor: default; background-color: rgb(=
255, 230, 230) !important; }

.tab_field_3:hover { background-color: rgb(204, 255, 204); color: rgb(0, 0,=
 0); background-repeat: repeat-x; cursor: default; }

#designer_hint { white-space: nowrap; position: absolute; background-color:=
 rgb(153, 255, 153); color: rgb(0, 0, 0); z-index: 3; border: 1px solid rgb=
(0, 204, 102); display: none; }

#designer_body #page_content { margin: 0px; }

.scroll_tab { overflow: auto; width: 100%; height: 500px; }

.designer_Tabs { cursor: default; color: rgb(0, 85, 187); white-space: nowr=
ap; text-decoration: none; text-indent: 3px; font-weight: bold; margin-left=
: 2px; text-align: left; background: linear-gradient(rgb(255, 255, 255), rg=
b(223, 229, 231) 70%, rgb(255, 255, 255) 70%, rgb(255, 255, 255) 100%); bor=
der: 1px solid rgb(204, 204, 204); }

.designer_Tabs:hover { cursor: default; color: rgb(0, 85, 187); background:=
 rgb(255, 238, 153); text-indent: 3px; font-weight: bold; white-space: nowr=
ap; text-decoration: none; border: 1px solid rgb(153, 153, 255); text-align=
: left; }

.owner { font-weight: normal; color: rgb(136, 136, 136); }

.option_tab { padding-left: 2px; padding-right: 2px; width: 5px; }

.select_all { vertical-align: top; padding-left: 2px; padding-right: 2px; c=
ursor: default; width: 1px; color: rgb(0, 0, 0); background: linear-gradien=
t(rgb(184, 230, 250), rgb(184, 230, 250) 6%, rgb(205, 245, 253) 10%, rgb(21=
9, 255, 255) 10%, rgb(155, 210, 246) 50%, rgb(155, 210, 246) 100%); }

.small_tab { vertical-align: top; background-color: rgb(0, 100, 234); color=
: rgb(255, 255, 255); background-image: url("../img/designer/small_tab.png"=
); cursor: default; text-align: center; font-weight: bold; padding-left: 2p=
x; padding-right: 2px; width: 1px; text-decoration: none; }

.small_tab:hover { vertical-align: top; color: rgb(255, 255, 255); backgrou=
nd-color: rgb(255, 153, 102); cursor: default; padding-left: 2px; padding-r=
ight: 2px; text-align: center; font-weight: bold; width: 1px; text-decorati=
on: none; }

.small_tab_pref { background: linear-gradient(rgb(184, 230, 250), rgb(184, =
230, 250) 6%, rgb(205, 245, 253) 10%, rgb(219, 255, 255) 10%, rgb(155, 210,=
 246) 50%, rgb(155, 210, 246) 100%); text-align: center; width: 1px; }

.small_tab_pref:hover { vertical-align: top; color: rgb(255, 255, 255); bac=
kground-color: rgb(255, 153, 102); cursor: default; text-align: center; fon=
t-weight: bold; width: 1px; text-decoration: none; }

.butt { border: 1px solid rgb(68, 119, 170); font-weight: bold; background-=
color: rgb(255, 255, 255); color: rgb(0, 0, 0); vertical-align: baseline; }

.L_butt2_1 { padding: 1px; text-decoration: none; vertical-align: middle; c=
ursor: default; }

.L_butt2_1:hover { padding: 0px; border: 1px solid rgb(0, 153, 204); backgr=
ound: rgb(255, 238, 153); color: rgb(0, 0, 0); text-decoration: none; verti=
cal-align: middle; cursor: default; }

.bor { width: 10px; height: 10px; }

.frams1 { background: url("../img/designer/1.png") right bottom no-repeat; =
}

.frams2 { background: url("../img/designer/2.png") left bottom no-repeat; }

.frams3 { background: url("../img/designer/3.png") left top no-repeat; }

.frams4 { background: url("../img/designer/4.png") right top no-repeat; }

.frams5 { background: url("../img/designer/5.png") center bottom repeat-x; =
}

.frams6 { background: url("../img/designer/6.png") left center repeat-y; }

.frams7 { background: url("../img/designer/7.png") center top repeat-x; }

.frams8 { background: url("../img/designer/8.png") right center repeat-y; }

#osn_tab { position: absolute; background-color: rgb(255, 255, 255); color:=
 rgb(0, 0, 0); }

.designer_header { background-color: rgb(234, 238, 240); color: rgb(0, 0, 0=
); text-align: center; font-weight: bold; margin: 0px; padding: 0px; backgr=
ound-image: url("../img/designer/top_panel.png"); background-position: cent=
er top; background-repeat: repeat-x; border-right: 1px solid rgb(153, 153, =
153); border-left: 1px solid rgb(153, 153, 153); height: 28px; z-index: 101=
; width: 100%; position: fixed; }

.designer_header a, .designer_header span { display: block; float: left; ma=
rgin: 3px 1px 4px; height: 20px; border: 1px dotted rgb(255, 255, 255); }

.designer_header .M_bord { display: block; float: left; margin: 4px; height=
: 20px; width: 2px; }

.designer_header a.first { margin-right: 1em; }

.designer_header a.last { margin-left: 1em; }

a.M_butt_Selected_down_IE, a.M_butt_Selected_down { border: 1px solid rgb(1=
92, 192, 187); background-color: rgb(153, 255, 153); color: rgb(0, 0, 0); }

a.M_butt_Selected_down_IE:hover, a.M_butt_Selected_down:hover { border: 1px=
 solid rgb(0, 153, 204); background-color: rgb(255, 238, 153); color: rgb(0=
, 0, 0); }

a.M_butt:hover { border: 1px solid rgb(0, 153, 204); background-color: rgb(=
255, 238, 153); color: rgb(0, 0, 0); }

#layer_menu { z-index: 98; position: relative; float: right; background-col=
or: rgb(234, 238, 240); border: 1px solid rgb(153, 153, 153); }

#layer_upd_relation { position: absolute; left: 637px; top: 224px; z-index:=
 100; }

#layer_new_relation, #designer_optionse { position: absolute; left: 636px; =
top: 85px; z-index: 100; width: 153px; }

#layer_menu_sizer { background-image: url("../img/designer/resize.png"); cu=
rsor: ew-resize; }

#layer_menu_sizer .icon { margin: 0px; }

.panel { position: fixed; top: 60px; right: 0px; width: 350px; max-height: =
500px; display: none; overflow: auto; padding-top: 34px; z-index: 102; }

a.trigger { position: fixed; text-decoration: none; top: 60px; right: 0px; =
color: rgb(255, 255, 255); padding: 10px 40px 10px 15px; background: url(".=
./img/designer/plus.png") 85% 55% no-repeat rgb(51, 51, 51); border: 1px so=
lid rgb(68, 68, 68); display: block; z-index: 102; }

a.trigger:hover { color: rgb(8, 8, 8); background: url("../img/designer/plu=
s.png") 85% 55% no-repeat rgb(255, 246, 150); border: 1px solid rgb(153, 15=
3, 153); }

a.active.trigger { background: url("../img/designer/minus.png") 85% 55% no-=
repeat rgb(34, 34, 34); z-index: 999; }

a.active.trigger:hover { background: url("../img/designer/minus.png") 85% 5=
5% no-repeat rgb(255, 246, 150); }

.toggle_container .block { background-color: rgb(219, 228, 232); border-top=
: 1px solid rgb(153, 153, 153); }

.history_table { text-align: center; cursor: pointer; background-color: rgb=
(219, 228, 232); }

.history_table:hover { background-color: rgb(153, 153, 204); }

#ab { min-width: 300px; }

#ab .ui-accordion-content { padding: 0px; }

#foreignkeychk { text-align: left; cursor: pointer; }

.side-menu { float: left; position: fixed; width: auto; height: auto; backg=
round: rgb(239, 239, 239); border: 1px solid gray; overflow: hidden; z-inde=
x: 50; padding: 2px; }

.side-menu.right { float: right; right: 0px; }

.side-menu .hide { display: none; }

.side-menu a { display: block; float: none; overflow: hidden; line-height: =
1em; }

.side-menu img, .side-menu .text { float: left; }

#name-panel { border-bottom: 1px solid gray; text-align: center; background=
: rgb(239, 239, 239); width: 100%; font-size: 1.2em; padding: 5px; font-wei=
ght: bold; }

#container-form { width: 100%; position: absolute; left: 0px; }

.CodeMirror { height: 20rem; direction: ltr; }

.CodeMirror.cm-s-default div.CodeMirror-scroll { margin-right: 0px; padding=
-bottom: 0px; }

#inline_editor_outer .CodeMirror { height: 6em; }

.insertRowTable .CodeMirror { min-height: 9em; min-width: 24em; border: 1px=
 solid rgb(169, 169, 169); }

#pma_console .CodeMirror-gutters { background-color: initial; border: none;=
 }

span.cm-keyword, span.cm-statement-verb { color: rgb(153, 0, 153); }

span.cm-variable { color: rgb(0, 0, 0); }

span.cm-comment { color: olive; }

span.cm-mysql-string { color: green; }

span.cm-operator { color: rgb(255, 0, 255); }

span.cm-mysql-word { color: rgb(0, 0, 0); }

span.cm-builtin { color: red; }

span.cm-variable-2 { color: rgb(255, 153, 0); }

span.cm-variable-3 { color: blue; }

span.cm-separator { color: rgb(255, 0, 255); }

span.cm-number { color: teal; }

.autocomplete-column-name { display: inline-block; }

.autocomplete-column-hint { display: inline-block; float: right; color: rgb=
(102, 102, 102); margin-left: 1em; }

.CodeMirror-hints { z-index: 1999; }

.CodeMirror-lint-tooltip { z-index: 200; font-family: inherit; }

.CodeMirror-lint-tooltip code { font-family: monospace; font-weight: bold; =
}

.jqplot-target { position: relative; color: rgb(34, 34, 34); font-family: "=
Trebuchet MS", Arial, Helvetica, sans-serif; font-size: 1em; }

.jqplot-axis { font-size: 0.75em; }

.jqplot-xaxis { margin-top: 10px; }

.jqplot-x2axis { margin-bottom: 10px; }

.jqplot-yaxis { margin-right: 10px; }

.jqplot-y2axis, .jqplot-y3axis, .jqplot-y4axis, .jqplot-y5axis, .jqplot-y6a=
xis, .jqplot-y7axis, .jqplot-y8axis, .jqplot-y9axis, .jqplot-yMidAxis { mar=
gin-left: 10px; margin-right: 10px; }

.jqplot-axis-tick, .jqplot-xaxis-tick, .jqplot-yaxis-tick, .jqplot-x2axis-t=
ick, .jqplot-y2axis-tick, .jqplot-y3axis-tick, .jqplot-y4axis-tick, .jqplot=
-y5axis-tick, .jqplot-y6axis-tick, .jqplot-y7axis-tick, .jqplot-y8axis-tick=
, .jqplot-y9axis-tick, .jqplot-yMidAxis-tick { position: absolute; white-sp=
ace: pre; }

.jqplot-xaxis-tick { top: 0px; left: 15px; vertical-align: top; }

.jqplot-x2axis-tick { bottom: 0px; left: 15px; vertical-align: bottom; }

.jqplot-yaxis-tick { right: 0px; top: 15px; text-align: right; }

.jqplot-yaxis-tick.jqplot-breakTick { right: -20px; margin-right: 0px; padd=
ing: 1px 5px; z-index: 2; font-size: 1.5em; }

.jqplot-y2axis-tick, .jqplot-y3axis-tick, .jqplot-y4axis-tick, .jqplot-y5ax=
is-tick, .jqplot-y6axis-tick, .jqplot-y7axis-tick, .jqplot-y8axis-tick, .jq=
plot-y9axis-tick { left: 0px; top: 15px; text-align: left; }

.jqplot-yMidAxis-tick { text-align: center; white-space: nowrap; }

.jqplot-xaxis-label { margin-top: 10px; font-size: 11pt; position: absolute=
; }

.jqplot-x2axis-label { margin-bottom: 10px; font-size: 11pt; position: abso=
lute; }

.jqplot-yaxis-label { margin-right: 10px; font-size: 11pt; position: absolu=
te; }

.jqplot-yMidAxis-label { font-size: 11pt; position: absolute; }

.jqplot-y2axis-label, .jqplot-y3axis-label, .jqplot-y4axis-label, .jqplot-y=
5axis-label, .jqplot-y6axis-label, .jqplot-y7axis-label, .jqplot-y8axis-lab=
el, .jqplot-y9axis-label { font-size: 11pt; margin-left: 10px; position: ab=
solute; }

.jqplot-meterGauge-tick { font-size: 0.75em; color: rgb(153, 153, 153); }

.jqplot-meterGauge-label { font-size: 1em; color: rgb(153, 153, 153); }

table.jqplot-table-legend { margin: 12px; background-color: rgba(255, 255, =
255, 0.6); border: 1px solid rgb(204, 204, 204); position: absolute; font-s=
ize: 0.75em; }

table.jqplot-cursor-legend { background-color: rgba(255, 255, 255, 0.6); bo=
rder: 1px solid rgb(204, 204, 204); position: absolute; font-size: 0.75em; =
}

td.jqplot-table-legend { vertical-align: middle; }

td.jqplot-seriesToggle:hover, td.jqplot-seriesToggle:active { cursor: point=
er; }

.jqplot-table-legend .jqplot-series-hidden { text-decoration: line-through;=
 }

div.jqplot-table-legend-swatch-outline { border: 1px solid rgb(204, 204, 20=
4); padding: 1px; }

div.jqplot-table-legend-swatch { width: 0px; height: 0px; border-width: 5px=
 6px; border-style: solid; }

.jqplot-title { top: 0px; left: 0px; padding-bottom: 0.5em; font-size: 1.2e=
m; }

table.jqplot-cursor-tooltip { border: 1px solid rgb(204, 204, 204); font-si=
ze: 0.75em; }

.jqplot-cursor-tooltip, .jqplot-highlighter-tooltip, .jqplot-canvasOverlay-=
tooltip { border: 1px solid rgb(204, 204, 204); font-size: 1em; white-space=
: nowrap; background: rgba(208, 208, 208, 0.8); padding: 1px; }

.jqplot-point-label { font-size: 0.75em; z-index: 2; }

td.jqplot-cursor-legend-swatch { vertical-align: middle; text-align: center=
; }

div.jqplot-cursor-legend-swatch { width: 1.2em; height: 0.7em; }

.jqplot-error { text-align: center; }

.jqplot-error-message { position: relative; top: 46%; display: inline-block=
; }

div.jqplot-bubble-label { font-size: 0.8em; padding-left: 2px; padding-righ=
t: 2px; color: rgb(51, 51, 51); }

div.jqplot-bubble-label.jqplot-bubble-label-highlight { background: rgba(23=
0, 230, 230, 0.7); }

div.jqplot-noData-container { text-align: center; background-color: rgba(24=
5, 245, 245, 0.3); }

.icon { margin: 0px 0px 0px 0.3em; width: 16px; height: 16px; padding: 0px =
!important; }

.icon_fulltext { width: 50px; height: 19px; }

.ic_asc_order { background-image: url("../img/asc_order.png"); }

.ic_b_bookmark { background-image: url("../img/b_bookmark.png"); }

.ic_b_browse { background-image: url("../img/b_browse.png"); }

.ic_b_calendar { background-image: url("../img/b_calendar.png"); }

.ic_b_chart { background-image: url("../img/b_chart.png"); }

.ic_b_close { background-image: url("../img/b_close.png"); }

.ic_b_column_add { background-image: url("../img/b_column_add.png"); }

.ic_b_comment { background-image: url("../img/b_comment.png"); }

.ic_b_dbstatistics { background-image: url("../img/b_dbstatistics.png"); }

.ic_b_deltbl { background-image: url("../img/b_deltbl.png"); }

.ic_b_docs { background-image: url("../img/b_docs.png"); }

.ic_b_docsql { background-image: url("../img/b_docsql.png"); }

.ic_b_drop { background-image: url("../img/b_drop.png"); }

.ic_b_edit { background-image: url("../img/b_edit.png"); }

.ic_b_empty { background-image: url("../img/b_empty.png"); }

.ic_b_engine { background-image: url("../img/b_engine.png"); }

.ic_b_event_add { background-image: url("../img/b_event_add.png"); }

.ic_b_events { background-image: url("../img/b_events.png"); }

.ic_b_export { background-image: url("../img/b_export.png"); }

.ic_b_favorite { background-image: url("../img/b_favorite.png"); }

.ic_b_find_replace { background-image: url("../img/b_find_replace.png"); }

.ic_b_firstpage { background-image: url("../img/b_firstpage.png"); }

.ic_b_ftext { background-image: url("../img/b_ftext.png"); }

.ic_b_globe { background-image: url("../img/b_globe.gif"); }

.ic_b_group { background-image: url("../img/b_group.png"); }

.ic_b_help { background-image: url("../img/b_help.png"); }

.ic_b_home { background-image: url("../img/b_home.png"); }

.ic_b_import { background-image: url("../img/b_import.png"); }

.ic_b_index { background-image: url("../img/b_index.png"); }

.ic_b_index_add { background-image: url("../img/b_index_add.png"); }

.ic_b_inline_edit { background-image: url("../img/b_inline_edit.png"); }

.ic_b_insrow { background-image: url("../img/b_insrow.png"); }

.ic_b_lastpage { background-image: url("../img/b_lastpage.png"); }

.ic_b_minus { background-image: url("../img/b_minus.png"); }

.ic_b_more { background-image: url("../img/b_more.png"); }

.ic_b_move { background-image: url("../img/b_move.png"); }

.ic_b_newdb { background-image: url("../img/b_newdb.png"); }

.ic_db_drop { background-image: url("../img/b_deltbl.png"); }

.ic_b_newtbl { background-image: url("../img/b_newtbl.png"); }

.ic_b_nextpage { background-image: url("../img/b_nextpage.png"); }

.ic_b_no_favorite { background-image: url("../img/b_no_favorite.png"); }

.ic_b_pdfdoc { background-image: url("../img/b_pdfdoc.png"); }

.ic_b_plugin { background-image: url("../img/b_plugin.png"); }

.ic_b_plus { background-image: url("../img/b_plus.png"); }

.ic_b_prevpage { background-image: url("../img/b_prevpage.png"); }

.ic_b_primary { background-image: url("../img/b_primary.png"); }

.ic_b_print { background-image: url("../img/b_print.png"); }

.ic_b_props { background-image: url("../img/b_props.png"); }

.ic_b_relations { background-image: url("../img/b_relations.png"); }

.ic_b_report { background-image: url("../img/b_report.png"); }

.ic_b_rename { background-image: url("../img/b_rename.svg"); }

.ic_b_routine_add { background-image: url("../img/b_routine_add.png"); }

.ic_b_routines { background-image: url("../img/b_routines.png"); }

.ic_b_save { background-image: url("../img/b_save.png"); }

.ic_b_saveimage { background-image: url("../img/b_saveimage.png"); }

.ic_b_sbrowse { background-image: url("../img/b_sbrowse.png"); }

.ic_b_sdb { background-image: url("../img/b_sdb.png"); width: 10px; height:=
 10px; }

.ic_b_search { background-image: url("../img/b_search.png"); }

.ic_b_select { background-image: url("../img/b_select.png"); }

.ic_b_snewtbl { background-image: url("../img/b_snewtbl.png"); }

.ic_b_spatial { background-image: url("../img/b_spatial.png"); }

.ic_b_sql { background-image: url("../img/b_sql.png"); }

.ic_b_sqldoc { background-image: url("../img/b_sqldoc.png"); }

.ic_b_sqlhelp { background-image: url("../img/b_sqlhelp.png"); }

.ic_b_table_add { background-image: url("../img/b_table_add.png"); }

.ic_b_tblanalyse { background-image: url("../img/b_tblanalyse.png"); }

.ic_b_tblexport { background-image: url("../img/b_tblexport.png"); }

.ic_b_tblimport { background-image: url("../img/b_tblimport.png"); }

.ic_b_tblops { background-image: url("../img/b_tblops.png"); }

.ic_b_tbloptimize { background-image: url("../img/b_tbloptimize.png"); }

.ic_b_tipp { background-image: url("../img/b_tipp.png"); }

.ic_b_trigger_add { background-image: url("../img/b_trigger_add.png"); }

.ic_b_triggers { background-image: url("../img/b_triggers.png"); }

.ic_b_undo { background-image: url("../img/b_undo.png"); }

.ic_b_unique { background-image: url("../img/b_unique.png"); }

.ic_b_usradd { background-image: url("../img/b_usradd.png"); }

.ic_b_usrcheck { background-image: url("../img/b_usrcheck.png"); }

.ic_b_usrdrop { background-image: url("../img/b_usrdrop.png"); }

.ic_b_usredit { background-image: url("../img/b_usredit.png"); }

.ic_b_usrlist { background-image: url("../img/b_usrlist.png"); }

.ic_b_versions { background-image: url("../img/b_versions.png"); }

.ic_b_view { background-image: url("../img/b_view.png"); }

.ic_b_view_add { background-image: url("../img/b_view_add.png"); }

.ic_b_views { background-image: url("../img/b_views.png"); }

.ic_b_left { background-image: url("../img/b_left.png"); }

.ic_b_right { background-image: url("../img/b_right.png"); }

.ic_bd_browse { background-image: url("../img/bd_browse.png"); }

.ic_bd_deltbl { background-image: url("../img/bd_deltbl.png"); }

.ic_bd_drop { background-image: url("../img/bd_drop.png"); }

.ic_bd_edit { background-image: url("../img/bd_edit.png"); }

.ic_bd_empty { background-image: url("../img/bd_empty.png"); }

.ic_bd_export { background-image: url("../img/bd_export.png"); }

.ic_bd_firstpage { background-image: url("../img/bd_firstpage.png"); }

.ic_bd_ftext { background-image: url("../img/bd_ftext.png"); }

.ic_bd_index { background-image: url("../img/bd_index.png"); }

.ic_bd_insrow { background-image: url("../img/bd_insrow.png"); }

.ic_bd_lastpage { background-image: url("../img/bd_lastpage.png"); }

.ic_bd_nextpage { background-image: url("../img/bd_nextpage.png"); }

.ic_bd_prevpage { background-image: url("../img/bd_prevpage.png"); }

.ic_bd_primary { background-image: url("../img/bd_primary.png"); }

.ic_bd_routine_add { background-image: url("../img/bd_routine_add.png"); }

.ic_bd_sbrowse { background-image: url("../img/bd_sbrowse.png"); }

.ic_bd_select { background-image: url("../img/bd_select.png"); }

.ic_bd_spatial { background-image: url("../img/bd_spatial.png"); }

.ic_bd_unique { background-image: url("../img/bd_unique.png"); }

.ic_centralColumns { background-image: url("../img/centralColumns.png"); }

.ic_centralColumns_add { background-image: url("../img/centralColumns_add.p=
ng"); }

.ic_centralColumns_delete { background-image: url("../img/centralColumns_de=
lete.png"); }

.ic_col_drop { background-image: url("../img/col_drop.png"); }

.ic_console { background-image: url("../img/console.png"); }

.ic_database { background-image: url("../img/database.png"); }

.ic_eye { background-image: url("../img/eye.png"); }

.ic_eye_grey { background-image: url("../img/eye_grey.png"); }

.ic_hide { background-image: url("../img/hide.png"); }

.ic_item { background-image: url("../img/item.png"); width: 9px; height: 9p=
x; }

.ic_lightbulb { background-image: url("../img/lightbulb.png"); }

.ic_lightbulb_off { background-image: url("../img/lightbulb_off.png"); }

.ic_more { background-image: url("../img/more.png"); width: 13px; }

.ic_new_data { background-image: url("../img/new_data.png"); }

.ic_new_data_hovered { background-image: url("../img/new_data_hovered.png")=
; }

.ic_new_data_selected { background-image: url("../img/new_data_selected.png=
"); }

.ic_new_data_selected_hovered { background-image: url("../img/new_data_sele=
cted_hovered.png"); }

.ic_new_struct { background-image: url("../img/new_struct.png"); }

.ic_new_struct_hovered { background-image: url("../img/new_struct_hovered.p=
ng"); }

.ic_new_struct_selected { background-image: url("../img/new_struct_selected=
.png"); }

.ic_new_struct_selected_hovered { background-image: url("../img/new_struct_=
selected_hovered.png"); }

.ic_normalize { background-image: url("../img/normalize.png"); }

.ic_pause { background-image: url("../img/pause.png"); }

.ic_php_sym { background-image: url("../img/php_sym.png"); }

.ic_play { background-image: url("../img/play.png"); }

.ic_s_asc { background-image: url("../img/s_asc.png"); }

.ic_s_asci { background-image: url("../img/s_asci.png"); }

.ic_s_attention { background-image: url("../img/s_attention.png"); }

.ic_s_cancel { background-image: url("../img/s_cancel.png"); }

.ic_s_cancel2 { background-image: url("../img/s_cancel2.png"); }

.ic_s_cog { background-image: url("../img/s_cog.png"); }

.ic_s_collapseall { background-image: url("../img/s_collapseall.png"); back=
ground-position: center center; }

.ic_s_db { background-image: url("../img/s_db.png"); }

.ic_s_desc { background-image: url("../img/s_desc.png"); }

.ic_s_error { background-image: url("../img/s_error.png"); }

.ic_s_host { background-image: url("../img/s_host.png"); }

.ic_s_info { background-image: url("../img/s_info.png"); }

.ic_s_lang { background-image: url("../img/s_lang.png"); }

.ic_s_link { background-image: url("../img/s_link.png"); }

.ic_s_lock { background-image: url("../img/s_lock.png"); }

.ic_s_unlock { background-image: url("../img/lock_open.png"); }

.ic_s_loggoff { background-image: url("../img/s_loggoff.png"); }

.ic_s_notice { background-image: url("../img/s_notice.png"); }

.ic_s_okay { background-image: url("../img/s_okay.png"); }

.ic_s_passwd { background-image: url("../img/s_passwd.png"); }

.ic_s_process { background-image: url("../img/s_process.png"); }

.ic_s_really { background-image: url("../img/s_really.png"); width: 11px; h=
eight: 11px; }

.ic_s_reload { background-image: url("../img/s_reload.png"); }

.ic_s_replication { background-image: url("../img/s_replication.png"); }

.ic_s_rights { background-image: url("../img/s_rights.png"); }

.ic_s_sortable { background-image: url("../img/s_sortable.png"); }

.ic_s_status { background-image: url("../img/s_status.png"); }

.ic_s_success { background-image: url("../img/s_success.png"); }

.ic_s_sync { background-image: url("../img/s_sync.png"); }

.ic_s_tbl { background-image: url("../img/s_tbl.png"); }

.ic_s_theme { background-image: url("../img/s_theme.png"); }

.ic_s_top { background-image: url("../img/s_top.png"); }

.ic_s_unlink { background-image: url("../img/s_unlink.png"); }

.ic_s_vars { background-image: url("../img/s_vars.png"); }

.ic_s_views { background-image: url("../img/s_views.png"); }

.ic_show { background-image: url("../img/show.png"); }

.ic_window-new { background-image: url("../img/window-new.png"); }

.ic_ajax_clock_small { background-image: url("../img/ajax_clock_small.gif")=
; }

.ic_s_partialtext { background-image: url("../img/s_partialtext.png"); }

.ic_s_fulltext { background-image: url("../img/s_fulltext.png"); }

body { text-align: left; }

h1, .h1 { font-weight: bold; }

h2, .h2 { font-weight: normal; text-shadow: rgb(255, 255, 255) 0px 1px 0px;=
 padding: 10px 0px 10px 3px; color: rgb(119, 119, 119); }

h3, .h3 { font-weight: bold; }

input, select { font-size: 1em; }

textarea { font-family: monospace; font-size: 1.2em; }

.table { caption-side: top; }

.table th, .table td { text-shadow: rgb(255, 255, 255) 0px 1px 0px; vertica=
l-align: middle; }

.table th { color: rgb(0, 0, 0); text-align: left; }

.table td { touch-action: manipulation; }

.table thead th { border-right: 1px solid rgb(255, 255, 255); background-im=
age: linear-gradient(rgb(255, 255, 255), rgb(204, 204, 204)); }

.table caption { background-color: rgb(211, 220, 227); font-weight: bold; t=
ext-align: center; }

.table-hover tbody tr:hover { background: linear-gradient(rgb(206, 214, 223=
), rgb(182, 198, 215)); }

.table-striped > tbody > tr:nth-of-type(2n) > th { color: rgb(0, 0, 0); }

@media only screen and (min-width: 768px) {
  .table th.position-sticky { top: 60px; }
}

select#fieldsSelect, textarea#sqlquery { margin: 0px; height: 20rem; }

.btn-primary, .btn-outline-primary { font-weight: 700; }

.btn-primary, .btn-secondary { border-color: rgb(170, 170, 170); text-shado=
w: rgb(255, 255, 255) 0px 1px 0px; background-image: linear-gradient(rgb(24=
8, 248, 248), rgb(216, 216, 216)); }

.btn-primary:hover, .btn-secondary:hover { background-image: linear-gradien=
t(rgb(255, 255, 255), rgb(221, 221, 221)); }

.btn-outline-primary, .btn-outline-secondary { color: rgb(68, 68, 68); bord=
er-color: rgb(170, 170, 170); }

.nav-pills .nav-link { margin-left: 0px; margin-right: 6px; padding: 4px 10=
px; font-weight: bold; background: rgb(242, 242, 242); color: rgb(35, 90, 1=
29); border: 1px solid rgb(221, 221, 221); border-radius: 20px; }

.nav-pills .nav-link:hover { background-color: rgb(229, 229, 229); border-r=
adius: 0.3em; }

.nav-pills .nav-link img { margin-right: 0.5em; vertical-align: -3px; }

.nav-pills .nav-link.active, .nav-pills .show > .nav-link { background-colo=
r: rgb(255, 255, 255); color: rgb(35, 90, 129); border-radius: 0.3em; }

.nav-tabs { font-weight: bold; }

.nav-tabs .nav-link { background-color: rgb(242, 242, 242); color: rgb(85, =
85, 85); border-color: rgb(213, 213, 213) rgb(213, 213, 213) rgb(170, 170, =
170); margin-right: 0.4em; padding: 7px 10px; }

.nav-tabs .nav-link:hover, .nav-tabs .nav-link:focus { background-color: rg=
b(229, 229, 229); }

.nav-tabs .nav-link.active:hover, .nav-tabs .nav-link.active:focus, .nav-ta=
bs .nav-item.show .nav-link:hover, .nav-tabs .nav-item.show .nav-link:focus=
 { background-color: rgb(255, 255, 255); }

.navbar.bg-light { background: linear-gradient(rgb(255, 255, 255), rgb(220,=
 220, 220)); }

.navbar-nav { font-weight: bold; }

.navbar-nav .icon { margin-right: 0.5em; vertical-align: -3px; }

.navbar-nav .nav-item { background: linear-gradient(rgb(255, 255, 255), rgb=
(220, 220, 220)); border-right: 1px solid rgb(255, 255, 255); border-left: =
1px solid rgb(204, 204, 204); border-bottom: 1px solid rgb(204, 204, 204); =
}

.navbar-nav .nav-item:first-child { border-left: 0px; }

.navbar-nav .nav-item:hover { background: linear-gradient(rgb(255, 255, 255=
), rgb(229, 229, 229)); }

.navbar-nav .nav-item.active { background: rgb(255, 255, 255); border-botto=
m: 0px; }

.card { margin-top: 2rem; margin-bottom: 0.5rem; }

.card > .card-header + .card-body { padding-top: 0px; }

.card, .card-footer { text-shadow: rgb(255, 255, 255) 1px 1px 2px; box-shad=
ow: rgb(255, 255, 255) 1px 1px 2px inset; }

.card-header { position: relative; top: -1rem; margin: 0px 5px; width: max-=
content; max-width: 100%; font-weight: bold; padding: 5px 10px; border: 1px=
 solid rgb(170, 170, 170); font-size: 1em; box-shadow: rgb(187, 187, 187) 3=
px 3px 15px; }

.card-header, .card-header:first-child { border-radius: 2px; }

.card-footer { color: rgb(0, 0, 0); background: rgb(211, 220, 227); padding=
: 0.5em; }

#maincontainer .card-header { position: static; width: auto; margin: 0px; b=
order: none; }

#maincontainer .card-header:first-child { border-radius: calc(-1px + 0.25re=
m) calc(-1px + 0.25rem) 0px 0px; }

#maincontainer .card { background-color: rgb(243, 243, 243); border: 1px so=
lid rgb(153, 153, 153); box-shadow: rgb(204, 204, 204) 2px 2px 5px; }

#maincontainer .card > .card-header + .card-body { padding-top: 1rem; }

#maincontainer .card-header { padding: 0.1em 1rem; background-color: rgb(18=
7, 187, 187); color: rgb(255, 255, 255); font-size: 1.6em; font-weight: nor=
mal; text-shadow: rgb(119, 119, 119) 0px 1px 0px; box-shadow: rgb(153, 153,=
 153) 1px 1px 15px inset; }

.breadcrumb-navbar { padding: 0.1rem 2.2em; margin-bottom: 0px; background-=
color: rgb(136, 136, 136); }

.breadcrumb-navbar .breadcrumb-item + .breadcrumb-comment { padding-left: 0=
.5rem; }

.breadcrumb-navbar .breadcrumb-item .icon { margin: 0px; }

.breadcrumb-navbar { text-shadow: rgb(0, 0, 0) 0px 1px 0px; }

.breadcrumb-navbar .breadcrumb-item + .breadcrumb-comment { padding-left: 0=
.5rem; }

.breadcrumb-navbar .breadcrumb-item a { color: rgb(255, 255, 255); }

.breadcrumb-navbar .breadcrumb-comment { color: rgb(214, 214, 214); font-we=
ight: bold; font-style: italic; text-shadow: none; }

.page-link { background-image: linear-gradient(rgb(255, 255, 255), rgb(224,=
 224, 224)); }

.page-link:hover { text-decoration: underline; }

.page-item.active .page-link { background-image: linear-gradient(rgb(187, 1=
87, 187), rgb(255, 255, 255)); }

.page-item.disabled .page-link { background-image: none; }

.alert { text-align: left; box-shadow: rgb(255, 255, 255) 0px 1px 1px inset=
; background-position: 10px 50%; padding: 10px; }

.alert a { text-decoration: underline; }

.alert h1, .alert .h1 { border-bottom: 2px solid; }

.alert-primary { color: rgb(0, 0, 0); background-color: rgb(232, 238, 241);=
 background-image: none; border-color: rgb(58, 108, 126); }

.alert-primary h1, .alert-primary .h1 { border-color: rgb(255, 177, 10); }

.alert-success { color: rgb(0, 0, 0); background-color: rgb(235, 248, 164);=
 background-image: none; border-color: rgb(162, 210, 70); }

.alert-success h1, .alert-success .h1 { border-color: lime; }

.alert-danger { color: rgb(0, 0, 0); background-color: pink; background-ima=
ge: none; border-color: rgb(51, 51, 51); }

.alert-danger h1, .alert-danger .h1 { border-color: red; }

.result_query .alert { margin-bottom: 0px; border-bottom-left-radius: 0px; =
border-bottom-right-radius: 0px; padding-bottom: 5px; border-bottom: none !=
important; }

#maincontainer .list-group { padding-left: 40px; margin: 1rem 0px; }

#maincontainer .list-group-item { padding: 0px; display: list-item; border:=
 none; }

#li_select_server.list-group-item, #li_change_password.list-group-item, #li=
_select_mysql_collation.list-group-item, #li_user_preferences.list-group-it=
em, #li_select_lang.list-group-item, #li_select_theme.list-group-item { dis=
play: block; margin-left: -20px; }

.modal-header { background-image: linear-gradient(rgb(248, 248, 248), rgb(2=
16, 216, 216)); }

@media print {
  .hide { display: none; }
  body, table, th, td { color: rgb(0, 0, 0); background-color: rgb(255, 255=
, 255); font-size: 12px; }
  a:link { color: rgb(0, 0, 0); text-decoration: none; }
  img { border: 0px; }
  table, th, td { border: 0.1em solid rgb(0, 0, 0); background-color: rgb(2=
55, 255, 255); }
  table { border-collapse: collapse; border-spacing: 0.2em; }
  thead { border-collapse: collapse; border-spacing: 0.2em; border: 0.1em s=
olid rgb(0, 0, 0); font-weight: 900; }
  th, td { padding: 0.2em; }
  thead th { font-weight: bold; background-color: rgb(229, 229, 229); borde=
r: 0.1em solid rgb(0, 0, 0); }
  #page_content { position: absolute; left: 0px; top: 0px; width: 95%; floa=
t: none; }
  .sqlOuter { color: rgb(0, 0, 0); background-color: rgb(0, 0, 0); }
  .cDrop, .cEdit, .cList, .cCpy, .cPointer { display: none; }
  table tbody:first-of-type tr:nth-child(2n+1) { background: rgb(255, 255, =
255); }
  table tbody:first-of-type tr:nth-child(2n+1) th { background: rgb(255, 25=
5, 255); }
  table tbody:first-of-type tr:nth-child(2n) { background: rgb(223, 223, 22=
3); }
  table tbody:first-of-type tr:nth-child(2n) th { background: rgb(223, 223,=
 223); }
  .column_attribute { font-size: 100%; }
}
------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: text/css
Content-Transfer-Encoding: quoted-printable
Content-Location: http://localhost/phpmyadmin/js/vendor/codemirror/addon/lint/lint.css?v=5.2.1

@charset "utf-8";

.CodeMirror-lint-markers { width: 16px; }

.CodeMirror-lint-tooltip { background-color: rgb(255, 255, 221); border: 1p=
x solid black; border-radius: 4px; color: black; font-family: monospace; fo=
nt-size: 10pt; overflow: hidden; padding: 2px 5px; position: fixed; white-s=
pace: pre-wrap; z-index: 100; max-width: 600px; opacity: 0; transition: opa=
city 0.4s; }

.CodeMirror-lint-mark { background-position: left bottom; background-repeat=
: repeat-x; }

.CodeMirror-lint-mark-warning { background-image: url("data:image/png;base6=
4,iVBORw0KGgoAAAANSUhEUgAAAAQAAAADCAYAAAC09K7GAAAAAXNSR0IArs4c6QAAAAZiS0dEA=
P8A/wD/oL2nkwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB9sJFhQXEbhTg7YAAAAZdEVY=
dENvbW1lbnQAQ3JlYXRlZCB3aXRoIEdJTVBXgQ4XAAAAMklEQVQI12NkgIIvJ3QXMjAwdDN+OaE=
bysDA4MPAwNDNwMCwiOHLCd1zX07o6kBVGQEAKBANtobskNMAAAAASUVORK5CYII=3D"); }

.CodeMirror-lint-mark-error { background-image: url("data:image/png;base64,=
iVBORw0KGgoAAAANSUhEUgAAAAQAAAADCAYAAAC09K7GAAAAAXNSR0IArs4c6QAAAAZiS0dEAP8=
A/wD/oL2nkwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB9sJDw4cOCW1/KIAAAAZdEVYdE=
NvbW1lbnQAQ3JlYXRlZCB3aXRoIEdJTVBXgQ4XAAAAHElEQVQI12NggIL/DAz/GdA5/xkY/qPKM=
DAwAADLZwf5rvm+LQAAAABJRU5ErkJggg=3D=3D"); }

.CodeMirror-lint-marker { background-position: center center; background-re=
peat: no-repeat; cursor: pointer; display: inline-block; height: 16px; widt=
h: 16px; vertical-align: middle; position: relative; }

.CodeMirror-lint-message { padding-left: 18px; background-position: left to=
p; background-repeat: no-repeat; }

.CodeMirror-lint-marker-warning, .CodeMirror-lint-message-warning { backgro=
und-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAA=
AAoLQ9TAAAANlBMVEX/uwDvrwD/uwD/uwD/uwD/uwD/uwD/uwD/uwD6twD/uwAAAADurwD2tQD7=
uAD+ugAAAAD/uwDhmeTRAAAADHRSTlMJ8mN1EYcbmiixgACm7WbuAAAAVklEQVR42n3PUQqAIBB=
FUU1LLc3u/jdbOJoW1P08DA9Gba8+YWJ6gNJoNYIBzAA2chBth5kLmG9YUoG0NHAUwFXwO9LuBQ=
L1giCQb8gC9Oro2vp5rncCIY8L8uEx5ZkAAAAASUVORK5CYII=3D"); }

.CodeMirror-lint-marker-error, .CodeMirror-lint-message-error { background-=
image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoL=
Q9TAAAAHlBMVEW7AAC7AACxAAC7AAC7AAAAAAC4AAC5AAD///+7AAAUdclpAAAABnRSTlMXnORS=
iwCK0ZKSAAAATUlEQVR42mWPOQ7AQAgDuQLx/z8csYRmPRIFIwRGnosRrpamvkKi0FTIiMASR3h=
hKW+hAN6/tIWhu9PDWiTGNEkTtIOucA5Oyr9ckPgAWm0GPBog6v4AAAAASUVORK5CYII=3D"); =
}

.CodeMirror-lint-marker-multiple { background-image: url("data:image/png;ba=
se64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAHCAMAAADzjKfhAAAACVBMVEUAAAAAAAC/v7914k=
yHAAAAAXRSTlMAQObYZgAAACNJREFUeNo1ioEJAAAIwmz/H90iFFSGJgFMe3gaLZ0od+9/AQZ0A=
DosbYraAAAAAElFTkSuQmCC"); background-repeat: no-repeat; background-positio=
n: right bottom; width: 100%; height: 100%; }

.CodeMirror-lint-line-error { background-color: rgba(183, 76, 81, 0.08); }

.CodeMirror-lint-line-warning { background-color: rgba(255, 211, 0, 0.1); }
------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: text/css
Content-Transfer-Encoding: quoted-printable
Content-Location: http://localhost/phpmyadmin/js/vendor/codemirror/addon/hint/show-hint.css?v=5.2.1

@charset "utf-8";

.CodeMirror-hints { position: absolute; z-index: 10; overflow: hidden auto;=
 list-style: none; margin: 0px; padding: 2px; box-shadow: rgba(0, 0, 0, 0.2=
) 2px 3px 5px; border-radius: 3px; border: 1px solid silver; background: wh=
ite; font-size: 90%; font-family: monospace; max-height: 20em; box-sizing: =
border-box; }

.CodeMirror-hint { margin: 0px; padding: 0px 4px; border-radius: 2px; white=
-space: pre; color: black; cursor: pointer; }

li.CodeMirror-hint-active { background: rgb(0, 136, 255); color: white; }
------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: text/css
Content-Transfer-Encoding: quoted-printable
Content-Location: http://localhost/phpmyadmin/js/vendor/codemirror/lib/codemirror.css?v=5.2.1

@charset "utf-8";

.CodeMirror { font-family: monospace; height: 300px; color: black; directio=
n: ltr; }

.CodeMirror-lines { padding: 4px 0px; }

.CodeMirror pre.CodeMirror-line, .CodeMirror pre.CodeMirror-line-like { pad=
ding: 0px 4px; }

.CodeMirror-scrollbar-filler, .CodeMirror-gutter-filler { background-color:=
 white; }

.CodeMirror-gutters { border-right: 1px solid rgb(221, 221, 221); backgroun=
d-color: rgb(247, 247, 247); white-space: nowrap; }

.CodeMirror-linenumbers { }

.CodeMirror-linenumber { padding: 0px 3px 0px 5px; min-width: 20px; text-al=
ign: right; color: rgb(153, 153, 153); white-space: nowrap; }

.CodeMirror-guttermarker { color: black; }

.CodeMirror-guttermarker-subtle { color: rgb(153, 153, 153); }

.CodeMirror-cursor { border-left: 1px solid black; border-right: none; widt=
h: 0px; }

.CodeMirror div.CodeMirror-secondarycursor { border-left: 1px solid silver;=
 }

.cm-fat-cursor .CodeMirror-cursor { width: auto; background: rgb(119, 238, =
119); border: 0px !important; }

.cm-fat-cursor div.CodeMirror-cursors { z-index: 1; }

.cm-fat-cursor .CodeMirror-line::selection, .cm-fat-cursor .CodeMirror-line=
 > span::selection, .cm-fat-cursor .CodeMirror-line > span > span::selectio=
n { background: transparent; }

.cm-fat-cursor { caret-color: transparent; }

@-webkit-keyframes blink {=20
  0% { }
  50% { background-color: transparent; }
  100% { }
}

@keyframes blink {=20
  0% { }
  50% { background-color: transparent; }
  100% { }
}

.CodeMirror-overwrite .CodeMirror-cursor { }

.cm-tab { display: inline-block; text-decoration: inherit; }

.CodeMirror-rulers { position: absolute; inset: -50px 0px 0px; overflow: hi=
dden; }

.CodeMirror-ruler { border-left: 1px solid rgb(204, 204, 204); top: 0px; bo=
ttom: 0px; position: absolute; }

.cm-s-default .cm-header { color: blue; }

.cm-s-default .cm-quote { color: rgb(0, 153, 0); }

.cm-negative { color: rgb(221, 68, 68); }

.cm-positive { color: rgb(34, 153, 34); }

.cm-header, .cm-strong { font-weight: bold; }

.cm-em { font-style: italic; }

.cm-link { text-decoration: underline; }

.cm-strikethrough { text-decoration: line-through; }

.cm-s-default .cm-keyword { color: rgb(119, 0, 136); }

.cm-s-default .cm-atom { color: rgb(34, 17, 153); }

.cm-s-default .cm-number { color: rgb(17, 102, 68); }

.cm-s-default .cm-def { color: rgb(0, 0, 255); }

.cm-s-default .cm-variable, .cm-s-default .cm-punctuation, .cm-s-default .c=
m-property, .cm-s-default .cm-operator { }

.cm-s-default .cm-variable-2 { color: rgb(0, 85, 170); }

.cm-s-default .cm-variable-3, .cm-s-default .cm-type { color: rgb(0, 136, 8=
5); }

.cm-s-default .cm-comment { color: rgb(170, 85, 0); }

.cm-s-default .cm-string { color: rgb(170, 17, 17); }

.cm-s-default .cm-string-2 { color: rgb(255, 85, 0); }

.cm-s-default .cm-meta { color: rgb(85, 85, 85); }

.cm-s-default .cm-qualifier { color: rgb(85, 85, 85); }

.cm-s-default .cm-builtin { color: rgb(51, 0, 170); }

.cm-s-default .cm-bracket { color: rgb(153, 153, 119); }

.cm-s-default .cm-tag { color: rgb(17, 119, 0); }

.cm-s-default .cm-attribute { color: rgb(0, 0, 204); }

.cm-s-default .cm-hr { color: rgb(153, 153, 153); }

.cm-s-default .cm-link { color: rgb(0, 0, 204); }

.cm-s-default .cm-error { color: rgb(255, 0, 0); }

.cm-invalidchar { color: rgb(255, 0, 0); }

.CodeMirror-composing { border-bottom: 2px solid; }

div.CodeMirror span.CodeMirror-matchingbracket { color: rgb(0, 187, 0); }

div.CodeMirror span.CodeMirror-nonmatchingbracket { color: rgb(170, 34, 34)=
; }

.CodeMirror-matchingtag { background: rgba(255, 150, 0, 0.3); }

.CodeMirror-activeline-background { background: rgb(232, 242, 255); }

.CodeMirror { position: relative; overflow: hidden; background: white; }

.CodeMirror-scroll { margin-bottom: -50px; margin-right: -50px; padding-bot=
tom: 50px; height: 100%; outline: none; position: relative; z-index: 0; ove=
rflow: scroll !important; }

.CodeMirror-sizer { position: relative; border-right: 50px solid transparen=
t; }

.CodeMirror-vscrollbar, .CodeMirror-hscrollbar, .CodeMirror-scrollbar-fille=
r, .CodeMirror-gutter-filler { position: absolute; z-index: 6; display: non=
e; outline: none; }

.CodeMirror-vscrollbar { right: 0px; top: 0px; overflow: hidden scroll; }

.CodeMirror-hscrollbar { bottom: 0px; left: 0px; overflow: scroll hidden; }

.CodeMirror-scrollbar-filler { right: 0px; bottom: 0px; }

.CodeMirror-gutter-filler { left: 0px; bottom: 0px; }

.CodeMirror-gutters { position: absolute; left: 0px; top: 0px; min-height: =
100%; z-index: 3; }

.CodeMirror-gutter { white-space: normal; height: 100%; display: inline-blo=
ck; vertical-align: top; margin-bottom: -50px; }

.CodeMirror-gutter-wrapper { position: absolute; z-index: 4; background: no=
ne !important; border: none !important; }

.CodeMirror-gutter-background { position: absolute; top: 0px; bottom: 0px; =
z-index: 4; }

.CodeMirror-gutter-elt { position: absolute; cursor: default; z-index: 4; }

.CodeMirror-gutter-wrapper ::selection { background-color: transparent; }

.CodeMirror-lines { cursor: text; min-height: 1px; }

.CodeMirror pre.CodeMirror-line, .CodeMirror pre.CodeMirror-line-like { bor=
der-radius: 0px; border-width: 0px; background: transparent; font-family: i=
nherit; font-size: inherit; margin: 0px; white-space: pre; overflow-wrap: n=
ormal; line-height: inherit; color: inherit; z-index: 2; position: relative=
; overflow: visible; -webkit-tap-highlight-color: transparent; font-variant=
-ligatures: contextual; }

.CodeMirror-wrap pre.CodeMirror-line, .CodeMirror-wrap pre.CodeMirror-line-=
like { overflow-wrap: break-word; white-space: pre-wrap; word-break: normal=
; }

.CodeMirror-linebackground { position: absolute; inset: 0px; z-index: 0; }

.CodeMirror-linewidget { position: relative; z-index: 2; padding: 0.1px; }

.CodeMirror-widget { }

.CodeMirror-rtl pre { direction: rtl; }

.CodeMirror-code { outline: none; }

.CodeMirror-scroll, .CodeMirror-sizer, .CodeMirror-gutter, .CodeMirror-gutt=
ers, .CodeMirror-linenumber { box-sizing: content-box; }

.CodeMirror-measure { position: absolute; width: 100%; height: 0px; overflo=
w: hidden; visibility: hidden; }

.CodeMirror-cursor { position: absolute; pointer-events: none; }

.CodeMirror-measure pre { position: static; }

div.CodeMirror-cursors { visibility: hidden; position: relative; z-index: 3=
; }

div.CodeMirror-dragcursors { visibility: visible; }

.CodeMirror-focused div.CodeMirror-cursors { visibility: visible; }

.CodeMirror-selected { background: rgb(217, 217, 217); }

.CodeMirror-focused .CodeMirror-selected { background: rgb(215, 212, 240); =
}

.CodeMirror-crosshair { cursor: crosshair; }

.CodeMirror-line::selection, .CodeMirror-line > span::selection, .CodeMirro=
r-line > span > span::selection { background: rgb(215, 212, 240); }

.cm-searching { background-color: rgba(255, 255, 0, 0.4); }

.cm-force-border { padding-right: 0.1px; }

@media print {
  .CodeMirror div.CodeMirror-cursors { visibility: hidden; }
}

.cm-tab-wrap-hack::after { content: ""; }

span.CodeMirror-selectedtext { background: none; }
------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: text/css
Content-Transfer-Encoding: quoted-printable
Content-Location: http://localhost/phpmyadmin/themes/pmahomme/jquery/jquery-ui.css

@charset "utf-8";

.ui-draggable-handle { touch-action: none; }

.ui-helper-hidden { display: none; }

.ui-helper-hidden-accessible { border: 0px; clip: rect(0px, 0px, 0px, 0px);=
 height: 1px; margin: -1px; overflow: hidden; padding: 0px; position: absol=
ute; width: 1px; }

.ui-helper-reset { margin: 0px; padding: 0px; border: 0px; outline: 0px; li=
ne-height: 1.3; text-decoration: none; font-size: 100%; list-style: none; }

.ui-helper-clearfix::before, .ui-helper-clearfix::after { content: ""; disp=
lay: table; border-collapse: collapse; }

.ui-helper-clearfix::after { clear: both; }

.ui-helper-zfix { width: 100%; height: 100%; top: 0px; left: 0px; position:=
 absolute; opacity: 0; }

.ui-front { z-index: 100; }

.ui-state-disabled { cursor: default !important; pointer-events: none; }

.ui-icon { display: inline-block; vertical-align: middle; margin-top: -0.25=
em; position: relative; text-indent: -99999px; overflow: hidden; background=
-repeat: no-repeat; }

.ui-widget-icon-block { left: 50%; margin-left: -8px; display: block; }

.ui-widget-overlay { position: fixed; top: 0px; left: 0px; width: 100%; hei=
ght: 100%; }

.ui-resizable { position: relative; }

.ui-resizable-handle { position: absolute; font-size: 0.1px; display: block=
; touch-action: none; }

.ui-resizable-disabled .ui-resizable-handle, .ui-resizable-autohide .ui-res=
izable-handle { display: none; }

.ui-resizable-n { cursor: n-resize; height: 7px; width: 100%; top: -5px; le=
ft: 0px; }

.ui-resizable-s { cursor: s-resize; height: 7px; width: 100%; bottom: -5px;=
 left: 0px; }

.ui-resizable-e { cursor: e-resize; width: 7px; right: -5px; top: 0px; heig=
ht: 100%; }

.ui-resizable-w { cursor: w-resize; width: 7px; left: -5px; top: 0px; heigh=
t: 100%; }

.ui-resizable-se { cursor: se-resize; width: 12px; height: 12px; right: 1px=
; bottom: 1px; }

.ui-resizable-sw { cursor: sw-resize; width: 9px; height: 9px; left: -5px; =
bottom: -5px; }

.ui-resizable-nw { cursor: nw-resize; width: 9px; height: 9px; left: -5px; =
top: -5px; }

.ui-resizable-ne { cursor: ne-resize; width: 9px; height: 9px; right: -5px;=
 top: -5px; }

.ui-selectable { touch-action: none; }

.ui-selectable-helper { position: absolute; z-index: 100; border: 1px dotte=
d black; }

.ui-sortable-handle { touch-action: none; }

.ui-accordion .ui-accordion-header { display: block; cursor: pointer; posit=
ion: relative; margin: 2px 0px 0px; padding: 0.5em 0.5em 0.5em 0.7em; font-=
size: 100%; }

.ui-accordion .ui-accordion-content { padding: 1em 2.2em; border-top: 0px; =
overflow: auto; }

.ui-autocomplete { position: absolute; top: 0px; left: 0px; cursor: default=
; }

.ui-menu { list-style: none; padding: 0px; margin: 0px; display: block; out=
line: 0px; }

.ui-menu .ui-menu { position: absolute; }

.ui-menu .ui-menu-item { margin: 0px; cursor: pointer; list-style-image: ur=
l("data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAA=
IBRAA7"); }

.ui-menu .ui-menu-item-wrapper { position: relative; padding: 3px 1em 3px 0=
.4em; }

.ui-menu .ui-menu-divider { margin: 5px 0px; height: 0px; font-size: 0px; l=
ine-height: 0; border-width: 1px 0px 0px; }

.ui-menu .ui-state-focus, .ui-menu .ui-state-active { margin: -1px; }

.ui-menu-icons { position: relative; }

.ui-menu-icons .ui-menu-item-wrapper { padding-left: 2em; }

.ui-menu .ui-icon { position: absolute; top: 0px; bottom: 0px; left: 0.2em;=
 margin: auto 0px; }

.ui-menu .ui-menu-icon { left: auto; right: 0px; }

.ui-button { padding: 0.4em 1em; display: inline-block; position: relative;=
 line-height: normal; margin-right: 0.1em; cursor: pointer; vertical-align:=
 middle; text-align: center; user-select: none; overflow: visible; }

.ui-button, .ui-button:link, .ui-button:visited, .ui-button:hover, .ui-butt=
on:active { text-decoration: none; }

.ui-button-icon-only { width: 2em; box-sizing: border-box; text-indent: -99=
99px; white-space: nowrap; }

input.ui-button.ui-button-icon-only { text-indent: 0px; }

.ui-button-icon-only .ui-icon { position: absolute; top: 50%; left: 50%; ma=
rgin-top: -8px; margin-left: -8px; }

.ui-button.ui-icon-notext .ui-icon { padding: 0px; width: 2.1em; height: 2.=
1em; text-indent: -9999px; white-space: nowrap; }

input.ui-button.ui-icon-notext .ui-icon { width: auto; height: auto; text-i=
ndent: 0px; white-space: normal; padding: 0.4em 1em; }

.ui-controlgroup { vertical-align: middle; display: inline-block; }

.ui-controlgroup > .ui-controlgroup-item { float: left; margin-left: 0px; m=
argin-right: 0px; }

.ui-controlgroup > .ui-controlgroup-item:focus, .ui-controlgroup > .ui-cont=
rolgroup-item.ui-visual-focus { z-index: 9999; }

.ui-controlgroup-vertical > .ui-controlgroup-item { display: block; float: =
none; width: 100%; margin-top: 0px; margin-bottom: 0px; text-align: left; }

.ui-controlgroup-vertical .ui-controlgroup-item { box-sizing: border-box; }

.ui-controlgroup .ui-controlgroup-label { padding: 0.4em 1em; }

.ui-controlgroup .ui-controlgroup-label span { font-size: 80%; }

.ui-controlgroup-horizontal .ui-controlgroup-label + .ui-controlgroup-item =
{ border-left: none; }

.ui-controlgroup-vertical .ui-controlgroup-label + .ui-controlgroup-item { =
border-top: none; }

.ui-controlgroup-horizontal .ui-controlgroup-label.ui-widget-content { bord=
er-right: none; }

.ui-controlgroup-vertical .ui-controlgroup-label.ui-widget-content { border=
-bottom: none; }

.ui-controlgroup-vertical .ui-spinner-input { width: calc(100% - 2.4em); }

.ui-controlgroup-vertical .ui-spinner .ui-spinner-up { border-top-style: so=
lid; }

.ui-checkboxradio-label .ui-icon-background { box-shadow: rgb(204, 204, 204=
) 1px 1px 1px inset; border-radius: 0.12em; border: none; }

.ui-checkboxradio-radio-label .ui-icon-background { width: 16px; height: 16=
px; border-radius: 1em; overflow: visible; border: none; }

.ui-checkboxradio-radio-label.ui-checkboxradio-checked .ui-icon, .ui-checkb=
oxradio-radio-label.ui-checkboxradio-checked:hover .ui-icon { background-im=
age: none; width: 8px; height: 8px; border-width: 4px; border-style: solid;=
 }

.ui-checkboxradio-disabled { pointer-events: none; }

.ui-datepicker { width: 17em; padding: 0.2em 0.2em 0px; display: none; }

.ui-datepicker .ui-datepicker-header { position: relative; padding: 0.2em 0=
px; }

.ui-datepicker .ui-datepicker-prev, .ui-datepicker .ui-datepicker-next { po=
sition: absolute; top: 2px; width: 1.8em; height: 1.8em; }

.ui-datepicker .ui-datepicker-prev-hover, .ui-datepicker .ui-datepicker-nex=
t-hover { top: 1px; }

.ui-datepicker .ui-datepicker-prev { left: 2px; }

.ui-datepicker .ui-datepicker-next { right: 2px; }

.ui-datepicker .ui-datepicker-prev-hover { left: 1px; }

.ui-datepicker .ui-datepicker-next-hover { right: 1px; }

.ui-datepicker .ui-datepicker-prev span, .ui-datepicker .ui-datepicker-next=
 span { display: block; position: absolute; left: 50%; margin-left: -8px; t=
op: 50%; margin-top: -8px; }

.ui-datepicker .ui-datepicker-title { margin: 0px 2.3em; line-height: 1.8em=
; text-align: center; }

.ui-datepicker .ui-datepicker-title select { font-size: 1em; margin: 1px 0p=
x; }

.ui-datepicker select.ui-datepicker-month, .ui-datepicker select.ui-datepic=
ker-year { width: 45%; }

.ui-datepicker table { width: 100%; font-size: 0.9em; border-collapse: coll=
apse; margin: 0px 0px 0.4em; }

.ui-datepicker th { padding: 0.7em 0.3em; text-align: center; font-weight: =
bold; border: 0px; }

.ui-datepicker td { border: 0px; padding: 1px; }

.ui-datepicker td span, .ui-datepicker td a { display: block; padding: 0.2e=
m; text-align: right; text-decoration: none; }

.ui-datepicker .ui-datepicker-buttonpane { background-image: none; margin: =
0.7em 0px 0px; padding: 0px 0.2em; border-left: 0px; border-right: 0px; bor=
der-bottom: 0px; }

.ui-datepicker .ui-datepicker-buttonpane button { float: right; margin: 0.5=
em 0.2em 0.4em; cursor: pointer; padding: 0.2em 0.6em 0.3em; width: auto; o=
verflow: visible; }

.ui-datepicker .ui-datepicker-buttonpane button.ui-datepicker-current { flo=
at: left; }

.ui-datepicker.ui-datepicker-multi { width: auto; }

.ui-datepicker-multi .ui-datepicker-group { float: left; }

.ui-datepicker-multi .ui-datepicker-group table { width: 95%; margin: 0px a=
uto 0.4em; }

.ui-datepicker-multi-2 .ui-datepicker-group { width: 50%; }

.ui-datepicker-multi-3 .ui-datepicker-group { width: 33.3%; }

.ui-datepicker-multi-4 .ui-datepicker-group { width: 25%; }

.ui-datepicker-multi .ui-datepicker-group-last .ui-datepicker-header, .ui-d=
atepicker-multi .ui-datepicker-group-middle .ui-datepicker-header { border-=
left-width: 0px; }

.ui-datepicker-multi .ui-datepicker-buttonpane { clear: left; }

.ui-datepicker-row-break { clear: both; width: 100%; font-size: 0px; }

.ui-datepicker-rtl { direction: rtl; }

.ui-datepicker-rtl .ui-datepicker-prev { right: 2px; left: auto; }

.ui-datepicker-rtl .ui-datepicker-next { left: 2px; right: auto; }

.ui-datepicker-rtl .ui-datepicker-prev:hover { right: 1px; left: auto; }

.ui-datepicker-rtl .ui-datepicker-next:hover { left: 1px; right: auto; }

.ui-datepicker-rtl .ui-datepicker-buttonpane { clear: right; }

.ui-datepicker-rtl .ui-datepicker-buttonpane button { float: left; }

.ui-datepicker-rtl .ui-datepicker-buttonpane button.ui-datepicker-current, =
.ui-datepicker-rtl .ui-datepicker-group { float: right; }

.ui-datepicker-rtl .ui-datepicker-group-last .ui-datepicker-header, .ui-dat=
epicker-rtl .ui-datepicker-group-middle .ui-datepicker-header { border-righ=
t-width: 0px; border-left-width: 1px; }

.ui-datepicker .ui-icon { display: block; text-indent: -99999px; overflow: =
hidden; background-repeat: no-repeat; left: 0.5em; top: 0.3em; }

.ui-dialog { position: absolute; top: 0px; left: 0px; padding: 0.2em; outli=
ne: 0px; }

.ui-dialog .ui-dialog-titlebar { padding: 0.4em 1em; position: relative; }

.ui-dialog .ui-dialog-title { float: left; margin: 0.1em 0px; white-space: =
nowrap; width: 90%; overflow: hidden; text-overflow: ellipsis; }

.ui-dialog .ui-dialog-titlebar-close { position: absolute; right: 0.3em; to=
p: 50%; width: 20px; margin: -10px 0px 0px; padding: 1px; height: 20px; }

.ui-dialog .ui-dialog-content { position: relative; border: 0px; padding: 0=
.5em 1em; background: none; overflow: auto; }

.ui-dialog .ui-dialog-buttonpane { text-align: left; border-width: 1px 0px =
0px; background-image: none; margin-top: 0.5em; padding: 0.3em 1em 0.5em 0.=
4em; }

.ui-dialog .ui-dialog-buttonpane .ui-dialog-buttonset { float: right; }

.ui-dialog .ui-dialog-buttonpane button { margin: 0.5em 0.4em 0.5em 0px; cu=
rsor: pointer; }

.ui-dialog .ui-resizable-n { height: 2px; top: 0px; }

.ui-dialog .ui-resizable-e { width: 2px; right: 0px; }

.ui-dialog .ui-resizable-s { height: 2px; bottom: 0px; }

.ui-dialog .ui-resizable-w { width: 2px; left: 0px; }

.ui-dialog .ui-resizable-se, .ui-dialog .ui-resizable-sw, .ui-dialog .ui-re=
sizable-ne, .ui-dialog .ui-resizable-nw { width: 7px; height: 7px; }

.ui-dialog .ui-resizable-se { right: 0px; bottom: 0px; }

.ui-dialog .ui-resizable-sw { left: 0px; bottom: 0px; }

.ui-dialog .ui-resizable-ne { right: 0px; top: 0px; }

.ui-dialog .ui-resizable-nw { left: 0px; top: 0px; }

.ui-draggable .ui-dialog-titlebar { cursor: move; }

.ui-progressbar { height: 2em; text-align: left; overflow: hidden; }

.ui-progressbar .ui-progressbar-value { margin: -1px; height: 100%; }

.ui-progressbar .ui-progressbar-overlay { background: url("data:image/gif;b=
ase64,R0lGODlhKAAoAIABAAAAAP///yH/C05FVFNDQVBFMi4wAwEAAAAh+QQJAQABACwAAAAAK=
AAoAAACkYwNqXrdC52DS06a7MFZI+4FHBCKoDeWKXqymPqGqxvJrXZbMx7Ttc+w9XgU2FB3lOyQ=
RWET2IFGiU9m1frDVpxZZc6bfHwv4c1YXP6k1Vdy292Fb6UkuvFtXpvWSzA+HycXJHUXiGYIiMg=
2R6W459gnWGfHNdjIqDWVqemH2ekpObkpOlppWUqZiqr6edqqWQAAIfkECQEAAQAsAAAAACgAKA=
AAApSMgZnGfaqcg1E2uuzDmmHUBR8Qil95hiPKqWn3aqtLsS18y7G1SzNeowWBENtQd+T1JktP0=
5nzPTdJZlR6vUxNWWjV+vUWhWNkWFwxl9VpZRedYcflIOLafaa28XdsH/ynlcc1uPVDZxQIR0K2=
5+cICCmoqCe5mGhZOfeYSUh5yJcJyrkZWWpaR8doJ2o4NYq62lAAACH5BAkBAAEALAAAAAAoACg=
AAAKVDI4Yy22ZnINRNqosw0Bv7i1gyHUkFj7oSaWlu3ovC8GxNso5fluz3qLVhBVeT/Lz7ZTHyx=
L5dDalQWPVOsQWtRnuwXaFTj9jVVh8pma9JjZ4zYSj5ZOyma7uuolffh+IR5aW97cHuBUXKGKXl=
Kjn+DiHWMcYJah4N0lYCMlJOXipGRr5qdgoSTrqWSq6WFl2ypoaUAAAIfkECQEAAQAsAAAAACgA=
KAAAApaEb6HLgd/iO7FNWtcFWe+ufODGjRfoiJ2akShbueb0wtI50zm02pbvwfWEMWBQ1zKGlLI=
hskiEPm9R6vRXxV4ZzWT2yHOGpWMyorblKlNp8HmHEb/lCXjcW7bmtXP8Xt229OVWR1fod2eWqN=
fHuMjXCPkIGNileOiImVmCOEmoSfn3yXlJWmoHGhqp6ilYuWYpmTqKUgAAIfkECQEAAQAsAAAAA=
CgAKAAAApiEH6kb58biQ3FNWtMFWW3eNVcojuFGfqnZqSebuS06w5V80/X02pKe8zFwP6EFWOT1=
lDFk8rGERh1TTNOocQ61Hm4Xm2VexUHpzjymViHrFbiELsefVrn6XKfnt2Q9G/+Xdie499XHd2g=
4h7ioOGhXGJboGAnXSBnoBwKYyfioubZJ2Hn0RuRZaflZOil56Zp6iioKSXpUAAAh+QQJAQABAC=
wAAAAAKAAoAAACkoQRqRvnxuI7kU1a1UU5bd5tnSeOZXhmn5lWK3qNTWvRdQxP8qvaC+/yaYQzX=
O7BMvaUEmJRd3TsiMAgswmNYrSgZdYrTX6tSHGZO73ezuAw2uxuQ+BbeZfMxsexY35+/Qe4J1in=
V0g4x3WHuMhIl2jXOKT2Q+VU5fgoSUI52VfZyfkJGkha6jmY+aaYdirq+lQAACH5BAkBAAEALAA=
AAAAoACgAAAKWBIKpYe0L3YNKToqswUlvznigd4wiR4KhZrKt9Upqip61i9E3vMvxRdHlbEFiEX=
fk9YARYxOZZD6VQ2pUunBmtRXo1Lf8hMVVcNl8JafV38aM2/Fu5V16Bn63r6xt97j09+MXSFi4B=
niGFae3hzbH9+hYBzkpuUh5aZmHuanZOZgIuvbGiNeomCnaxxap2upaCZsq+1kAACH5BAkBAAEA=
LAAAAAAoACgAAAKXjI8By5zf4kOxTVrXNVlv1X0d8IGZGKLnNpYtm8Lr9cqVeuOSvfOW79D9aDH=
izNhDJidFZhNydEahOaDH6nomtJjp1tutKoNWkvA6JqfRVLHU/QUfau9l2x7G54d1fl995xcIGA=
dXqMfBNadoYrhH+Mg2KBlpVpbluCiXmMnZ2Sh4GBqJ+ckIOqqJ6LmKSllZmsoq6wpQAAAh+QQJA=
QABACwAAAAAKAAoAAAClYx/oLvoxuJDkU1a1YUZbJ59nSd2ZXhWqbRa2/gF8Gu2DY3iqs7yrq+x=
BYEkYvFSM8aSSObE+ZgRl1BHFZNr7pRCavZ5BW2142hY3AN/zWtsmf12p9XxxFl2lpLn1rseztf=
XZjdIWIf2s5dItwjYKBgo9yg5pHgzJXTEeGlZuenpyPmpGQoKOWkYmSpaSnqKileI2FAAACH5BA=
kBAAEALAAAAAAoACgAAAKVjB+gu+jG4kORTVrVhRlsnn2dJ3ZleFaptFrb+CXmO9OozeL5VfP99=
HvAWhpiUdcwkpBH3825AwYdU8xTqlLGhtCosArKMpvfa1mMRae9VvWZfeB2XfPkeLmm18lUcBj+=
p5dnN8jXZ3YIGEhYuOUn45aoCDkp16hl5IjYJvjWKcnoGQpqyPlpOhr3aElaqrq56Bq7VAAAOw=
=3D=3D"); height: 100%; opacity: 0.25; }

.ui-progressbar-indeterminate .ui-progressbar-value { background-image: non=
e; }

.ui-selectmenu-menu { padding: 0px; margin: 0px; position: absolute; top: 0=
px; left: 0px; display: none; }

.ui-selectmenu-menu .ui-menu { overflow: hidden auto; padding-bottom: 1px; =
}

.ui-selectmenu-menu .ui-menu .ui-selectmenu-optgroup { font-size: 1em; font=
-weight: bold; line-height: 1.5; padding: 2px 0.4em; margin: 0.5em 0px 0px;=
 height: auto; border: 0px; }

.ui-selectmenu-open { display: block; }

.ui-selectmenu-text { display: block; margin-right: 20px; overflow: hidden;=
 text-overflow: ellipsis; }

.ui-selectmenu-button.ui-button { text-align: left; white-space: nowrap; wi=
dth: 14em; }

.ui-selectmenu-icon.ui-icon { float: right; margin-top: 0px; }

.ui-slider { position: relative; text-align: left; }

.ui-slider .ui-slider-handle { position: absolute; z-index: 2; width: 1.2em=
; height: 1.2em; cursor: default; touch-action: none; }

.ui-slider .ui-slider-range { position: absolute; z-index: 1; font-size: 0.=
7em; display: block; border: 0px; background-position: 0px 0px; }

.ui-slider.ui-state-disabled .ui-slider-handle, .ui-slider.ui-state-disable=
d .ui-slider-range { filter: inherit; }

.ui-slider-horizontal { height: 0.8em; }

.ui-slider-horizontal .ui-slider-handle { top: -0.3em; margin-left: -0.6em;=
 }

.ui-slider-horizontal .ui-slider-range { top: 0px; height: 100%; }

.ui-slider-horizontal .ui-slider-range-min { left: 0px; }

.ui-slider-horizontal .ui-slider-range-max { right: 0px; }

.ui-slider-vertical { width: 0.8em; height: 100px; }

.ui-slider-vertical .ui-slider-handle { left: -0.3em; margin-left: 0px; mar=
gin-bottom: -0.6em; }

.ui-slider-vertical .ui-slider-range { left: 0px; width: 100%; }

.ui-slider-vertical .ui-slider-range-min { bottom: 0px; }

.ui-slider-vertical .ui-slider-range-max { top: 0px; }

.ui-spinner { position: relative; display: inline-block; overflow: hidden; =
padding: 0px; vertical-align: middle; }

.ui-spinner-input { border: none; background: none; color: inherit; padding=
: 0.222em 0px; margin: 0.2em 2em 0.2em 0.4em; vertical-align: middle; }

.ui-spinner-button { width: 1.6em; height: 50%; font-size: 0.5em; padding: =
0px; margin: 0px; text-align: center; position: absolute; cursor: default; =
display: block; overflow: hidden; right: 0px; }

.ui-spinner a.ui-spinner-button { border-top-style: none; border-bottom-sty=
le: none; border-right-style: none; }

.ui-spinner-up { top: 0px; }

.ui-spinner-down { bottom: 0px; }

.ui-tabs { position: relative; padding: 0.2em; }

.ui-tabs .ui-tabs-nav { margin: 0px; padding: 0.2em 0.2em 0px; }

.ui-tabs .ui-tabs-nav li { list-style: none; float: left; position: relativ=
e; top: 0px; margin: 1px 0.2em 0px 0px; border-bottom-width: 0px; padding: =
0px; white-space: nowrap; }

.ui-tabs .ui-tabs-nav .ui-tabs-anchor { float: left; padding: 0.5em 1em; te=
xt-decoration: none; }

.ui-tabs .ui-tabs-nav li.ui-tabs-active { margin-bottom: -1px; padding-bott=
om: 1px; }

.ui-tabs .ui-tabs-nav li.ui-tabs-active .ui-tabs-anchor, .ui-tabs .ui-tabs-=
nav li.ui-state-disabled .ui-tabs-anchor, .ui-tabs .ui-tabs-nav li.ui-tabs-=
loading .ui-tabs-anchor { cursor: text; }

.ui-tabs-collapsible .ui-tabs-nav li.ui-tabs-active .ui-tabs-anchor { curso=
r: pointer; }

.ui-tabs .ui-tabs-panel { display: block; border-width: 0px; padding: 1em 1=
.4em; background: none; }

.ui-tooltip { padding: 8px; position: absolute; z-index: 9999; max-width: 3=
00px; }

body .ui-tooltip { border-width: 2px; }

.ui-widget { font-family: Verdana, Arial, sans-serif; font-size: 1.1em; }

.ui-widget .ui-widget { font-size: 1em; }

.ui-widget input, .ui-widget select, .ui-widget textarea, .ui-widget button=
 { font-family: Verdana, Arial, sans-serif; font-size: 1em; }

.ui-widget.ui-widget-content { border: 1px solid rgb(211, 211, 211); }

.ui-widget-content { border: 1px solid rgb(170, 170, 170); background: rgb(=
255, 255, 255); color: rgb(34, 34, 34); }

.ui-widget-content a { color: rgb(34, 34, 34); }

.ui-widget-header { border: 1px solid rgb(170, 170, 170); background: url("=
images/ui-bg_highlight-soft_75_cccccc_1x100.png") 50% 50% repeat-x rgb(204,=
 204, 204); color: rgb(34, 34, 34); font-weight: bold; }

.ui-widget-header a { color: rgb(34, 34, 34); }

.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header =
.ui-state-default, .ui-button, html .ui-button.ui-state-disabled:hover, htm=
l .ui-button.ui-state-disabled:active { border: 1px solid rgb(211, 211, 211=
); background: url("images/ui-bg_glass_75_e6e6e6_1x400.png") 50% 50% repeat=
-x rgb(230, 230, 230); font-weight: normal; color: rgb(85, 85, 85); }

.ui-state-default a, .ui-state-default a:link, .ui-state-default a:visited,=
 a.ui-button, a:link.ui-button, a:visited.ui-button, .ui-button { color: rg=
b(85, 85, 85); text-decoration: none; }

.ui-state-hover, .ui-widget-content .ui-state-hover, .ui-widget-header .ui-=
state-hover, .ui-state-focus, .ui-widget-content .ui-state-focus, .ui-widge=
t-header .ui-state-focus, .ui-button:hover, .ui-button:focus { border: 1px =
solid rgb(153, 153, 153); background: url("images/ui-bg_glass_75_dadada_1x4=
00.png") 50% 50% repeat-x rgb(218, 218, 218); font-weight: normal; color: r=
gb(33, 33, 33); }

.ui-state-hover a, .ui-state-hover a:hover, .ui-state-hover a:link, .ui-sta=
te-hover a:visited, .ui-state-focus a, .ui-state-focus a:hover, .ui-state-f=
ocus a:link, .ui-state-focus a:visited, a.ui-button:hover, a.ui-button:focu=
s { color: rgb(33, 33, 33); text-decoration: none; }

.ui-visual-focus { box-shadow: rgb(94, 158, 214) 0px 0px 3px 1px; }

.ui-state-active, .ui-widget-content .ui-state-active, .ui-widget-header .u=
i-state-active, a.ui-button:active, .ui-button:active, .ui-button.ui-state-=
active:hover { border: 1px solid rgb(170, 170, 170); background: url("image=
s/ui-bg_glass_65_ffffff_1x400.png") 50% 50% repeat-x rgb(255, 255, 255); fo=
nt-weight: normal; color: rgb(33, 33, 33); }

.ui-icon-background, .ui-state-active .ui-icon-background { border: rgb(170=
, 170, 170); background-color: rgb(33, 33, 33); }

.ui-state-active a, .ui-state-active a:link, .ui-state-active a:visited { c=
olor: rgb(33, 33, 33); text-decoration: none; }

.ui-state-highlight, .ui-widget-content .ui-state-highlight, .ui-widget-hea=
der .ui-state-highlight { border: 1px solid rgb(252, 239, 161); background:=
 url("images/ui-bg_glass_55_fbf9ee_1x400.png") 50% 50% repeat-x rgb(251, 24=
9, 238); color: rgb(54, 54, 54); }

.ui-state-checked { border: 1px solid rgb(252, 239, 161); background: rgb(2=
51, 249, 238); }

.ui-state-highlight a, .ui-widget-content .ui-state-highlight a, .ui-widget=
-header .ui-state-highlight a { color: rgb(54, 54, 54); }

.ui-state-error, .ui-widget-content .ui-state-error, .ui-widget-header .ui-=
state-error { border: 1px solid rgb(205, 10, 10); background: url("images/u=
i-bg_glass_95_fef1ec_1x400.png") 50% 50% repeat-x rgb(254, 241, 236); color=
: rgb(205, 10, 10); }

.ui-state-error a, .ui-widget-content .ui-state-error a, .ui-widget-header =
.ui-state-error a { color: rgb(205, 10, 10); }

.ui-state-error-text, .ui-widget-content .ui-state-error-text, .ui-widget-h=
eader .ui-state-error-text { color: rgb(205, 10, 10); }

.ui-priority-primary, .ui-widget-content .ui-priority-primary, .ui-widget-h=
eader .ui-priority-primary { font-weight: bold; }

.ui-priority-secondary, .ui-widget-content .ui-priority-secondary, .ui-widg=
et-header .ui-priority-secondary { opacity: 0.7; font-weight: normal; }

.ui-state-disabled, .ui-widget-content .ui-state-disabled, .ui-widget-heade=
r .ui-state-disabled { opacity: 0.35; background-image: none; }

.ui-state-disabled .ui-icon { }

.ui-icon { width: 16px; height: 16px; }

.ui-icon, .ui-widget-content .ui-icon { background-image: url("images/ui-ic=
ons_222222_256x240.png"); }

.ui-widget-header .ui-icon { background-image: url("images/ui-icons_222222_=
256x240.png"); }

.ui-state-hover .ui-icon, .ui-state-focus .ui-icon, .ui-button:hover .ui-ic=
on, .ui-button:focus .ui-icon { background-image: url("images/ui-icons_4545=
45_256x240.png"); }

.ui-state-active .ui-icon, .ui-button:active .ui-icon { background-image: u=
rl("images/ui-icons_454545_256x240.png"); }

.ui-state-highlight .ui-icon, .ui-button .ui-state-highlight.ui-icon { back=
ground-image: url("images/ui-icons_2e83ff_256x240.png"); }

.ui-state-error .ui-icon, .ui-state-error-text .ui-icon { background-image:=
 url("images/ui-icons_cd0a0a_256x240.png"); }

.ui-button .ui-icon { background-image: url("images/ui-icons_888888_256x240=
.png"); }

.ui-icon-blank { background-position: 16px 16px; }

.ui-icon-caret-1-n { background-position: 0px 0px; }

.ui-icon-caret-1-ne { background-position: -16px 0px; }

.ui-icon-caret-1-e { background-position: -32px 0px; }

.ui-icon-caret-1-se { background-position: -48px 0px; }

.ui-icon-caret-1-s { background-position: -65px 0px; }

.ui-icon-caret-1-sw { background-position: -80px 0px; }

.ui-icon-caret-1-w { background-position: -96px 0px; }

.ui-icon-caret-1-nw { background-position: -112px 0px; }

.ui-icon-caret-2-n-s { background-position: -128px 0px; }

.ui-icon-caret-2-e-w { background-position: -144px 0px; }

.ui-icon-triangle-1-n { background-position: 0px -16px; }

.ui-icon-triangle-1-ne { background-position: -16px -16px; }

.ui-icon-triangle-1-e { background-position: -32px -16px; }

.ui-icon-triangle-1-se { background-position: -48px -16px; }

.ui-icon-triangle-1-s { background-position: -65px -16px; }

.ui-icon-triangle-1-sw { background-position: -80px -16px; }

.ui-icon-triangle-1-w { background-position: -96px -16px; }

.ui-icon-triangle-1-nw { background-position: -112px -16px; }

.ui-icon-triangle-2-n-s { background-position: -128px -16px; }

.ui-icon-triangle-2-e-w { background-position: -144px -16px; }

.ui-icon-arrow-1-n { background-position: 0px -32px; }

.ui-icon-arrow-1-ne { background-position: -16px -32px; }

.ui-icon-arrow-1-e { background-position: -32px -32px; }

.ui-icon-arrow-1-se { background-position: -48px -32px; }

.ui-icon-arrow-1-s { background-position: -65px -32px; }

.ui-icon-arrow-1-sw { background-position: -80px -32px; }

.ui-icon-arrow-1-w { background-position: -96px -32px; }

.ui-icon-arrow-1-nw { background-position: -112px -32px; }

.ui-icon-arrow-2-n-s { background-position: -128px -32px; }

.ui-icon-arrow-2-ne-sw { background-position: -144px -32px; }

.ui-icon-arrow-2-e-w { background-position: -160px -32px; }

.ui-icon-arrow-2-se-nw { background-position: -176px -32px; }

.ui-icon-arrowstop-1-n { background-position: -192px -32px; }

.ui-icon-arrowstop-1-e { background-position: -208px -32px; }

.ui-icon-arrowstop-1-s { background-position: -224px -32px; }

.ui-icon-arrowstop-1-w { background-position: -240px -32px; }

.ui-icon-arrowthick-1-n { background-position: 1px -48px; }

.ui-icon-arrowthick-1-ne { background-position: -16px -48px; }

.ui-icon-arrowthick-1-e { background-position: -32px -48px; }

.ui-icon-arrowthick-1-se { background-position: -48px -48px; }

.ui-icon-arrowthick-1-s { background-position: -64px -48px; }

.ui-icon-arrowthick-1-sw { background-position: -80px -48px; }

.ui-icon-arrowthick-1-w { background-position: -96px -48px; }

.ui-icon-arrowthick-1-nw { background-position: -112px -48px; }

.ui-icon-arrowthick-2-n-s { background-position: -128px -48px; }

.ui-icon-arrowthick-2-ne-sw { background-position: -144px -48px; }

.ui-icon-arrowthick-2-e-w { background-position: -160px -48px; }

.ui-icon-arrowthick-2-se-nw { background-position: -176px -48px; }

.ui-icon-arrowthickstop-1-n { background-position: -192px -48px; }

.ui-icon-arrowthickstop-1-e { background-position: -208px -48px; }

.ui-icon-arrowthickstop-1-s { background-position: -224px -48px; }

.ui-icon-arrowthickstop-1-w { background-position: -240px -48px; }

.ui-icon-arrowreturnthick-1-w { background-position: 0px -64px; }

.ui-icon-arrowreturnthick-1-n { background-position: -16px -64px; }

.ui-icon-arrowreturnthick-1-e { background-position: -32px -64px; }

.ui-icon-arrowreturnthick-1-s { background-position: -48px -64px; }

.ui-icon-arrowreturn-1-w { background-position: -64px -64px; }

.ui-icon-arrowreturn-1-n { background-position: -80px -64px; }

.ui-icon-arrowreturn-1-e { background-position: -96px -64px; }

.ui-icon-arrowreturn-1-s { background-position: -112px -64px; }

.ui-icon-arrowrefresh-1-w { background-position: -128px -64px; }

.ui-icon-arrowrefresh-1-n { background-position: -144px -64px; }

.ui-icon-arrowrefresh-1-e { background-position: -160px -64px; }

.ui-icon-arrowrefresh-1-s { background-position: -176px -64px; }

.ui-icon-arrow-4 { background-position: 0px -80px; }

.ui-icon-arrow-4-diag { background-position: -16px -80px; }

.ui-icon-extlink { background-position: -32px -80px; }

.ui-icon-newwin { background-position: -48px -80px; }

.ui-icon-refresh { background-position: -64px -80px; }

.ui-icon-shuffle { background-position: -80px -80px; }

.ui-icon-transfer-e-w { background-position: -96px -80px; }

.ui-icon-transferthick-e-w { background-position: -112px -80px; }

.ui-icon-folder-collapsed { background-position: 0px -96px; }

.ui-icon-folder-open { background-position: -16px -96px; }

.ui-icon-document { background-position: -32px -96px; }

.ui-icon-document-b { background-position: -48px -96px; }

.ui-icon-note { background-position: -64px -96px; }

.ui-icon-mail-closed { background-position: -80px -96px; }

.ui-icon-mail-open { background-position: -96px -96px; }

.ui-icon-suitcase { background-position: -112px -96px; }

.ui-icon-comment { background-position: -128px -96px; }

.ui-icon-person { background-position: -144px -96px; }

.ui-icon-print { background-position: -160px -96px; }

.ui-icon-trash { background-position: -176px -96px; }

.ui-icon-locked { background-position: -192px -96px; }

.ui-icon-unlocked { background-position: -208px -96px; }

.ui-icon-bookmark { background-position: -224px -96px; }

.ui-icon-tag { background-position: -240px -96px; }

.ui-icon-home { background-position: 0px -112px; }

.ui-icon-flag { background-position: -16px -112px; }

.ui-icon-calendar { background-position: -32px -112px; }

.ui-icon-cart { background-position: -48px -112px; }

.ui-icon-pencil { background-position: -64px -112px; }

.ui-icon-clock { background-position: -80px -112px; }

.ui-icon-disk { background-position: -96px -112px; }

.ui-icon-calculator { background-position: -112px -112px; }

.ui-icon-zoomin { background-position: -128px -112px; }

.ui-icon-zoomout { background-position: -144px -112px; }

.ui-icon-search { background-position: -160px -112px; }

.ui-icon-wrench { background-position: -176px -112px; }

.ui-icon-gear { background-position: -192px -112px; }

.ui-icon-heart { background-position: -208px -112px; }

.ui-icon-star { background-position: -224px -112px; }

.ui-icon-link { background-position: -240px -112px; }

.ui-icon-cancel { background-position: 0px -128px; }

.ui-icon-plus { background-position: -16px -128px; }

.ui-icon-plusthick { background-position: -32px -128px; }

.ui-icon-minus { background-position: -48px -128px; }

.ui-icon-minusthick { background-position: -64px -128px; }

.ui-icon-close { background-position: -80px -128px; }

.ui-icon-closethick { background-position: -96px -128px; }

.ui-icon-key { background-position: -112px -128px; }

.ui-icon-lightbulb { background-position: -128px -128px; }

.ui-icon-scissors { background-position: -144px -128px; }

.ui-icon-clipboard { background-position: -160px -128px; }

.ui-icon-copy { background-position: -176px -128px; }

.ui-icon-contact { background-position: -192px -128px; }

.ui-icon-image { background-position: -208px -128px; }

.ui-icon-video { background-position: -224px -128px; }

.ui-icon-script { background-position: -240px -128px; }

.ui-icon-alert { background-position: 0px -144px; }

.ui-icon-info { background-position: -16px -144px; }

.ui-icon-notice { background-position: -32px -144px; }

.ui-icon-help { background-position: -48px -144px; }

.ui-icon-check { background-position: -64px -144px; }

.ui-icon-bullet { background-position: -80px -144px; }

.ui-icon-radio-on { background-position: -96px -144px; }

.ui-icon-radio-off { background-position: -112px -144px; }

.ui-icon-pin-w { background-position: -128px -144px; }

.ui-icon-pin-s { background-position: -144px -144px; }

.ui-icon-play { background-position: 0px -160px; }

.ui-icon-pause { background-position: -16px -160px; }

.ui-icon-seek-next { background-position: -32px -160px; }

.ui-icon-seek-prev { background-position: -48px -160px; }

.ui-icon-seek-end { background-position: -64px -160px; }

.ui-icon-seek-start { background-position: -80px -160px; }

.ui-icon-seek-first { background-position: -80px -160px; }

.ui-icon-stop { background-position: -96px -160px; }

.ui-icon-eject { background-position: -112px -160px; }

.ui-icon-volume-off { background-position: -128px -160px; }

.ui-icon-volume-on { background-position: -144px -160px; }

.ui-icon-power { background-position: 0px -176px; }

.ui-icon-signal-diag { background-position: -16px -176px; }

.ui-icon-signal { background-position: -32px -176px; }

.ui-icon-battery-0 { background-position: -48px -176px; }

.ui-icon-battery-1 { background-position: -64px -176px; }

.ui-icon-battery-2 { background-position: -80px -176px; }

.ui-icon-battery-3 { background-position: -96px -176px; }

.ui-icon-circle-plus { background-position: 0px -192px; }

.ui-icon-circle-minus { background-position: -16px -192px; }

.ui-icon-circle-close { background-position: -32px -192px; }

.ui-icon-circle-triangle-e { background-position: -48px -192px; }

.ui-icon-circle-triangle-s { background-position: -64px -192px; }

.ui-icon-circle-triangle-w { background-position: -80px -192px; }

.ui-icon-circle-triangle-n { background-position: -96px -192px; }

.ui-icon-circle-arrow-e { background-position: -112px -192px; }

.ui-icon-circle-arrow-s { background-position: -128px -192px; }

.ui-icon-circle-arrow-w { background-position: -144px -192px; }

.ui-icon-circle-arrow-n { background-position: -160px -192px; }

.ui-icon-circle-zoomin { background-position: -176px -192px; }

.ui-icon-circle-zoomout { background-position: -192px -192px; }

.ui-icon-circle-check { background-position: -208px -192px; }

.ui-icon-circlesmall-plus { background-position: 0px -208px; }

.ui-icon-circlesmall-minus { background-position: -16px -208px; }

.ui-icon-circlesmall-close { background-position: -32px -208px; }

.ui-icon-squaresmall-plus { background-position: -48px -208px; }

.ui-icon-squaresmall-minus { background-position: -64px -208px; }

.ui-icon-squaresmall-close { background-position: -80px -208px; }

.ui-icon-grip-dotted-vertical { background-position: 0px -224px; }

.ui-icon-grip-dotted-horizontal { background-position: -16px -224px; }

.ui-icon-grip-solid-vertical { background-position: -32px -224px; }

.ui-icon-grip-solid-horizontal { background-position: -48px -224px; }

.ui-icon-gripsmall-diagonal-se { background-position: -64px -224px; }

.ui-icon-grip-diagonal-se { background-position: -80px -224px; }

.ui-corner-all, .ui-corner-top, .ui-corner-left, .ui-corner-tl { border-top=
-left-radius: 4px; }

.ui-corner-all, .ui-corner-top, .ui-corner-right, .ui-corner-tr { border-to=
p-right-radius: 4px; }

.ui-corner-all, .ui-corner-bottom, .ui-corner-left, .ui-corner-bl { border-=
bottom-left-radius: 4px; }

.ui-corner-all, .ui-corner-bottom, .ui-corner-right, .ui-corner-br { border=
-bottom-right-radius: 4px; }

.ui-widget-overlay { background: rgb(170, 170, 170); opacity: 0.3; }

.ui-widget-shadow { box-shadow: rgb(170, 170, 170) -8px -8px 8px; }
------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN----
Content-Type: text/css
Content-Transfer-Encoding: quoted-printable
Content-Location: cid:css-9a16203a-d41e-4183-bb61-b6a306639b29@mhtml.blink

@charset "utf-8";

@font-face { font-family: NotoSans_online_security; src: url("chrome-extens=
ion://llbcnfanfmjhpedaedhbcnpgeepdnnok/assets/fonts/noto-sans-regular.woff"=
); }

@font-face { font-family: NotoSans_medium_online_security; src: url("chrome=
-extension://llbcnfanfmjhpedaedhbcnpgeepdnnok/assets/fonts/noto-sans-medium=
.ttf"); }

@font-face { font-family: NotoSans_bold_online_security; src: url("chrome-e=
xtension://llbcnfanfmjhpedaedhbcnpgeepdnnok/assets/fonts/noto-sans-bold.wof=
f"); }

@font-face { font-family: NotoSans_semibold_online_security; src: url("chro=
me-extension://llbcnfanfmjhpedaedhbcnpgeepdnnok/assets/fonts/noto-sans-semi=
bold.ttf"); }
------MultipartBoundary--sIedHJPx6GTWnm41iCaEwkSOlzjUYE0d8WWSJz2qtN------
