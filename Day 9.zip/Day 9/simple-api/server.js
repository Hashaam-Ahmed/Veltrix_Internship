const express = require("express");

const app = express();
const PORT = 3000;

// Basic API route
app.get("/hello", (req, res) => {
    res.json({ message: "Hello World" });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});